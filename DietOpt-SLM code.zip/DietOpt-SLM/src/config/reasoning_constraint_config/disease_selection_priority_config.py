
DISEASE_SELECTION_PRIORITY = [
    "糖尿病"
]
DISEASE_SELECTION_PRIORITY_INDEX = {
    disease: index for index, disease in enumerate(DISEASE_SELECTION_PRIORITY)
}

class DiseaseSelectionPriorityConfig:
    disease_selection_priority = DISEASE_SELECTION_PRIORITY
    disease_selection_priority_index = DISEASE_SELECTION_PRIORITY_INDEX
    
    disease_priority = 99999
    disease_priority_name = None

    def __init__(self, disease_selection_priority=DISEASE_SELECTION_PRIORITY, disease_selection_priority_index=DISEASE_SELECTION_PRIORITY_INDEX):
        self.disease_selection_priority = disease_selection_priority
        self.disease_selection_priority_index = disease_selection_priority_index

    @classmethod
    def get_disease_selection_priority_by_disease_name(self, user_health_risk_arr:set):
        disease_priority_result = self.disease_priority
        disease_priority_name_result = self.disease_priority_name

        if user_health_risk_arr and len(user_health_risk_arr) > 0:
            for disease in user_health_risk_arr:
                if disease in self.disease_selection_priority_index:
                    priority = self.disease_selection_priority_index[disease]
                    if priority < disease_priority_result:
                        disease_priority_result = priority
                        disease_priority_name_result = disease
        return disease_priority_result, disease_priority_name_result
    
if __name__ == "__main__":
    print('---start---')
