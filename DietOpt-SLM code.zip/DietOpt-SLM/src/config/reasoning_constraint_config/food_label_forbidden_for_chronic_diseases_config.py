CONFIG_LIST = [
    {
		"disease_name": "高血糖",
		"suitable_food_label": [
            "高糖",
            "高GI值",
            "糖醋",
            "红烧",
            "高能量",
            "酸甜",
		]
	},
    {
		"disease_name": "糖尿病",
		"suitable_food_label": [
			"高糖",
            "高GI值",
            "糖醋",
            "红烧",
            "高能量",
            "酸甜",
		]
	},
	{
		"disease_name": "高血脂",
		"suitable_food_label": [
            "高脂",
            "饱和脂肪",
            "高饱和脂肪",
            "高饱和脂肪肉",
            "反式脂肪",
            "高反式脂肪",
            "高胆固醇",
            "油炸",
            "煎炸",
            "大量油炒",
            "高油",
            "精制碳水",
            "高盐",
            "肥肉",
            "动物油脂",
            "动物油",
            "内脏类",
            "果汁",
            "蛋糕"
            "酒类"
		]
	},
	{
		"disease_name": "高血压",
		"suitable_food_label": [
            "高钠",
            "高盐",
            "高脂",
            "高糖",
            "高胆固醇",
            "高能量",
            "高饱和脂肪",
            "高饱和脂肪肉",
            "动物油脂",
            "腌制",
            "酒精",
		]
	},
	{
		"disease_name": "肥胖",
		"suitable_food_label": [
            "高能量",
            "高糖",
            "高脂",
            "高油",
            "油炸",
            "煎炸",
		]
	}
]

class FoodLabelForbiddenForChronicDiseasesConfig:
    config_list = CONFIG_LIST
    
    def __init__(self, config_list):
        self.config_list = config_list

    @classmethod
    def get_all_disease_name_list(self):
        return [item["disease_name"] for item in self.config_list]
    
    @classmethod
    def get_forbidden_food_label_list(self, disease_name):
        if not disease_name:
            return []
        if "，" in disease_name:
            disease_name = disease_name.replace("，", ",")
        if "," in disease_name:
            disease_name_list = disease_name.split(",")
        else:
            disease_name_list = [disease_name]
        suitable_food_label_list = []
        temp_set = set()
        for item in self.config_list:
            if item["disease_name"] in disease_name_list:
                temp_set.update(item["suitable_food_label"])
        suitable_food_label_list = list(temp_set)
        return suitable_food_label_list
