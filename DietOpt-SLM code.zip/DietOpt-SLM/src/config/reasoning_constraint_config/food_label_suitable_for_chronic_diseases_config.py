CONFIG_LIST = [
    {
		"disease_name": "高血糖",
		"suitable_food_label": [
			"低糖",
			"低GI值",
			"中GI值",
			"高膳食纤维",
			"低升糖负荷",
			"优质低脂肪蛋白质",
			"复合碳水",
            "绿叶蔬菜",
            "深色蔬菜",
            "全谷物",
            "杂粮",
            "粗粮",
            "低胆固醇",
            "高蛋白",
            "低脂",
            "优质蛋白",
            "深海鱼",
		]
	},
    {
		"disease_name": "糖尿病",
		"suitable_food_label": [
			"低糖",
			"低GI值",
			"中GI值",
			"高膳食纤维",
			"低升糖负荷",
			"优质低脂肪蛋白质",
			"复合碳水",
            "绿叶蔬菜",
            "深色蔬菜",
            "全谷物",
            "杂粮",
            "粗粮",
            "低胆固醇",
            "高蛋白",
            "低脂",
            "优质蛋白",
            "深海鱼",
		]
	},
	{
		"disease_name": "高血脂",
		"suitable_food_label": [
			"低饱和脂肪",
			"低反式脂肪",
			"高不饱和脂肪酸",
			"高膳食纤维",
			"低糖",
			"低胆固醇",
            "绿叶蔬菜",
            "杂粮",
            "粗粮",
            "高钾",
            "低钠",
            "低GI值",
            "高维生素E",
            "高叶酸",
            "全谷物",
            "薯类",
            "蔬菜",
            "水果",
            "鱼",
            "豆类及豆制品",
            "不饱和脂肪酸",
            "高纤维主食",
            "植物蛋白",
		]
	},
	{
		"disease_name": "高血压",
		"suitable_food_label": [
			"低盐",
			"高钾",
			"低脂",
			"高膳食纤维",
			"低糖",
			"优质蛋白质",
			"清淡易消化",
            "绿叶蔬菜",
            "全谷物",
            "薯类",
            "杂豆类",
            "杂粮",
            "粗粮",
            "瘦肉",
            "蔬菜",
            "水果",
            "鱼",
            "禽类",
            "奶类",
            "豆类及豆制品",
            "坚果",
            "优质蛋白"
		]
	},
	{
		"disease_name": "肥胖",
		"suitable_food_label": [
			"低热量",
			"高膳食纤维",
			"高蛋白",
			"低脂肪",
			"低糖",
			"高营养密度",
			"清淡烹饪",
            "绿叶蔬菜",
		]
	}
]


class FoodLabelSuitableForChronicDiseasesConfig:
    config_list = CONFIG_LIST
    
    def __init__(self, config_list):
        self.config_list = config_list

    @classmethod
    def get_all_disease_name_list(self):

        return [item["disease_name"] for item in self.config_list]
    
    @classmethod
    def get_suitable_food_label_list(self, disease_name):
        
        if not disease_name:
            return []
        if "，" in disease_name:
            disease_name = disease_name.replace("，", ",")
        if "," in disease_name:
            disease_name_list = disease_name.split(",")
        else:
            disease_name_list = [disease_name]
        suitable_food_label_list = []
        temp_set = set()
        for item in self.config_list:
            if item["disease_name"] in disease_name_list:
                temp_set.update(item["suitable_food_label"])
        suitable_food_label_list = list(temp_set)
        return suitable_food_label_list
