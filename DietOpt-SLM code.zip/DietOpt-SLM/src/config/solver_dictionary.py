ACTIVITY_LEVEL = {
    "卧床/久坐不动": "01",
    "可行走/低活动量": "02",
    "轻度活动": "03",
    "中度活动": "04",
    "非常活跃活动": "05",
    "高度活跃活动": "06",
}

ACTIVITY_LEVEL_PA = {
    "卧床/久坐不动": 1.1,
    "可行走/低活动量": 1.3,
    "轻度活动": 1.4,
    "中度活动": 1.5,
    "非常活跃活动": 1.7,
    "高度活跃活动": 1.9,
}

GENDER = {
    "男": 0,
    "女": 1,
}

YES_OR_NO = {
    "是": 1,
    "否": 0,
}


class DictUtil:
    _dicts = {
        "ACTIVITY_LEVEL": ACTIVITY_LEVEL,
        "GENDER": GENDER,
        "YES_OR_NO": YES_OR_NO,
        "ACTIVITY_LEVEL_PA": ACTIVITY_LEVEL_PA,
    }

    @classmethod
    def get_code(cls, dict_name, name):
        mapping = cls._dicts.get(dict_name, {})
        return mapping.get(name)

    @classmethod
    def get_name(cls, dict_name, code):
        mapping = cls._dicts.get(dict_name, {})
        for k, v in mapping.items():
            if v == code:
                return k
        return None


if __name__ == "__main__":
    print('---start---')
    
