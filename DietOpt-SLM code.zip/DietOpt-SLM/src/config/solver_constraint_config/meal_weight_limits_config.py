CONFIG_LIST = [
    {
        "id": "config_700_1000",
        "total_energy": [700, 1000],
        "weight_limits": {
            "breakfast": [150, 300],
            "lunch": [250, 450],    
            "dinner": [200, 400],
            "snack": [10, 300]
        }
    },
    {
        "id": "config_1000_1400",
        "total_energy": [1000, 1400],
        "weight_limits": {
            "breakfast": [150, 450],
            "lunch": [250, 600], 
            "dinner": [250, 500],
            "snack": [10, 300] 
        }
    },
    {
        "id": "config_1400_2000",
        "total_energy": [1400, 2000],
        "weight_limits": {
            "breakfast": [150, 600],
            "lunch": [250, 800], 
            "dinner": [250, 700],
            "snack": [10, 300] 
        }
    },
    {
        "id": "config_2000_2500",
        "total_energy": [2000, 2500],
        "weight_limits": {
            "breakfast": [150, 750],
            "lunch": [250, 950], 
            "dinner": [250, 850],
            "snack": [10, 400] 
        }
    },
    {
        "id": "config_2500_plus",
        "total_energy": [2500, 6000],
        "weight_limits": {
            "breakfast": [150, 800],
            "lunch": [250, 800], 
            "dinner": [250, 800],
            "snack": [10, 600] 
        }
    },
    {
        "id": "config_default",
        "category": "默认",
        "ree": [],
        "total_energy": [],
        "weight_limits": {
            "breakfast": [100, 600],
            "lunch": [200, 900],
            "dinner": [200, 800],
            "snack": [50, 500]
        }
    }
]

class MealWeightLimitsConfig:
    config_list = CONFIG_LIST
    WEIGHT_LIMITS = "weight_limits"
    

    
    def __init__(self, config_list):
        self.config_list = config_list

    @classmethod
    def get_meal_weight_limits(self, params_dict:dict = None):
        if params_dict is None:
            return self.get_default_config()
        max_score = 0
        final_config = None
        total_energy = params_dict.get("total_energy", [])
       

        for config in self.config_list:
            config_total_energy = config.get("total_energy", [])
            if len(config_total_energy) == 2:
                min_energy, max_energy = config_total_energy
                if min_energy <= total_energy <= max_energy:
                    score = max_energy - total_energy
                    if score > max_score:
                        max_score = score
                        final_config = config[self.WEIGHT_LIMITS]
                        break
        if not final_config:
            final_config = self.get_default_config()
        return final_config
    
    @classmethod
    def get_default_config(self):
        final_default_config = None
        for config in self.config_list:
            if config.get("category") == "默认":
                final_default_config = config[self.WEIGHT_LIMITS]
                break
        return final_default_config


if __name__ == "__main__":
    print('---start---')