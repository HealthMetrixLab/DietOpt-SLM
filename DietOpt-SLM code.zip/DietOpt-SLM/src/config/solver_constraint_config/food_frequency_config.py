CONFIG_LIST = [
    {
        "category": "主食",
        "max_times_per_week": 3,
        "type": "formal",
        "last_category": ["米饭", "炒饭", "盖饭/焖饭/抓饭", "粥/糊/羹", 
                          "包子", "饼", "饺子/馄饨/烧卖", "馒头/花卷/窝头", 
                          "面条/米粉/粉丝/皮", "其他主食", "油炸面点", "杂粮类"],
    },
    {
        "category": "水果",
        "max_times_per_week": 7,
        "type": "formal",
        "last_category": [],
    },
    {
        "category": "饮品",
        "max_times_per_week": 7,
        "type": "formal",
        "last_category": ["奶类饮品"],
    },
    {
        "category": "豆类与豆制品",
        "max_times_per_week": 3,
        "type": "formal",
        "last_category": ["豆浆/豆奶"],
    },
    {
        "category": "零食与甜点",
        "max_times_per_week": 7,
        "type": "formal",
        "last_category": ["坚果/籽类零食"],
    },
    {
        "category": "肉蛋鱼与海产",
        "max_times_per_week": 7,
        "type": "formal",
        "last_category": ["水煮蛋", "蒸蛋"],
    },
    {
        "category": "默认",
        "max_times_per_week": 2,
        "type": "default",
        "last_category": []
    },
]

class FoodFrequencyConfig:
    config_list = CONFIG_LIST
    
    def __init__(self, config_list):
        self.config_list = config_list

    @classmethod
    def get_food_frequency_by_food_category(self, food_category_str: str, last_category_str: str = None):
        final_frequency = 0
        for item in self.config_list:
            if item["category"] == food_category_str:
                final_frequency = item["max_times_per_week"]
                if last_category_str and item["last_category"]:
                    last_category_arr = item["last_category"]
                    has_match = False
                    for last_category in last_category_arr:
                        if last_category == last_category_str:
                            has_match = True
                            final_frequency = item["max_times_per_week"]
                            break
                    if not has_match:
                        final_frequency = 0
        if not final_frequency:
            final_frequency = self.get_food_frequency_by_food_category("默认")
        return final_frequency
    
    @classmethod
    def get_default_config(self):
        return self.get_food_frequency_by_food_category("默认")


if __name__ == "__main__":
    print('---start---')