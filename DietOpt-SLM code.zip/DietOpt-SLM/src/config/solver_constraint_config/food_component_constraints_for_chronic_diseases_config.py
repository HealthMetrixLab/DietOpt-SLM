CONFIG_LIST = [
    {
        "suitable_disease_name": ['高血糖', '糖尿病'],
        "constraints": [
            {
                "name": ['默认'],
                "range": [100, 500],
                "category_main": "default"
            },
            {
                "name": [
                    '其他杂粮主食', '杂粮饭', '面条/米粉/粉丝/皮', '馒头/花卷/窝头', '饺子/馄饨/烧卖', '饼', '包子', 
                ],
                "range": [25, 600],
                "category_main": "主食"
            },
            {
                "name": [
                    '水煮蛋','煎蛋','蒸蛋'
                ],
                "range": [50, 500],
                "category_main": "肉蛋鱼与海产"
            },
            {
                "name": [
                    '粥/糊/羹'
                ],
                "range": [25, 500],
                "category_main": "主食"
            },
			{
                "name": [
                    '盖饭/焖饭/抓饭','炒饭', '米饭', '糕点类'
                ],
                "range": [25, 500],
                "category_main": "主食"
            },
            {
                "name": ['菌类菜肴', '凉拌蔬菜', '炒/烧/焖/烩蔬菜', '蒸/煮蔬菜', '蔬菜汤羹', '芽苗类'],
                "range": [100, 500],
                "category_main": "蔬菜"
            },
            {
                "name": ['腌/酱/泡菜'],
                "range": [20, 500],
                "category_main": "蔬菜"
            },
            {
                "name": ['豆腐/豆干/豆花菜肴', '豆类菜肴', '腐竹/豆皮/面筋菜肴', '豆制品汤羹'],
                "range": [100, 500],
                "category_main": "豆类与豆制品"
            },
            {
                "name": ['豆浆/豆奶'],
                "range": [100, 500],
                "category_main": "豆类与豆制品"
            },
            {
                "name": ['奶类饮品'],
                "range": [100, 500],
                "category_main": "饮品"
            },
            {
                "name": ['干制水果', '水果沙拉', '水果饮品/汁/酱', '新鲜水果'],
                "range": [50, 500],
                "category_main": "水果"
            },
            {
                "name": ['畜肉汤羹', '蛋类汤羹', '禽肉汤羹', '虾蟹贝类汤羹', '鱼类汤羹'],
                "range": [100, 500],
                "category_main": "肉蛋鱼与海产"
            },
            {
                "name": ['坚果/籽类零食'],
                "range": [5, 200],
                "category_main": "坚果零食与甜点"
            },
        ]
    },
    {
        "suitable_disease_name": ['default'],
        "constraints": [
            {
                "name": ['默认'],
                "range": [100, 500],
                "category_main": "default"
            },
            {
                "name": [
                    '其他杂粮主食', '杂粮饭', '面条/米粉/粉丝/皮', '馒头/花卷/窝头', '饺子/馄饨/烧卖', '饼', '包子', 
                ],
                "range": [25, 600],
                "category_main": "主食"
            },
            {
                "name": [
                    '水煮蛋','煎蛋','蒸蛋'
                ],
                "range": [50, 500],
                "category_main": "肉蛋鱼与海产"
            },
            {
                "name": [
                    '粥/糊/羹'
                ],
                "range": [25, 500],
                "category_main": "主食"
            },
			{
                "name": [
                    '盖饭/焖饭/抓饭','炒饭', '米饭', '糕点类'
                ],
                "range": [25, 500],
                "category_main": "主食"
            },
            {
                "name": ['菌类菜肴', '凉拌蔬菜', '炒/烧/焖/烩蔬菜', '蒸/煮蔬菜', '蔬菜汤羹', '芽苗类'],
                "range": [100, 500],
                "category_main": "蔬菜"
            },
            {
                "name": ['腌/酱/泡菜'],
                "range": [20, 500],
                "category_main": "蔬菜"
            },
            {
                "name": ['豆腐/豆干/豆花菜肴', '豆类菜肴', '腐竹/豆皮/面筋菜肴', '豆制品汤羹'],
                "range": [100, 500],
                "category_main": "豆类与豆制品"
            },
            {
                "name": ['豆浆/豆奶'],
                "range": [100, 500],
                "category_main": "豆类与豆制品"
            },
            {
                "name": ['奶类饮品'],
                "range": [100, 500],
                "category_main": "饮品"
            },
            {
                "name": ['干制水果', '水果沙拉', '水果饮品/汁/酱', '新鲜水果'],
                "range": [50, 500],
                "category_main": "水果"
            },
            {
                "name": ['畜肉汤羹', '蛋类汤羹', '禽肉汤羹', '虾蟹贝类汤羹', '鱼类汤羹'],
                "range": [100, 500],
                "category_main": "肉蛋鱼与海产"
            },
            {
                "name": ['坚果/籽类零食'],
                "range": [5, 200],
                "category_main": "坚果零食与甜点"
            },
        ]
    }
]


class FoodComponentConstraintsForChronicDiseasesConfig:
    config_list = CONFIG_LIST
    
    def __init__(self, config_list):
        self.config_list = config_list

    @classmethod
    def get_constraints_by_disease_name(self, disease_name):

        for item in self.config_list:
            suitable_disease_name_arr = item["suitable_disease_name"]
            if disease_name in suitable_disease_name_arr:
                return {
                    "constraints": item["constraints"],
                    "type": "normal" 
                }
        return self.get_default_constraints()
    
    @classmethod
    def get_default_constraints(self):
        return {
            "constraints": self.get_constraints_by_disease_name("default")["constraints"],
            "type": "default"
        }
    
if __name__ == "__main__":
    print('---start---')
