
CONFIG_LIST = [
    {
        "range": [0, 2000],
        "config": {
            "主食":[3, 21],
            "主食":[3, 21],
        },
        "type": "formal"
    },
    {
        "range": [2001, 6000],
        "config": {
           "主食":[3, 21],
            "主食":[3, 21],
        },
        "type": "formal"
    },
    {
        "range": [6001, 1000],
        "config": {
           "主食":[3, 21],
            "主食":[3, 21],
        },
        "type": "formal"
    },
    {
        "range": [0, 0],
        "config": {
           "主食":[3, 21],
            "主食":[3, 21],
        },
        "type": "default"
    }
]


class FrequencyFoodCategoryConfigBySolverSpace:
    config_list = CONFIG_LIST
    
    def __init__(self, config_list):
        self.config_list = config_list

    @classmethod
    def get_frequency_food_category_config(self, optional_food_num):
        for item in self.config_list:
            if item["range"][0] <= optional_food_num <= item["range"][1]:
                return item["config"]
        return self.get_default_config()
    
    @classmethod
    def get_default_config(self):
        for item in self.config_list:
            if item["type"] == "default":
                return item["config"]
        return None


if __name__ == "__main__":
    print('---start---')