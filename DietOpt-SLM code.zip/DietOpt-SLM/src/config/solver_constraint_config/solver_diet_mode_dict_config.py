class SolverDietModeDict:
    diet_mode_dict = {
        "MODLE_01": {
            "name": "平衡膳食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.12, 0.14],
                    "fat": [0.20, 0.30],
                    "carb": [0.50, 0.65]
                }
            }
        },
        "MODLE_02": {
            "name": "限能量平衡膳食",
            "Parameters": {
                "cal_factor": 0.7,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.20, 0.25],
                    "carb": [0.50, 0.65]
                }
            }
        },
        "MODLE_03": {
            "name": "限能量高蛋白饮食",
            "Parameters": {
                "cal_factor": 0.7,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.20, 0.30],
                    "fat": [0.20, 0.30],
                    "carb": [0.40, 0.60]
                }
            }
        },
        "MODLE_04": {
            "name": "限能量低脂饮食",
            "Parameters": {
                "cal_factor": 0.7,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.10, 0.20],
                    "carb": [0.60, 0.75]
                }
            }
        },
        "MODLE_05": {
            "name": "低能量膳食",
            "Parameters": {
                "cal_factor": 0.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.30, 0.40],
                    "fat": [0.10, 0.20],
                    "carb": [0.40, 0.60]
                }
            }
        },
        "MODLE_06": {
            "name": "极低能量膳食",
            "Parameters": {
                "cal_factor": 0.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.35, 0.50],
                    "fat": [0.10, 0.20],
                    "carb": [0.20, 0.55]
                }
            }
        },
        "MODLE_07": {
            "name": "低盐饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.12, 0.14],
                    "fat": [0.20, 0.30],
                    "carb": [0.50, 0.65]
                }
            }
        },
        "MODLE_09": {
            "name": "低碳水化合物饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.25, 0.30],
                    "fat": [0.30, 0.40],
                    "carb": [0.30, 0.40]
                }
            }
        },
        "MODLE_10": {
            "name": "DASH饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.20, 0.35],
                    "lunch": [0.25, 0.45],
                    "dinner": [0.25, 0.40],
                    "snack": [0.05, 0.20]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.20, 0.30],
                    "carb": [0.50, 0.65]
                }
            }
        },
        "MODLE_12": {
            "name": "糖尿病治疗膳食",
            "Parameters": {
                "cal_factor": 0.9,
                "three_meal_ratios": {
                    "breakfast": [0.30, 0.35], # 早餐吃好，避免午餐前低血糖
                    "lunch": [0.35, 0.40],
                    "dinner": [0.20, 0.25],    # 晚餐少吃，特别是碳水要少
                    "snack": [0.05, 0.10]      # 加餐仅限极少量坚果或低糖水果
                },
                "nutrient_ratios": {
                    "protein": [0.20, 0.25],   # 【调高】保证肝脏修复，增加饱腹感
                    "fat": [0.30, 0.35],       # 【调高】用优质脂肪（橄榄油、坚果）替代碳水供能
                    "carb": [0.40, 0.45]       # 【调低】核心！将碳水压到45%以下
                }
            }
        },
        "MODLE_13": {
            "name": "低蛋白饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.05, 0.10],
                    "fat": [0.25, 0.30],
                    "carb": [0.55, 0.70]
                }
            }
        },
        "MODLE_14": {
            "name": "生酮饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.25, 0.30],
                    "fat": [0.50, 0.65],
                    "carb": [0.05, 0.20]
                }
            }
        },
        "MODLE_15": {
            "name": "低嘌呤饮食",
            "Parameters": {
                "cal_factor": 0.7,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.10, 0.20],
                    "fat": [0.20, 0.25],
                    "carb": [0.60, 0.65]
                }
            }
        },
        "MODLE_16": {
            "name": "间歇性能量限制饮食（16+8）",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.20, 0.30],
                    "carb": [0.45, 0.60]
                }
            }
        },
        "MODLE_17": {
            "name": "TLC（治疗性生活方式改变饮食）",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.35, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.10]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.25, 0.30],
                    "carb": [0.50, 0.60]
                }
            }
        },
        "MODLE_18": {
            "name": "中国心脏健康饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.25, 0.30],
                    "carb": [0.50, 0.55]
                }
            }
        },
        "MODLE_19": {
            "name": "东方健康膳食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.25, 0.30],
                    "carb": [0.55, 0.60]
                }
            }
        },
        "MODLE_20": {
            "name": "地中海饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.15, 0.20],
                    "fat": [0.25, 0.30],
                    "carb": [0.55, 0.60]
                }
            }
        },
        "MODLE_22": {
            "name": "蛋奶素食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.12, 0.14],
                    "fat": [0.20, 0.30],
                    "carb": [0.50, 0.65]
                }
            }
        },
        "MODLE_23": {
            "name": "健脑饮食",
            "Parameters": {
                "cal_factor": 1.0,
                "three_meal_ratios": {
                    "breakfast": [0.25, 0.30],
                    "lunch": [0.30, 0.40],
                    "dinner": [0.30, 0.35],
                    "snack": [0.05, 0.15]
                },
                "nutrient_ratios": {
                    "protein": [0.12, 0.14],
                    "fat": [0.20, 0.30],
                    "carb": [0.50, 0.65]
                }
            }
        },
    }
