
CONFIG_LIST = [
    {
        "id": "config_1",
        "suitable_disease_name": ['高血糖', '糖尿病'],
        "suitable_nutrition_target": ['控制血糖'],
        "suitable_mode": [],
        "activity_level": [],
        "carb_ratio_limits": {
            "breakfast": [0.20, 0.30],
            "lunch":     [0.15, 0.40],
            "dinner":    [0.15, 0.25],
            "snack":     [0.0,  0.15]
        }
    },
    {
        "id": "config_2",
        "suitable_disease_name": ['肥胖'],
        "suitable_nutrition_target": ['控制体重'],
        "suitable_mode": [],
        "activity_level": [],
        "carb_ratio_limits": {
            "breakfast": [0.25, 0.30],
            "lunch":     [0.35, 0.40],
            "dinner":    [0.20, 0.25],
            "snack":     [0.0,  0.15]
        }
    },
    {
        "id": "config_3",
        "suitable_disease_name": [],
        "suitable_nutrition_target": [],
        "suitable_mode": [],
        "activity_level": ['1.7', '1.9'],
        "carb_ratio_limits": {
            "breakfast": [0.15, 0.30],
            "lunch":     [0.30, 0.45],
            "dinner":    [0.15, 0.30],
            "snack":     [0.0,  0.20]
        }
    },
    {
        "id": "config_default",
        "category": "默认",
        "carb_ratio_limits": {
            "breakfast": [0.20, 0.35],
            "lunch":     [0.20, 0.45],
            "dinner":    [0.20, 0.40],
            "snack":     [0.0,  0.20]
        }
    },
]


class MealCarbRatioLimitsConfig:
    config_list = CONFIG_LIST
    CARB_RATIO_LIMITS = "carb_ratio_limits"
    

    hit_disease_score = 100
    hit_nutrition_target_score = 80
    hit_mode_score = 60
    hit_activity_level_score = 50

    
    def __init__(self, config_list):
        self.config_list = config_list

    @classmethod
    def get_meal_carb_ratio_limits(self, params_dict:dict):
        max_score = 0
        final_config = None
        disease_name = params_dict.get("disease_name", "")
        nutrition_target = params_dict.get("nutrition_target", "")
        mode = params_dict.get("mode", "")
        activity_level = params_dict.get("activity_level", "")

        for config in self.config_list:
            current_score = 0
            if disease_name and disease_name in config.get("suitable_disease_name", []):
                current_score += self.hit_disease_score
            if nutrition_target and nutrition_target in config.get("suitable_nutrition_target", []):
                current_score += self.hit_nutrition_target_score
            if mode and mode in config.get("suitable_mode", []):
                current_score += self.hit_mode_score
            if activity_level and activity_level in config.get("activity_level", []):
                current_score += self.hit_activity_level_score
            if current_score > max_score:
                max_score = current_score
                final_config = config[self.CARB_RATIO_LIMITS]
        if not final_config:
            final_config = self.get_default_config()
        return final_config
    
    @classmethod
    def get_default_config(self):
        final_default_config = None
        for config in self.config_list:
            if config.get("category") == "默认":
                final_default_config = config[self.CARB_RATIO_LIMITS]
                break
        return final_default_config


if __name__ == "__main__":
    print('---start---')