import sys
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)

from src.graph_reasoner.alternative_food_library import load_alternative_food_library_by_cons
from src.graph_reasoner.quantify_dietary_preferences import quantify_dietary_preferences_by_cons
from src.graph_reasoner.quantify_the_appropriateness_of_food_meals import quantify_appropriateness_of_food_meals
from src.graph_reasoner.quantify_the_suitability_of_food_combinations import quantify_suitability_of_food_combinations
from src.graph_reasoner.quantify_food_category_preferences_and_suitability import quantify_food_category_preferences_and_suitability_by_cons
from src.graph_reasoner.analyse_dietary_pattern_by_execute_llm import analyse_dietary_pattern_by_execute_llm_by_cons
from src.graph_reasoner.analyse_preference_by_execute_llm import analyse_preference_by_execute_llm_by_cons


from util.execute_llm import execute_llm_2_format_user_json, \
    execute_llm_2_analyse_user_province_by_user_address

from util.main_execute_llm_fun import analyse_disease_by_execute_llm_by_cons


from config.diet_pattern_config import DietPatternConfig
from config.constants import Constants

from clazz.file.file_manager_class import FileManager
from clazz.common.common_utils import CommonUtils
from clazz.common.result_manager_class import ResultManager
from clazz.utils.logger_util import logger

executor = ThreadPoolExecutor(max_workers=6)



def solver_diet_main_function(client_ip: str, params_json: dict) -> dict:
    from src.util.valid_data_util import check_solver_diet_param_is_valid
    from src.solver.combinatorial_optimization_solver import execute_solver_async

    logger.info(f"【求解器-获取七日饮食数据(solver/diet)】，client_ip：{client_ip}，请求参数：\n{params_json}")
    serial_number = CommonUtils.get_uuid()
    logger.info(f"【求解器-获取七日饮食数据(solver/diet)】---，client_ip：{client_ip}，请求流水号：{serial_number}")
    start_time = time.time()
    try:
        check_result = check_solver_diet_param_is_valid(params_json)
        if not check_result['success']:
            logger.error(f"【求解器-获取七日饮食数据(solver/diet)】---校验参数失败，{check_result['msg']}，client_ip：{client_ip}")
            return ResultManager.error_with_code(check_result['code'], check_result['msg'], None, serial_number)
        is_save_main_process_result = params_json.get("is_save_main_process_result", "0")

        params_json['serial_number'] = serial_number
        main_process_result = main_process(params_json)
        if not main_process_result or not main_process_result['success']:
            logger.error(f"【求解器-获取七日饮食数据(solver/diet)】---主工作流程执行失败，{main_process_result['msg']}，client_ip：{client_ip}")
            return ResultManager.error_with_code(main_process_result['code'], main_process_result['msg'], None, serial_number)

        
        main_process_result_data = main_process_result['data']
        main_process_result_data['is_save_main_process_result'] = is_save_main_process_result
        main_process_result_data['serial_number'] = serial_number
        execute_solver_result = execute_solver_async(main_process_result_data)
        if not execute_solver_result or not execute_solver_result['success']:
            logger.error(
                f"【求解器-获取七日饮食数据(solver/diet)】---组合优化求解器执行失败，{execute_solver_result['msg']}，client_ip：{client_ip}")
            return ResultManager.error_with_code(execute_solver_result['code'], execute_solver_result['msg'], None, serial_number)
        # logger.info(f"求解器-获取七日饮食数据(solver/diet)，访问成功，客户端IP：{client_ip}，结果：{execute_solver_result}")

        final_data = execute_solver_result['data']
        final_data['alternative_foods_size'] = main_process_result_data.get('alternative_foods_size', 0)

        logger.info(
            f"【求解器-获取七日饮食数据(solver/diet)】------耗时：{time.time() - start_time:.2f} 秒，客户端IP：{client_ip}")
        return ResultManager.success("访问成功！", final_data, serial_number)
    except Exception as e:
        logger.error(f"【求解器-获取七日饮食数据(solver/diet)】---访问失败,{e}")
    return ResultManager.error("访问失败！请联系管理员！", {}, serial_number)









def main_process(param_dict: dict) -> dict:

    start_time = time.time()
    logger.info("==============================main_process进程(开始)======================================")
    try:

        user_self_report = ""
        query_type = param_dict["query_type"]
        user_info_json = param_dict["user_info_json"]

        if query_type == "self_report":
            user_self_report = param_dict["user_self_report"]
        elif query_type == "user_info_json":
            user_info_json_str = CommonUtils.json_data_to_str(user_info_json)
            user_self_report = execute_llm_2_format_user_json(user_info_json_str)
        else:
            return ResultManager.error("query_type错误")

        user_province = execute_llm_2_analyse_user_province_by_user_address(user_self_report)
        #print(f"【主进程】分析用户的省份：{user_province}")
        logger.info(f"【主进程】分析用户的省份：{user_province}")

        diet_history_str = ""
        if "diet_history" in param_dict:
            diet_history_str = param_dict["diet_history"]


        nutritional_prescription_obj = {}
        if "nutritional_prescription" in param_dict and param_dict["nutritional_prescription"]:
            nutritional_prescription_obj = param_dict["nutritional_prescription"]

        llm_require_str = f"用户信息：{user_self_report}\n"
        if diet_history_str:
            llm_require_str += f"用户饮食历史：{diet_history_str}\n"

        dietary_advice_str = ""
        if nutritional_prescription_obj and "dietary_advice" in nutritional_prescription_obj:
            logger.info(f"【主进程】接口提供“用户营养处方建议”，用户营养处方建议：\n{nutritional_prescription_obj['dietary_advice']}")
            dietary_advice_str = f"用户营养处方建议：{nutritional_prescription_obj['dietary_advice']}\n"
            llm_require_str += dietary_advice_str

        logger.info(f"【主进程】处理传递的用户信息和饮食历史记录，处理后传递给模型的数据：\n{dietary_advice_str}")


        start_thread_time = time.time()
        dietary_pattern_obj = {}
        preference_obj = {}


        analyse_preference_cons_dict = {
            # 自我描述
            "user_self_report": user_self_report,
            # 饮食历史
            "diet_history_str": diet_history_str,
            # 饮食建议
            "dietary_advice_str": dietary_advice_str,
        }
        dietary_pattern_obj  = analyse_dietary_pattern_by_execute_llm_by_cons(analyse_preference_cons_dict)

        dietary_pattern_list = dietary_pattern_obj["dietary_patterns"]
        dietary_pattern_str = ""
        dietary_pattern_code = ""
        if len(dietary_pattern_list) > 0:
            dietary_pattern_str = dietary_pattern_list[0]
            dietary_pattern_code = DietPatternConfig.get_code(dietary_pattern_str)
            logger.info(f"【主进程】检索到对应的膳食模式名称，使用该模式，分析出的膳食模式：{dietary_pattern_str}")

        if dietary_pattern_code is None:
            logger.warning(f"【主进程】未检索到对应的膳食模式名称，使用默认平衡膳食模式，分析出的膳食模式：{dietary_pattern_str}")
            dietary_pattern_code = "MODLE_01"
            dietary_pattern_str = "平衡膳食"



        # 营养处方分析出的膳食模式名称
        nutritional_prescription_dietary_pattern_str = None
        if ("nutritional_prescription_dietary_pattern" in nutritional_prescription_obj
                and nutritional_prescription_obj["nutritional_prescription_dietary_pattern"]):
            nutritional_prescription_dietary_pattern_str = nutritional_prescription_obj["nutritional_prescription_dietary_pattern"]

        nutritional_prescription_dietary_pattern_code = None
        if ("nutritional_prescription_dietary_pattern_code" in nutritional_prescription_obj
                and nutritional_prescription_obj["nutritional_prescription_dietary_pattern_code"]):
            nutritional_prescription_dietary_pattern_code = nutritional_prescription_obj["nutritional_prescription_dietary_pattern_code"]



        if nutritional_prescription_dietary_pattern_str:
            logger.info(f"【主进程】接口提供膳食模式名称，膳食模式：{nutritional_prescription_dietary_pattern_str}")
            all_dietary_pattern_name_list = DietPatternConfig.get_all_diet_name_list()
            
            if nutritional_prescription_dietary_pattern_str in all_dietary_pattern_name_list:
                if nutritional_prescription_dietary_pattern_str != dietary_pattern_str:
                    logger.info(f"【主进程】接口提供的膳食模式名称与分析出的膳食模式名称不一致！！！！"
                                   f"使用接口提供的膳食模式，膳食模式：{nutritional_prescription_dietary_pattern_str}，"
                                   f"分析出的膳食模式：{dietary_pattern_str}")
                    dietary_pattern_code = DietPatternConfig.get_code(nutritional_prescription_dietary_pattern_str)
                    dietary_pattern_str = nutritional_prescription_dietary_pattern_str
                else:
                    logger.warning(f"【主进程】接口提供的膳食模式名称 与 分析的膳食模式一致，使用分析出的膳食模式，膳食模式：{dietary_pattern_str}")
            else:
                logger.warning(f"【主进程】接口提供的膳食模式名称不在合法的膳食模型名称中(1)，使用分析出的膳食模式，膳食模式：{dietary_pattern_str}")
        else:
            logger.info(f"【主进程】接口未提供膳食模式名称，判断是否提供膳食模式编码{nutritional_prescription_dietary_pattern_code}")
            if nutritional_prescription_dietary_pattern_code:
                logger.info(f"【主进程】接口提供膳食模式编码，膳食模式编码：{nutritional_prescription_dietary_pattern_code}")
                temp_diet_pattern_name = DietPatternConfig.get_name(nutritional_prescription_dietary_pattern_code)
                logger.info(f"【主进程】接口提供膳食模式编码，对应的名称为：{temp_diet_pattern_name}")
                if temp_diet_pattern_name:
                    if temp_diet_pattern_name != dietary_pattern_str:
                        logger.info(f"【主进程】接口提供的膳食模式名称(编码获取)与分析出的膳食模式名称不一致！！！！"
                                    f"使用接口提供的膳食模式(编码获取)，膳食模式：{temp_diet_pattern_name}，"
                                    f"分析出的膳食模式：{dietary_pattern_str}")
                    else:
                        logger.info(
                            f"【主进程】接口提供的膳食模式名称 与 分析的膳食模式一致，使用分析出的膳食模式，膳食模式：{dietary_pattern_str}")

                    logger.info(f"【主进程】接口提供的膳食模式编码对应的名称为：{temp_diet_pattern_name}")

                    dietary_pattern_code = nutritional_prescription_dietary_pattern_code
                    dietary_pattern_str = temp_diet_pattern_name
                else:
                    logger.warning(f"【主进程】接口提供的膳食模式名称不在合法的膳食模型名称中(2)，使用分析出的膳食模式，膳食模式：{dietary_pattern_str}")
            else:
                logger.info(f"【主进程】接口未提供膳食模式编码，使用分析出的膳食模式，膳食模式：{dietary_pattern_str}")


        user_info_json["dietary_pattern"] = dietary_pattern_code
        user_info_json["dietary_pattern_name"] = dietary_pattern_str
        logger.info(f"【主进程】-- 膳食模式-- 最终使用的，膳食模式：{dietary_pattern_str}，编码:{dietary_pattern_code}")

        analyse_preference_cons_dict = {
            # 膳食模式
            "dietary_pattern": dietary_pattern_str,
            # 自我描述
            "user_self_report": user_self_report,
            # 饮食历史
            "diet_history_str": diet_history_str,
            # 饮食建议
            "dietary_advice_str": dietary_advice_str,
            # 用户信息
            "user_info_json": user_info_json
        }
        preference_obj = analyse_preference_by_execute_llm_by_cons(analyse_preference_cons_dict)


        health_risk_set = analyse_disease_by_execute_llm_by_cons(analyse_preference_cons_dict)
        if not health_risk_set or len(health_risk_set) == 0:
            health_risk_set.add("无")
        user_info_json["health_risk_arr"] = list(health_risk_set)
        user_info_json["user_self_report"] = user_self_report


        if user_province:
            user_info_json["user_province"] = user_province

        alternative_food_library = solver_main_process(preference_obj, user_info_json)


        return ResultManager.success("访问成功！", {
            "alternative_foods": alternative_food_library["alternative_foods"],
            "alternative_foods_size": len(alternative_food_library["alternative_foods"]),
            "food_type_matching": alternative_food_library["food_type_matching"],
            "food_category_preferences_and_suitability": alternative_food_library["food_category_preferences_and_suitability"],
            "user_info": user_info_json
        })

    except Exception as e:
        logger.error(f"【主进程】主进程执行失败，{e}")

    return ResultManager.error("主进程执行失败")



def handle_request(llm_require_str: str) -> list[Any]:
    futures = [
        executor.submit(main_process_analyse_preference_thread,  llm_require_str),
        executor.submit(main_process_analyse_dietary_pattern_thread,  llm_require_str)
    ]
    return futures  # 先返回 future，不阻塞


def main_process_analyse_preference_thread(llm_require_str: str) -> dict:

    preference_obj = analyse_preference_by_execute_llm_by_cons(llm_require_str)
    return {
        "thread_type": "preference",
        "data": preference_obj,
    }

def main_process_analyse_dietary_pattern_thread(llm_require_str: str) -> dict:

    dietary_pattern_obj_thread = analyse_dietary_pattern_by_execute_llm_by_cons(llm_require_str)
    return {
        "thread_type": "dietary_pattern",
        "data": dietary_pattern_obj_thread,
    }



def solver_main_process(constraint_params: dict, user_info_json:dict):
   
    start_time = time.time()
    logger.info("==============================量化食物图谱推理器主进程(开始)======================================")
    
    constraint_params['user_health_risk_arr'] = user_info_json.get('health_risk_arr', None)
    alternative_food_arr, preference_food_list \
        = load_alternative_food_library_by_cons(constraint_params)

   
    constraint_params['user_province'] = user_info_json.get('user_province', None)
    quantify_dietary_preferences_food_arr \
        = quantify_dietary_preferences_by_cons(constraint_params, alternative_food_arr, preference_food_list)

    
    final_food_arr = quantify_appropriateness_of_food_meals(quantify_dietary_preferences_food_arr)
    alternative_foods = {}
    for food in final_food_arr:
        alternative_foods[food["id"]] = food

    quantify_food_category_preferences_and_suitability_result_arr \
        = quantify_food_category_preferences_and_suitability_by_cons(constraint_params, alternative_food_arr)
    exists_food_category_obj = {}
    for food in quantify_food_category_preferences_and_suitability_result_arr:
        exists_food_category_obj[food[Constants.ENTITY_FOOD_CATEGORY_FIELD_NAME]] = food


   
    suitability_of_food_combinations = quantify_suitability_of_food_combinations(exists_food_category_obj)

    logger.info(f"---【量化食物图谱推理器主进程耗时】：{time.time() - start_time:.2f} 秒")
    logger.info("==============================量化食物图谱推理器主进程(结束)======================================")

    return {
        "food_type_matching": suitability_of_food_combinations,
        "alternative_foods": alternative_foods,
        "food_category_preferences_and_suitability": quantify_food_category_preferences_and_suitability_result_arr,
    }

if __name__ == '__main__':
    print('---start---')