import json
import sys
import time
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from clazz.common.common_utils import CommonUtils
from clazz.utils.logger_util import logger

def diet_solver_schedule_main_function():
    from src.util.sync_work_process_database_util import (
        check_is_running,
        query_waiting_deal_dietary_solution_history,
        update_dietary_solution_history_status,
        save_dietary_solution_history_result)
    from src.work_process import solver_diet_main_function

    history_id = None
    try:
        success_flag = False

        if not check_is_running():
            logger.info("【求解器-定时任务-获取七日饮食数据】---有正在运行的求解任务，等待下次执行...")
            return

        history = query_waiting_deal_dietary_solution_history()
        if not history:
            logger.info("【求解器-定时任务-获取七日饮食数据】---没有等待处理的饮食求解历史，等待下次执行...")
            return

        history_id = history['id']
        update_dietary_solution_history_status(history_id, '1')

        params_json = json.loads(history['content'])

        result_json = solver_diet_main_function('0.0.0.0',params_json)

        if result_json and result_json.get('code', 0) == 200:
            success_flag = True

            data_obj = result_json.get('data')
            data_str = CommonUtils.json_data_to_str(data_obj)
            save_dietary_solution_history_result(history_id, data_str)

        logger.info(f"【求解器-定时任务-获取七日饮食数据】---success_flag:{success_flag}")
        if success_flag:
            update_dietary_solution_history_status(history_id, '2')
        else:
            logger.error(f"【求解器-定时任务-获取七日饮食数据】---求解失败,{result_json}")
            update_dietary_solution_history_status(history_id, '-1')
    except Exception as e:
        logger.error(f"【求解器-定时任务-获取七日饮食数据】---访问失败,{e}")
        if history_id:
            update_dietary_solution_history_status(history_id, '-1')
