import json
import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from clazz.common.common_utils import CommonUtils
from clazz.utils.logger_util import logger
from clazz.common.result_manager_class import ResultManager

def diet_solver_inter_by_serial_number(client_ip: str, params_json: dict):
    from src.util.sync_work_process_database_util import (
        query_dietary_solution_history_detail_by_serial_number,
        save_dietary_solution_history_result)
    from src.work_process import solver_diet_main_function

    return_serial_number = CommonUtils.get_uuid()
    try:
        success_flag = False

        if not params_json or 'serial_number' not in params_json:
            return ResultManager.error_with_code(406, "参数错误，请检查流水号(serial_number)", None, return_serial_number)

        serial_number = params_json['serial_number']
        history = query_dietary_solution_history_detail_by_serial_number(serial_number)
        if not history:
            return ResultManager.error_with_code(406, "求解历史为空，请检查流水号", None, return_serial_number)

        logger.info(f"history:{history}")
        history_id = history['id']
        params_json = json.loads(history['content'])

        result_json = solver_diet_main_function(client_ip, params_json)

        if result_json and result_json.get('code', 0) == 200:
            success_flag = True

            data_obj = result_json.get('data')
            data_str = CommonUtils.json_data_to_str(data_obj)
            save_dietary_solution_history_result(history_id, data_str)

        logger.info(f"【求解器-调用接口-获取七日饮食数据】---success_flag:{success_flag}")
        if success_flag:
            return ResultManager.success("求解成功", None, return_serial_number)
        else:
            logger.error(f"【求解器-调用接口-获取七日饮食数据】---求解失败,{result_json}")
            return ResultManager.error_with_code(406, "求解失败", None, return_serial_number)
    except Exception as e:
        logger.error(f"【求解器-调用接口-获取七日饮食数据】---访问失败,{e}")
        return ResultManager.error_with_code(407, "求解失败", None, return_serial_number)
