import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from config.constants import Constants
from clazz.utils.logger_util import logger

from src.util.database_util import load_all_drug_ingredient_taboo
from src.util.main_execute_llm_fun import analyse_take_drug_status_execute_llm_by_cons

THIS_REASONER_MODULE_NAME = "根据用户服药情况推理出不允许食用的食材"



def analyse_take_drug_to_forbidden_ingredients(constraint_params: dict) -> dict:
    logger.info(f'【推理器】---{THIS_REASONER_MODULE_NAME}----开始')
    
    user_info_json = constraint_params.get("user_info_json", None)
    if user_info_json is None:
        logger.error(f'【推理器】---{THIS_REASONER_MODULE_NAME}----用户信息为空')
        return None
    
    take_drug_status = user_info_json.get("medication_status", None)
    if take_drug_status is None:
        logger.error(f'【推理器】---{THIS_REASONER_MODULE_NAME}----用户服药情况为空')
        return None
    
    result_list = analyse_take_drug_status_execute_llm_by_cons({
        "take_drug_status": take_drug_status
    })
    if result_list is None:
        logger.error(f'【推理器】---{THIS_REASONER_MODULE_NAME}----调用模型分析服药情况失败')
        return None
    
    drug_name_set = set()
    drug_class_set = set()
    filtered_result_list = []
    for item in result_list:
        if type(item) == dict:
            filtered_result_list.append(item)
        elif type(item) == list:
            filtered_result_list.extend(item)

    for item in filtered_result_list:
        standard_name = item.get("standard_name", None)
        class_name = item.get("category", None)
        if standard_name:
            drug_name_set.add(standard_name)
        if class_name:
            drug_class_set.add(class_name)

    taboo_ingredient_list = load_all_drug_ingredient_taboo()
    if not taboo_ingredient_list:
        logger.error(f'【推理器】---{THIS_REASONER_MODULE_NAME}----获取药品禁忌食材失败')
        return None
    
    ingredient_name_set = set()

    if drug_name_set and len(drug_name_set) > 0:
        for taboo_item in taboo_ingredient_list:
            drug_name = taboo_item.get("drug_name", None)
            for name in drug_name_set:
                if name in drug_name or drug_name in name:
                    ingredient_name_set.add(taboo_item['ing_name'])
    if drug_class_set and len(drug_class_set) > 0:
        for taboo_item in taboo_ingredient_list:
            drug_class = taboo_item.get("drug_class", None)
            for class_name in drug_class_set:
                if class_name in drug_class or drug_class in class_name:
                    ingredient_name_set.add(taboo_item['ing_name'])

    logger.info(f'【推理器】---{THIS_REASONER_MODULE_NAME}----根据用户服药情况推理出不允许食用的食材：{len(ingredient_name_set)}')
    logger.info(f'【推理器】---{THIS_REASONER_MODULE_NAME}----结束')
    return {
        "forbidden_ingredient_set": ingredient_name_set
    }
