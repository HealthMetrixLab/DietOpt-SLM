import sys
import time
from pathlib import Path



project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from src.util.database_util import load_meal_suitability
from clazz.utils.logger_util import logger


def quantify_appropriateness_of_food_meals(alternative_food_arr: list) -> list:
    start_time = time.time()

    meal_suitability_list = load_meal_suitability()
    meal_suitability_dict = {}
    for item in meal_suitability_list:
        meal_suitability_dict[item["food_id"]] = item

    for item in alternative_food_arr:
        food_id = item["id"]
        if food_id not in meal_suitability_dict:
            continue

        meal_suitability = meal_suitability_dict[food_id]

        breakfast_suit_weight = float(meal_suitability["breakfast_suit_weight"])
        lunch_suit_weight = float(meal_suitability["lunch_suit_weight"])
        dinner_suit_weight = float(meal_suitability["dinner_suit_weight"])
        extra_suit_weight = float(meal_suitability["extra_suit_weight"])

        item["breakfast_suit_weight"] = breakfast_suit_weight
        item["lunch_suit_weight"] = lunch_suit_weight
        item["dinner_suit_weight"] = dinner_suit_weight
        item["extra_suit_weight"] = extra_suit_weight

    return  alternative_food_arr