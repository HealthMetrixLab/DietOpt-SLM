import sys
import time
from pathlib import Path



project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from src.util.database_util import load_all_food_entity_threaded
from src.util.knowledge_graph_util import load_food_list_by_cons,load_forbidden_food_list_by_food_label,\
                            load_alter_food_data_by_user_disease
from clazz.utils.logger_util import logger
from config.constants import Constants
from config.reasoning_constraint_config.food_label_forbidden_for_chronic_diseases_config import FoodLabelForbiddenForChronicDiseasesConfig
from config.reasoning_constraint_config.disease_selection_priority_config import DiseaseSelectionPriorityConfig


def load_alternative_food_library_by_cons(constraint_params: dict):
   

    start_time = time.time()
    logger.info("==============================加载备选食物库(开始)======================================")

    personal_preference = constraint_params['personal_preference']
    area_preference = constraint_params['area_preference']
    forbidden_ingredients = constraint_params['forbidden_ingredients']
    forbidden_cooking = constraint_params['forbidden_cooking']
    forbidden_taste = constraint_params['forbidden_taste']

    forbidden_label = constraint_params['forbidden_label'] if 'forbidden_label' in constraint_params else set()
    logger.info(f"【备选食物库】------禁忌食物标签：{len(forbidden_label)}")
    logger.info(f"【备选食物库】------禁忌食物标签：{forbidden_label}")
    forbidden_label.update(forbidden_ingredients)
    forbidden_label.update(forbidden_cooking)
    forbidden_label.update(forbidden_taste)
    logger.info(f"【备选食物库】------禁忌食物标签（添加禁忌食材等信息后）：{len(forbidden_label)}")
    logger.info(f"【备选食物库】------禁忌食物标签（添加禁忌食材等信息后）：{forbidden_label}")
    
    ingredients_of_personal_preference = personal_preference['ingredients'] or set()
    cooking_of_personal_preference = personal_preference['cooking'] or set()
    taste_of_personal_preference = personal_preference['taste'] or set()

    ingredients_of_area_preference = area_preference['ingredients'] or set()
    cooking_of_area_preference = area_preference['cooking'] or set()
    taste_of_area_preference = area_preference['taste'] or set()


    ingredients_of_union = ingredients_of_personal_preference | ingredients_of_area_preference
    cooking_of_union = cooking_of_personal_preference | cooking_of_area_preference
    taste_of_union = taste_of_personal_preference | taste_of_area_preference

    user_health_risk_arr = constraint_params['user_health_risk_arr'] or set()

    disease_priority, disease_priority_name = \
        DiseaseSelectionPriorityConfig.get_disease_selection_priority_by_disease_name(user_health_risk_arr)
    logger.info(f"【备选食物库】------疾病名称：{disease_priority_name}")
    logger.info(f"【备选食物库】------疾病优先级：{disease_priority}")
    

    preference_food_list = load_food_list_by_cons(ingredients_of_union, cooking_of_union, taste_of_union)

    

    forbidden_food_list = load_food_list_by_cons(forbidden_ingredients, forbidden_cooking, forbidden_taste, "1")
    forbidden_food_ids = {food["food_id"] for food in forbidden_food_list}
    logger.info(f"【备选食物库】------forbidden 食物总数量：{len(forbidden_food_ids)}")

    user_disease_alter_food_list = []

    label_filter_flag = True

    if disease_priority_name:
        logger.info(f"【备选食物库】------根据疾病选择可选食物库,疾病名称：{disease_priority_name}")
        user_disease_alter_food_list = load_alter_food_data_by_user_disease(disease_priority_name)
        logger.info(f"【备选食物库】------根据疾病选择可选食物库，可选食物数量：{len(user_disease_alter_food_list)}")
        if len(user_disease_alter_food_list) > 0:
            label_filter_flag = False
    logger.info(f"【备选食物库】------是否进行食物标签过滤：{label_filter_flag}")
    label_filter_flag = False
    if label_filter_flag:
        if user_health_risk_arr and len(user_health_risk_arr) > 0:
            try:
                disease_forbidden_labels = \
                    FoodLabelForbiddenForChronicDiseasesConfig.get_forbidden_food_label_list(",".join(user_health_risk_arr))
                logger.info(f"【备选食物库】------疾病相关的禁忌食物标签：{disease_forbidden_labels}")
                if disease_forbidden_labels and len(disease_forbidden_labels) > 0:
                    forbidden_label.update(set(disease_forbidden_labels) - forbidden_label)
            except Exception as e:
                logger.error(f"【备选食物库】------根据疾病名称获取疾病相关的禁忌食物标签失败：{e}")
                disease_forbidden_labels = []

        forbidden_label_food_list = \
            load_forbidden_food_list_by_food_label(forbidden_label)
        logger.info(f"【备选食物库】------食物标签对应的forbidden食物数量：{len(forbidden_label_food_list)}")

        forbidden_food_ids.update({food["food_id"] for food in forbidden_label_food_list})
        logger.info(f"【备选食物库】------forbidden 食物总数量(添加食物禁忌标签过滤)：{len(forbidden_food_ids)}")
        
    start_query_all_food_time = time.time()
    all_food_data_list = load_all_food_entity_threaded(user_disease_alter_food_list)
    logger.info(f"【备选食物库】------加载所有食物数据耗时：{time.time() - start_query_all_food_time:.2f} 秒, 食物总数：{len(all_food_data_list)}")

    alternative_food_arr = []
    for food in all_food_data_list:
        if not food["food_id"]:
            logger.error(f"【备选食物库】------food_id为空：{food}")
            continue

        if food["id"] in forbidden_food_ids:
            continue
        
        alternative_food_arr.append(food)
            

    logger.info(f"【备选食物库】------可选食物集合大小：{len(alternative_food_arr)}")
    start_deal_alternative_food_time = time.time()
    final_alternative_food_arr = deal_alternative_food(alternative_food_arr)
    logger.info(f"【备选食物库】------耗时：{time.time() - start_deal_alternative_food_time:.2f} 秒")

    logger.info(f"【备选食物库】------"
            f"食物总数：{len(all_food_data_list)}，"
            f"可选食物集合数量：{len(final_alternative_food_arr)}，"
            f"偏好食物集合数量：{len(preference_food_list)}，"
            f"forbidden集合：{len(forbidden_food_ids)}")

    category_count_map = {}
    for food in final_alternative_food_arr:
        category_name = food["food_category"]
        if category_name in category_count_map:
            category_count_map[category_name] += 1
        else:
            category_count_map[category_name] = 1

    logger.info(f"【备选食物库】------各类别食物数量统计：")

    for category_name in sorted(category_count_map.keys()):
        count = category_count_map[category_name]
        logger.info(f"类别：{category_name}，数量：{count}")

    logger.info(f"【备选食物库】------耗时：{time.time() - start_time:.2f} 秒")
    logger.info("==============================加载备选食物库(结束)======================================")


    return final_alternative_food_arr, preference_food_list

def deal_alternative_food(alternative_food_arr):
    """
    处理备选食物库
    :param alternative_food_arr:
    :return:
    """
    error_food_size = 0
    final_result = []



    for food in alternative_food_arr:
        required_ingredient_ids = []
        if "required_ingredient_ids" in food and food["required_ingredient_ids"]:
            required_ingredient_ids = food["required_ingredient_ids"].split(",")

        new_food = {
            "id": food["id"],
            "food_id": food["food_id"],
            "name": food["entity_name"],
            "taste_name": food["food_taste"],
            "cuisine": food["food_cuisine"],
            #"required_ingredient_ids": required_ingredient_ids,
            "personal_preference_weight": 0.0,
            "regional_preference_weight": 0.0,
            "breakfast_suit_weight": 0.0,
            "lunch_suit_weight": 0.0,
            "dinner_suit_weight": 0.0,
            "extra_suit_weight": 0.0,
        }
        if food[Constants.ENTITY_FOOD_CATEGORY_FIELD_NAME]:
            food_category = food[Constants.ENTITY_FOOD_CATEGORY_FIELD_NAME]

            temp_arr = food_category.split("_")
            new_food["category_name"] = temp_arr
            new_food["food_category"] = food_category
        else:
            new_food["category_name"] = '未知'
            new_food["food_category"] = '其他'

        if food["food_unit"] and food["food_unit"] != "None":
            food_unit = food["food_unit"]

            food_unit = float(food_unit)

            calories = float(food["calories"]) if food["calories"] else 0
            protein = float(food["protein"]) if food["protein"] else 0
            fat = float(food["fat"]) if food["fat"] else 0
            carbo = float(food["carbo"]) if food["carbo"] else 0

            nutrition = {
                "calories": calories,
                "protein": protein,
                "fat": fat,
                "carbo": carbo,
            }
            new_food["nutrition"] = nutrition
            new_food["nutrition_unit"] = food_unit

            for key in new_food.keys():
                if not new_food[key] or new_food[key] == "None" or new_food[key] == "none":
                    if type(new_food[key]) is str:
                        new_food[key] = ""
            final_result.append(new_food)
        else:
            error_food_size += 1


    logger.info(f"【备选食物库】------处理备选食物库，错误食物数量：{error_food_size}")
    return final_result







if __name__ == '__main__':
    params = {
        'personal_preference':
            {'ingredients':{'三文鱼','鲭鱼','燕麦','橄榄油'},
             'cooking':{'蒸','煮','气炸','炖'},
             'taste':{'清淡','少糖','少油'}
             },
        'area_preference':
            {'ingredients':{'小麦','茄子','水稻','玉米','白菜','萝卜','猪肉','鲤鱼','羊肉','鸡肉','鲫鱼','豆角','大葱','牛肉'},
             'cooking':{'爆','烧','炖','蒸','炒'},
             'taste':{'咸','鲜'}
             },
        'forbidden_ingredients':{'豆类','高汞鱼','精制碳水','加工肉','含糖饮料','甜点','生食'},
        'forbidden_cooking':{'油炸','糖浆挂糊','裹粉炸','深炸','腌','熏','复炸','卤'},
        'forbidden_taste':{},
        'user_province':'A省B市'
    }
    alternative_food_arr_1, preference_food_list_1 \
        = load_alternative_food_library_by_cons(params)
