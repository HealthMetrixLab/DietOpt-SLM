import math
import sys
import time
from pathlib import Path



project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from src.util.database_util import load_entity_list, load_all_home_cooked_food_list,load_user_suit_suisine
from src.util.knowledge_graph_util import load_food_list_by_food_label

from config.constants import Constants
from config.reasoning_constraint_config.food_label_suitable_for_chronic_diseases_config import FoodLabelSuitableForChronicDiseasesConfig

from clazz.utils.logger_util import logger


def quantify_dietary_preferences_by_cons(
        constraint_params: dict,
        alternative_food_arr: list,
        preference_food_list: list):

    start_time = time.time()
    logger.info("==============================量化食物偏好权重(开始)======================================")
    personal_preference = constraint_params['personal_preference']
    area_preference = constraint_params['area_preference']

    ingredients_of_personal_preference = personal_preference['ingredients'] or set()
    cooking_of_personal_preference = personal_preference['cooking'] or set()
    taste_of_personal_preference = personal_preference['taste'] or set()

    ingredients_of_area_preference = area_preference['ingredients'] or set()
    cooking_of_area_preference = area_preference['cooking'] or set()
    taste_of_area_preference = area_preference['taste'] or set()

    ingredients_of_area_and_personal_preference = ingredients_of_area_preference & ingredients_of_personal_preference
    cooking_of_area_and_personal_preference = cooking_of_area_preference & cooking_of_personal_preference
    taste_of_area_and_personal_preference = taste_of_area_preference & taste_of_personal_preference

    ingredients_entity_list = load_entity_list(ingredients_of_personal_preference, Constants.INGREDIENT_ENTITY_TYPE_NAME)
    cooking_entity_list = load_entity_list(cooking_of_personal_preference, Constants.COOKING_ENTITY_TYPE_NAME)
    taste_entity_list = load_entity_list(taste_of_personal_preference, Constants.TASTE_ENTITY_TYPE_NAME)

    ingredients_personal_preference_entity_name_list = load_entity_name_list_from_entity_list(ingredients_entity_list)
    cooking_personal_preference_entity_name_list = load_entity_name_list_from_entity_list(cooking_entity_list)
    taste_personal_preference_entity_name_list = load_entity_name_list_from_entity_list(taste_entity_list)


    ingredients_entity_list = load_entity_list(ingredients_of_area_preference,Constants.INGREDIENT_ENTITY_TYPE_NAME)
    cooking_entity_list = load_entity_list(cooking_of_area_preference, Constants.COOKING_ENTITY_TYPE_NAME)
    taste_entity_list = load_entity_list(taste_of_area_preference, Constants.TASTE_ENTITY_TYPE_NAME)

    ingredients_area_preference_entity_name_list = load_entity_name_list_from_entity_list(ingredients_entity_list)
    cooking_area_preference_entity_name_list = load_entity_name_list_from_entity_list(cooking_entity_list)
    taste_area_preference_entity_name_list = load_entity_name_list_from_entity_list(taste_entity_list)

    home_cooked_food_entity_list = load_all_home_cooked_food_list()
    home_cooked_food_check_obj = {}
    if home_cooked_food_entity_list:
        for home_cooked_food in home_cooked_food_entity_list:
            home_cooked_food_check_obj[home_cooked_food['food_id']] = 1

    logger.info(f'【量化食物偏好权重值】------家常菜食物集合: {len(home_cooked_food_entity_list)}')

    user_suit_cuisine_list = []
    user_province = constraint_params.get('user_province', None)
    if user_province:
        user_suit_cuisine_list = load_user_suit_suisine(user_province)
    logger.info(f'【量化食物偏好权重值】------用户适宜的菜系: {user_suit_cuisine_list}')

    suitable_food_label_obj = {}
    user_health_risk_arr = constraint_params.get('user_health_risk_arr', None)
    if user_health_risk_arr and len(user_health_risk_arr) > 0:
        logger.info(f'【量化食物偏好权重值】------用户的疾病: {user_health_risk_arr}')
        user_health_risk_str = ','.join(user_health_risk_arr)
        suitable_food_label_list = \
            FoodLabelSuitableForChronicDiseasesConfig.get_suitable_food_label_list(user_health_risk_str)
        logger.info(f'【量化食物偏好权重值】------用户适宜的食物标签: {len(suitable_food_label_list)}')
        if suitable_food_label_list and len(suitable_food_label_list) > 0:
            logger.info(f'【量化食物偏好权重值】------用户适宜的食物标签: {suitable_food_label_list}')
            suitable_food_list = load_food_list_by_food_label(suitable_food_label_list)
            if suitable_food_list:
                for suitable_food in suitable_food_list:
                    if suitable_food['food_id'] not in suitable_food_label_obj:
                        suitable_food_label_obj[suitable_food['food_id']] = []
                    suitable_food_label_obj[suitable_food['food_id']].append(suitable_food[Constants.TARGET_ENTITY_NAME_FIELD_NAME])
    check_preference_obj = {}
    if preference_food_list:
        for preference_food in preference_food_list:
            check_preference_obj[preference_food['food_id']] = preference_food

    preference_food_id_list = check_preference_obj.keys()

    check_personal_preference_obj = {}
    check_area_preference_obj = {}

    other_quantify_params = {
        'home_cooked_food_check_obj': home_cooked_food_check_obj,
        'user_suit_cuisine_list': user_suit_cuisine_list,
    }

    if alternative_food_arr:
        for food in alternative_food_arr:
            food_id = food['id']
            preference_food = food

            if food_id in preference_food_id_list:
                preference_food = check_preference_obj[food_id]
                preference_food['id'] = food_id

            extra_add_score = 0
            extra_params_dict = {
                'suitable_food_label_obj': suitable_food_label_obj,
            }
            extra_add_score += deal_extra_add_score_by_params(food_id, extra_params_dict)

            personal_preference_weight = calculate_quantify_personal_dietary_preferences_by_cons(
                ingredients_personal_preference_entity_name_list,
                cooking_personal_preference_entity_name_list,
                taste_personal_preference_entity_name_list,
                ingredients_of_area_and_personal_preference,
                cooking_of_area_and_personal_preference,
                taste_of_area_and_personal_preference,
                preference_food,
                extra_add_score,
                other_quantify_params,
                "personal")

            area_preference_weight = calculate_quantify_personal_dietary_preferences_by_cons(
                ingredients_area_preference_entity_name_list,
                cooking_area_preference_entity_name_list,
                taste_area_preference_entity_name_list,
                ingredients_of_area_and_personal_preference,
                cooking_of_area_and_personal_preference,
                taste_of_area_and_personal_preference,
                preference_food,
                extra_add_score,
                other_quantify_params,
                "area")

            food['personal_preference_weight'] = personal_preference_weight
            food['regional_preference_weight'] = area_preference_weight

            temp_value = 1
            if personal_preference_weight in check_personal_preference_obj:
                temp_value = check_personal_preference_obj[personal_preference_weight]
            check_personal_preference_obj[personal_preference_weight] = temp_value + 1

            temp_value = 1
            if area_preference_weight in check_area_preference_obj:
                temp_value = check_area_preference_obj[area_preference_weight]
            check_area_preference_obj[area_preference_weight] = temp_value + 1


        logger.info(f"【量化食物偏好权重值】------耗时：{time.time() - start_time:.2f} 秒")
        logger.info("==============================量化食物偏好权重(结束)======================================")
    return alternative_food_arr

def deal_extra_add_score_by_params(food_id: str, params_json: dict) -> int:
    extra_score_total = 0
    if not food_id:
        return extra_score_total
    if not params_json or len(params_json) == 0:
        return extra_score_total
    suitable_food_label_obj = params_json['suitable_food_label_obj']
    if food_id in suitable_food_label_obj:
        temp_label_arr = suitable_food_label_obj[food_id]
        if not temp_label_arr:
            temp_label_arr = []
        extra_score_total += len(temp_label_arr) * Constants.HIT_FOOD_LABEL_SCORE 
        if len(temp_label_arr) >= Constants.MULTI_HIT_FOOD_LABEL_THRESHOLD:
            extra_score_total += (len(temp_label_arr) - Constants.MULTI_HIT_FOOD_LABEL_THRESHOLD + 1) \
                            * Constants.MULTI_HIT_FOOD_LABEL_EXTRA_SCORE
    
    return extra_score_total

def calculate_quantify_personal_dietary_preferences_by_cons(
    ingredients_preference: set,
    cooking_preference: set,
    taste_preference: set,
    ingredients_of_area_and_personal_preference: set,
    cooking_of_area_and_personal_preference: set,
    taste_of_area_and_personal_preference: set,
    food: dict,
    extra_add_score: int,
    other_quantify_params: dict,
    preference_type: str = "personal") -> float:

    hit_ingredients = []
    hit_cooking = []
    hit_taste = []

    if "hit_ingredients" in food:
        hit_ingredients = food["hit_ingredients"]
    if "hit_cooking" in food:
        hit_cooking = food["hit_cooking"]
    if "hit_taste" in food:
        hit_taste = food["hit_taste"]

    hit_category_size = 0


    ingredients_score = 0

    hit_size = 0
    if hit_ingredients and len(hit_ingredients) > 0:
        for ingredient in hit_ingredients:
            if ingredient in ingredients_preference:
                hit_size += 1
                if ingredient in ingredients_of_area_and_personal_preference:
                    ingredients_score += Constants.HIT_ALL_INGREDIENT_SCORE
                else:
                    ingredients_score += Constants.HIT_PERSONAL_INGREDIENT_SCORE

        if hit_size > 1:
            count = Constants.MAX_MULTI_HIT_INGREDIENT_TIMES if hit_size > Constants.MAX_MULTI_HIT_INGREDIENT_TIMES else hit_size
            ingredients_score += Constants.MULTI_HIT_INGREDIENT_EXTRA_SCORE * (count - 1)

        if hit_size > 0:
            hit_category_size += 1

    if preference_type == "personal":
        if ingredients_score > Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_INGREDIENT:
            ingredients_score = Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_INGREDIENT

        ingredients_score += Constants.PERSONAL_INGREDIENT_BASE_SCORE
    else:
        if ingredients_score > Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_INGREDIENT:
            ingredients_score = Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_INGREDIENT

        ingredients_score += Constants.AREA_INGREDIENT_BASE_SCORE


    cooking_score = 0
    hit_size = 0
    if hit_cooking and len(hit_cooking) > 0:
        for cooking in hit_cooking:
            if cooking in cooking_preference:
                hit_size += 1
                if cooking in cooking_of_area_and_personal_preference:
                    cooking_score += Constants.HIT_ALL_COOKING_SCORE
                else:
                    cooking_score += Constants.HIT_PERSONAL_COOKING_SCORE

        if hit_size > 1:
            count = Constants.MAX_MULTI_HIT_COOKING_TIMES if hit_size > Constants.MAX_MULTI_HIT_COOKING_TIMES else hit_size
            cooking_score += Constants.MULTI_HIT_COOKING_EXTRA_SCORE * (count - 1)

        if hit_size > 0:
            hit_category_size += 1


    if preference_type == "personal":
        if cooking_score > Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_COOKING:
            cooking_score = Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_COOKING

        cooking_score += Constants.PERSONAL_COOKING_BASE_SCORE
    else:
        if cooking_score > Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_COOKING:
            cooking_score = Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_COOKING

        cooking_score += Constants.AREA_COOKING_BASE_SCORE

    """
    3、量化口味偏好
    """
    taste_score = 0
    hit_size = 0
    if hit_taste and len(hit_taste) > 0:
        for taste in hit_taste:
            if taste in taste_preference:
                hit_size += 1
                if taste in taste_of_area_and_personal_preference:
                    taste_score += Constants.HIT_ALL_TASTE_SCORE
                else:
                    taste_score += Constants.HIT_PERSONAL_TASTE_SCORE

        if hit_size > 1:
            count = Constants.MAX_MULTI_HIT_TASTE_TIMES if hit_size > Constants.MAX_MULTI_HIT_TASTE_TIMES else hit_size
            taste_score += Constants.MULTI_HIT_TASTE_EXTRA_SCORE * (count - 1)

        if hit_size > 0:
            hit_category_size += 1

    if preference_type == "personal":
        if taste_score > Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_TASTE:
            taste_score = Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_TASTE

        taste_score += Constants.PERSONAL_TASTE_BASE_SCORE
    else:
        if taste_score > Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_TASTE:
            taste_score = Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_TASTE

        taste_score += Constants.AREA_TASTE_BASE_SCORE


    if other_quantify_params:
        home_cooked_food_check_obj = other_quantify_params.get('home_cooked_food_check_obj', None)
        user_suit_cuisine_list = other_quantify_params.get('user_suit_cuisine_list', None)

        if home_cooked_food_check_obj and home_cooked_food_check_obj.get(food['id'], None):
            extra_add_score += Constants.HOME_COOKED_FOOD_SCORE


        if preference_type == "personal":
            pass
        else:
            pass

        if user_suit_cuisine_list and len(user_suit_cuisine_list) > 0:
            food_cuisine = food.get('cuisine', None)
            if food_cuisine:
                exist_food_cuisine_arr = food_cuisine.split(',')
                temp_merge_arr = set(exist_food_cuisine_arr) & set(user_suit_cuisine_list)
                if len(temp_merge_arr) > 0:
                    extra_add_score += Constants.HIT_CUISINE_SCORE

    base_score = 0
    max_score = 0
    weight_score = 0
    hit_category_score = 0

    if preference_type == "personal":
        hit_category_score = hit_category_size * Constants.HIT_PERSONAL_CATEGORY_SCORE

        weight_score = ingredients_score * Constants.PERSONAL_INGREDIENT_PREFERENCE_WEIGHT + \
                       cooking_score * Constants.PERSONAL_COOKING_PREFERENCE_WEIGHT + \
                       taste_score * Constants.PERSONAL_TASTE_PREFERENCE_WEIGHT + \
                       hit_category_score * Constants.PERSONAL_HIT_CATEGORY_WEIGHT

        base_score =\
            Constants.PERSONAL_INGREDIENT_BASE_SCORE + Constants.PERSONAL_COOKING_BASE_SCORE + \
            Constants.PERSONAL_TASTE_BASE_SCORE + extra_add_score


        max_score = base_score + \
                    hit_category_score * Constants.PERSONAL_HIT_CATEGORY_WEIGHT + \
                    Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_INGREDIENT * Constants.PERSONAL_INGREDIENT_PREFERENCE_WEIGHT + \
                    Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_COOKING * Constants.PERSONAL_COOKING_PREFERENCE_WEIGHT + \
                    Constants.MAX_PERSONAL_PREFERENCE_SCORE_OF_HIT_TASTE * Constants.PERSONAL_TASTE_PREFERENCE_WEIGHT +\
                    Constants.SPECIAL_FOOD_SCORE_COUNT
    else:
        hit_category_score = hit_category_size * Constants.HIT_AREA_CATEGORY_SCORE

        weight_score = ingredients_score * Constants.AREA_INGREDIENT_PREFERENCE_WEIGHT + \
                       cooking_score * Constants.AREA_COOKING_PREFERENCE_WEIGHT + \
                       taste_score * Constants.AREA_TASTE_PREFERENCE_WEIGHT + \
                       hit_category_score * Constants.PERSONAL_HIT_CATEGORY_WEIGHT

        base_score =\
            Constants.AREA_INGREDIENT_BASE_SCORE + Constants.AREA_COOKING_BASE_SCORE + \
            Constants.AREA_TASTE_BASE_SCORE + extra_add_score

        max_score = base_score + \
                    hit_category_score * Constants.AREA_HIT_CATEGORY_WEIGHT + \
                    Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_INGREDIENT * Constants.AREA_INGREDIENT_PREFERENCE_WEIGHT + \
                    Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_COOKING * Constants.AREA_COOKING_PREFERENCE_WEIGHT + \
                    Constants.MAX_AREA_PREFERENCE_SCORE_OF_HIT_TASTE * Constants.AREA_TASTE_PREFERENCE_WEIGHT + \
                    Constants.SPECIAL_FOOD_SCORE_COUNT


    normalized_score = round(weight_score / max_score, 2)

    normalized_score = round(math.sqrt(normalized_score), 2)

    return normalized_score


def load_entity_name_list_from_entity_list(entity_list:list) -> set:

    entity_name_list = set()
    for food in entity_list:
        entity_name_list.add(food[Constants.ENTITY_FIELD_NAME])
    return entity_name_list