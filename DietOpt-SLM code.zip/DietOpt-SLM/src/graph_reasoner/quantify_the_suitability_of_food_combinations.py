import sys
import time
from pathlib import Path



project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from src.util.database_util import load_food_category_combinations
from clazz.utils.logger_util import logger

def quantify_suitability_of_food_combinations(exists_food_category_obj:dict) -> list:

    food_category_combinations_arr = load_food_category_combinations()


    final_result_arr = []

    for food_category_combination in food_category_combinations_arr:
        category_1 = food_category_combination["category_1"]
        category_2 = food_category_combination["category_2"]
        suit_weight = food_category_combination["suit_weight"]
        suit_weight = float(suit_weight)

        if (food_category_combination["category_1_all"] in exists_food_category_obj
                and food_category_combination["category_2_all"] in exists_food_category_obj):

            final_result_arr.append({
                "source_food_type": category_1,
                "target_food_type": category_2,
                "suit_weight": suit_weight
            })

            final_result_arr.append({
                "source_food_type": category_2,
                "target_food_type": category_1,
                "suit_weight": suit_weight
            })
    return final_result_arr