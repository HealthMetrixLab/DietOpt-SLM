import sys
import time
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from src.util.execute_llm import execute_llm_2_analyse_dietary_pattern
from clazz.utils.logger_util import logger

def analyse_dietary_pattern_by_execute_llm_by_cons(analyse_preference_cons_dict: dict) -> dict:
    start_time = time.time()
    logger.info("==================================调用模型分析膳食模式(开始)================================")
    result_str = execute_llm_2_analyse_dietary_pattern(analyse_preference_cons_dict)

    result_obj = {
        "dietary_patterns": []
    }
    if not result_str:
        return result_obj

    dietary_pattern_list = extract_dietary_patterns_flexible(result_str)

    result_obj["dietary_patterns"] = dietary_pattern_list

    logger.info(f"【调用模型分析膳食模式】------提取到的膳食模式列表：{dietary_pattern_list}")

    logger.info(f"【调用模型分析膳食模式】------耗时：{time.time() - start_time:.2f} 秒")
    logger.info("==================================调用模型分析膳食模式(结束)================================")

    return result_obj

def extract_dietary_patterns_flexible(text):
    pattern_names = []
    lines = text.strip().split('\n')

    for line in lines:
        if line.strip().startswith('膳食模式') and '：' in line:
            name = line.split('：', 1)[1].strip()
            name = name.rstrip('。')
            pattern_names.append(name)

    return pattern_names