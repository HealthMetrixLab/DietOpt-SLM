import math
import statistics
import sys
import time
from pathlib import Path



project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from src.util.database_util import load_food_category_meal_suitability_table_name
from config.constants import Constants
from clazz.utils.logger_util import logger


def quantify_food_category_preferences_and_suitability_by_cons(
        constraint_params: dict,
        alternative_food_arr: list):
    
    start_time = time.time()
    logger.info("==============================量化食物类别偏好权重和早中晚加餐适宜度(开始)======================================")

    check_personal_obj = {}
    check_regional_obj = {}

    check_food_category_size_obj = {}

    quantify_result = {}

   
    check_food_category_nutrition_obj = {}

    for food in alternative_food_arr:
        food_category = food[Constants.ENTITY_FOOD_CATEGORY_FIELD_NAME]

        if food_category in check_food_category_size_obj:
            check_food_category_size_obj[food_category] += 1
        else:
            check_food_category_size_obj[food_category] = 1

        personal_preference_weight = food["personal_preference_weight"]
        regional_preference_weight = food["regional_preference_weight"]

        if food_category not in check_personal_obj:
            check_personal_obj[food_category] = 0
        check_personal_obj[food_category] += personal_preference_weight

        if food_category not in check_regional_obj:
            check_regional_obj[food_category] = 0
        check_regional_obj[food_category] += regional_preference_weight

        check_food_category_nutrition_obj = calculate_food_category_nutrition(
            food,
            food_category,
            check_food_category_nutrition_obj)

    logger.info(f"【量化食物类别偏好权重和早中晚加餐适宜度】------类别数量：{len(check_food_category_size_obj)}")

    check_food_category_suitability_obj = {}
    food_category_suitability_arr = load_food_category_meal_suitability_table_name()
    for food_category_suitability in food_category_suitability_arr:
        check_food_category_suitability_obj[food_category_suitability["category_name_all"]] = food_category_suitability

    final_check_food_category_nutrition_obj = get_final_food_category_nutrition_obj(
        check_food_category_nutrition_obj)
    logger.info(f"【量化食物类别偏好权重和早中晚加餐适宜度】------NUTRITION_TYPE：{Constants.NUTRITION_TYPE}")
    quantify_result = quantify_food_category_preferences_and_suitability_by_weight(
        check_personal_obj,
        check_regional_obj,
        check_food_category_size_obj,
        check_food_category_suitability_obj,
        final_check_food_category_nutrition_obj)


    logger.info(f"【量化食物类别偏好权重和早中晚加餐适宜度】------耗时：{time.time() - start_time:.2f} 秒")
    logger.info("==============================量化食物类别偏好权重和早中晚加餐适宜度(结束)======================================")
    return quantify_result


def quantify_food_category_preferences_and_suitability_by_weight(
        check_personal_obj: dict,
        check_regional_obj: dict,
        check_food_category_size_obj: dict,
        check_food_category_suitability_obj: dict,
        check_food_category_nutrition_obj: dict):

    quantify_result = []

    for food_category in check_food_category_size_obj:
        food_category_size = check_food_category_size_obj[food_category]
        if food_category_size is None or food_category_size <= 0:
            food_category_size = 1

        food_category_suitability = {
            "breakfast_suit_weight": 0,
            "lunch_suit_weight": 0,
            "dinner_suit_weight": 0,
            "extra_suit_weight": 0,
        }
        if (food_category in check_food_category_suitability_obj
                and check_food_category_suitability_obj[food_category] is not None):
            food_category_suitability = check_food_category_suitability_obj[food_category]
        else:
            logger.info(f"【量化食物类别偏好权重和早中晚加餐适宜度】------没有配置食物类别：{food_category} 的早中晚加餐适宜度")
            continue

        food_category_personal_preference_weight = check_personal_obj[food_category] / food_category_size
        food_category_regional_preference_weight = check_regional_obj[food_category] / food_category_size

        last_name = food_category.split("_")[-1]

        nutrition = check_food_category_nutrition_obj[food_category]
        if nutrition is None:
            nutrition = {
                "calories": 0,
                "protein": 0,
                "fat": 0,
                "carbo": 0,
            }

        quantify_result.append({
            "name": last_name,
            Constants.ENTITY_FOOD_CATEGORY_FIELD_NAME: food_category,
            "personal_preference_weight": food_category_personal_preference_weight,
            "regional_preference_weight": food_category_regional_preference_weight,
            "breakfast_suit_weight": food_category_suitability["breakfast_suit_weight"],
            "lunch_suit_weight": food_category_suitability["lunch_suit_weight"],
            "dinner_suit_weight": food_category_suitability["dinner_suit_weight"],
            "extra_suit_weight": food_category_suitability["extra_suit_weight"],
            "nutrition_unit": Constants.FORMAT_UNIT,
            "nutrition": nutrition
        })

    return quantify_result


def calculate_food_category_nutrition(food_obj: dict, food_category: str, check_food_category_nutrition_obj: dict):

    calories_arr = []
    protein_arr = []
    fat_arr = []
    carbo_arr = []
    if food_category in check_food_category_nutrition_obj:
        calories_arr = check_food_category_nutrition_obj[food_category]["calories"]
        protein_arr = check_food_category_nutrition_obj[food_category]["protein"]
        fat_arr = check_food_category_nutrition_obj[food_category]["fat"]
        carbo_arr = check_food_category_nutrition_obj[food_category]["carbo"]
    else:
        check_food_category_nutrition_obj[food_category] = {
            "calories": [],
            "protein": [],
            "fat": [],
            "carbo": [],
        }

    if calories_arr is None:
        calories_arr = []
    if protein_arr is None:
        protein_arr = []
    if fat_arr is None:
        fat_arr = []
    if carbo_arr is None:
        carbo_arr = []



    food_unit = 1 if not food_obj["nutrition_unit"] else float(food_obj["nutrition_unit"])
    calories = 0 if not food_obj['nutrition']["calories"] else float(food_obj["nutrition"]["calories"])
    protein = 0 if not food_obj['nutrition']["protein"] else float(food_obj["nutrition"]["protein"])
    fat = 0 if not food_obj['nutrition']["fat"] else float(food_obj["nutrition"]["fat"])
    carb = 0 if not food_obj['nutrition']["carbo"] else float(food_obj["nutrition"]["carbo"])

    one_calories = round(calories * Constants.FORMAT_UNIT / food_unit, 2)
    one_protein = round(protein * Constants.FORMAT_UNIT / food_unit, 2)
    one_fat = round(fat * Constants.FORMAT_UNIT / food_unit, 2)
    one_carb = round(carb * Constants.FORMAT_UNIT / food_unit, 2)


    calories_arr.append(one_calories)
    protein_arr.append(one_protein)
    fat_arr.append(one_fat)
    carbo_arr.append(one_carb)

    check_food_category_nutrition_obj[food_category]["calories"] = calories_arr
    check_food_category_nutrition_obj[food_category]["protein"] = protein_arr
    check_food_category_nutrition_obj[food_category]["fat"] = fat_arr
    check_food_category_nutrition_obj[food_category]["carbo"] = carbo_arr

    return check_food_category_nutrition_obj



def get_final_food_category_nutrition_obj(check_food_category_nutrition_obj: dict):

    final_check_food_category_nutrition_obj = {}

    for food_category in check_food_category_nutrition_obj:
        nutrition_obj = {
            "calories": 0,
            "protein": 0,
            "fat": 0,
            "carbo": 0,
        }

        calories_arr = check_food_category_nutrition_obj[food_category]["calories"]
        protein_arr = check_food_category_nutrition_obj[food_category]["protein"]
        fat_arr = check_food_category_nutrition_obj[food_category]["fat"]
        carbo_arr = check_food_category_nutrition_obj[food_category]["carbo"]


        if Constants.NUTRITION_TYPE == "average":
            nutrition_obj["calories"] = sum(calories_arr) / (len(calories_arr) if len(calories_arr) > 0 else 1)
            nutrition_obj["protein"] = sum(protein_arr) / (len(protein_arr) if len(protein_arr) > 0 else 1)
            nutrition_obj["fat"] = sum(fat_arr) / (len(fat_arr) if len(fat_arr) > 0 else 1)
            nutrition_obj["carbo"] = sum(carbo_arr) / (len(carbo_arr) if len(carbo_arr) > 0 else 1)
        elif Constants.NUTRITION_TYPE == "median":
            nutrition_obj["calories"] = statistics.median(calories_arr) if len(calories_arr) > 0 else 0
            nutrition_obj["protein"] = statistics.median(protein_arr) if len(protein_arr) > 0 else 0
            nutrition_obj["fat"] = statistics.median(fat_arr) if len(fat_arr) > 0 else 0
            nutrition_obj["carbo"] = statistics.median(carbo_arr) if len(carbo_arr) > 0 else 0

        nutrition_obj["calories"] = round(nutrition_obj["calories"], 2)
        nutrition_obj["protein"] = round(nutrition_obj["protein"], 2)
        nutrition_obj["fat"] = round(nutrition_obj["fat"], 2)
        nutrition_obj["carbo"] = round(nutrition_obj["carbo"], 2)

        final_check_food_category_nutrition_obj[food_category] = nutrition_obj

    return final_check_food_category_nutrition_obj

