import sys
import time
import re

from pathlib import Path



project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from config.constants import Constants

from src.util.main_execute_llm_fun import (
    analyse_user_preference_by_execute_llm_by_cons,
    analyse_user_forbidden_by_execute_llm_by_cons,
    analyse_forbidden_label_by_execute_llm_by_cons,
)

from clazz.utils.logger_util import logger

from src.graph_reasoner.analyse_take_drug_to_forbidden_ingredients import analyse_take_drug_to_forbidden_ingredients

def analyse_preference_by_execute_llm_by_cons(analyse_preference_cons_dict: dict) -> dict:
    start_time = time.time()

    result_obj = {
        'personal_preference': {
            'ingredients': {},
            'cooking': {},
            'taste': {}
        },
        'area_preference': {
            'ingredients': {},
            'cooking': {},
            'taste': {}
        },
        'forbidden_ingredients': {},
        'forbidden_cooking': {},
        'forbidden_taste': {},
        'forbidden_label': {}
    }

    extract_result_obj = analyse_user_preference_by_execute_llm_by_cons(analyse_preference_cons_dict)
    if not extract_result_obj:
        extract_result_obj = {}

    extract_result_obj = analyse_user_forbidden_by_execute_llm_by_cons(analyse_preference_cons_dict)
    if not extract_result_obj:
        extract_result_obj = {}

    result_obj = deal_execute_llm_result(result_obj, extract_result_obj)

    forbidden_label = analyse_forbidden_label_by_execute_llm_by_cons(analyse_preference_cons_dict)
    if forbidden_label and len(forbidden_label) > 0:
        result_obj['forbidden_label'] = forbidden_label

    drug_to_forbidden_ingredient_name_dict = \
        analyse_take_drug_to_forbidden_ingredients(analyse_preference_cons_dict)
    if drug_to_forbidden_ingredient_name_dict and 'forbidden_ingredient_set' in drug_to_forbidden_ingredient_name_dict:
        result_obj['forbidden_ingredients'].update(drug_to_forbidden_ingredient_name_dict['forbidden_ingredient_set'])

    logger.info(f"【调用模型分析偏好和饮食安全】------耗时：{time.time() - start_time:.2f} 秒")
    logger.info("==================================调用模型分析偏好和饮食安全(结束)================================")

    return result_obj


def deal_execute_llm_result(result_obj: dict, extract_result_obj: dict) -> dict:
    if "个人偏好（食材）" in extract_result_obj:
        result_obj['personal_preference']['ingredients'] = extract_result_obj["个人偏好（食材）"]
    if "个人偏好（烹饪方式）" in extract_result_obj:
        result_obj['personal_preference']['cooking'] = extract_result_obj["个人偏好（烹饪方式）"]
    if "个人偏好（口味）" in extract_result_obj:
        result_obj['personal_preference']['taste'] = extract_result_obj["个人偏好（口味）"]
    if "地域偏好（食材）" in extract_result_obj:
        result_obj['area_preference']['ingredients'] = extract_result_obj["地域偏好（食材）"]
    if "地域偏好（烹饪方式）" in extract_result_obj:
        result_obj['area_preference']['cooking'] = extract_result_obj["地域偏好（烹饪方式）"]
    if "地域偏好（口味）" in extract_result_obj:
        result_obj['area_preference']['taste'] = extract_result_obj["地域偏好（口味）"]
    if "禁忌食材" in extract_result_obj:
        result_obj['forbidden_ingredients'] = extract_result_obj["禁忌食材"]
    if "禁忌加工方式" in extract_result_obj:
        result_obj['forbidden_cooking'] = extract_result_obj["禁忌加工方式"]
    if "禁忌口味" in extract_result_obj:
        result_obj['forbidden_taste'] = extract_result_obj["禁忌口味"]
    return result_obj

