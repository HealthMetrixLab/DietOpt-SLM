import sys
from pathlib import Path
import json
import os
from typing import List, Union


class FileManager:
    @staticmethod
    def clear_file_data(file_path: str) -> None:
        try:
            file = Path(file_path)
            file.parent.mkdir(parents=True, exist_ok=True)

            file.write_text('')
        except Exception as e:
            print(f"❌ 错误: 写入文件 '{file_path}' 时发生意外错误: {e}", file=sys.stderr)

    @staticmethod
    def write_to_file(data: str, file_path: str, mode: str = 'a') -> bool:
        try:
            file = Path(file_path)
            file.parent.mkdir(parents=True, exist_ok=True)

            with file.open(mode, encoding='utf-8') as f:
                f.write(data)
            return True
        except PermissionError:
            return False
        except Exception as e:
            return False

    @staticmethod
    def write_str_to_file(content: str, file_path: str) -> bool:
        return FileManager.write_to_file(content + '\n', file_path, 'a')

    @staticmethod
    def write_json_to_file(json_data: dict, file_path: str) -> bool:
        json_str = json.dumps(json_data, ensure_ascii=False)
        return FileManager.write_to_file(json_str + '\n', file_path, 'a')

    @staticmethod
    def line_data_to_json(line: str) -> Union[dict, None]:
        if not line:
            return None
        try:
            return json.loads(line)
        except json.JSONDecodeError as e:
            return None
        except Exception as e:
            return None

    @staticmethod
    def get_all_files(folder_path: str, file_type: Union[str, List[str]] = '') -> List[str]:
        if not os.path.exists(folder_path):
            print(f"❌ 错误: 文件夹 '{folder_path}' 不存在", file=sys.stderr)
            return []
        if not os.path.isdir(folder_path):
            print(f"❌ 错误: '{folder_path}' 不是一个有效的文件夹", file=sys.stderr)
            return []

        file_types = []
        if isinstance(file_type, str):
            file_types = [ft.strip().lower() for ft in file_type.split(',') if ft]
        elif isinstance(file_type, list):
            file_types = [ft.strip().lower() for ft in file_type if ft]

        all_files = []
        for root, _, files in os.walk(folder_path):
            for file in files:
                if not file_types or any(file.lower().endswith(ft) for ft in file_types):
                    all_files.append(os.path.join(root, file))

        # print(f"✅ 获取文件夹 '{folder_path}' 下的所有文件，共 {len(all_files)} 个文件")
        return all_files

    @staticmethod
    def read_data_list_by_file_path(file_path: str, encoding: str = 'utf-8') -> List[str]:
        file = Path(file_path)
        if not file.is_file():
            return []

        try:
            with file.open('r', encoding=encoding) as f:
                lines = [line.rstrip('\n') for line in f]
                return [line for line in lines if line]
        except UnicodeDecodeError:
            return []
        except PermissionError:
            return []
        except Exception as e:
            return []

    @staticmethod
    def read_data_str_by_file_path(file_path: str, encoding: str = 'utf-8') -> str:
        file = Path(file_path)
        if not file.is_file():
            return ""

        try:
            with file.open('r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            return ""
        except PermissionError:
            return ""
        except Exception as e:
            return ""

    @staticmethod
    def read_data_list_by_file_path_limit_line(file_path: str, encoding: str = 'utf-8', limit_line: int = 100) -> List[
        str]:
        file = Path(file_path)
        if not file.is_file():
            print(f"❌ 错误: 文件 '{file_path}' 不存在或不是一个文件", file=sys.stderr)
            return []

        try:
            with file.open('r', encoding=encoding) as f:
                lines = []
                for i, line in enumerate(f):
                    if i >= limit_line:
                        break
                    lines.append(line.rstrip('\n'))
                return [line for line in lines if line]
        except UnicodeDecodeError:
            print(f"❌ 错误: 文件 '{file_path}' 不是 {encoding} 编码", file=sys.stderr)
            return []
        except PermissionError:
            print(f"❌ 错误: 没有权限读取文件 '{file_path}'", file=sys.stderr)
            return []
        except Exception as e:
            print(f"❌ 错误: 读取文件 '{file_path}' 时发生意外错误: {e}", file=sys.stderr)
            return []


# 示例使用
if __name__ == '__main__':
       print('---start---')