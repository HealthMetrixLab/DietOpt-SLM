import os
import time
import logging

import sys
from pathlib import Path

# ===== 配置 =====
MAX_BYTES = 10 * 1024 * 1024  # 10MB
DEFAULT_FILE_NAME = "app.log"  

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

# 控制台颜色
COLORS = {
    logging.DEBUG: "\033[37m",
    logging.INFO: "\033[32m",
    logging.WARNING: "\033[33m",
    logging.ERROR: "\033[31m",
    logging.CRITICAL: "\033[41m",
}
RESET = "\033[0m"


class ColorFormatter(logging.Formatter):
    def format(self, record):
        log_color = COLORS.get(record.levelno, RESET)
        message = super().format(record)
        return f"{log_color}{message}{RESET}"


class DailySizeRotatingFileHandler(logging.Handler):
    def __init__(self, filename: str, maxBytes: int = MAX_BYTES, encoding: str = "utf-8"):
        super().__init__()
        stem, ext = os.path.splitext(filename)
        self.stem = stem
        self.ext = ext or ".log"
        self.maxBytes = maxBytes
        self.encoding = encoding

        self.current_date = time.strftime("%Y-%m-%d", time.localtime())
        self.file_index = 1
        self.stream = None

        dir_ = os.path.dirname(self.stem) or "."
        os.makedirs(dir_, exist_ok=True)

        self._open_new_file()

    def _current_log_path(self) -> str:
        return f"{self.stem}.{self.current_date}.{self.file_index}{self.ext}"

    def _open_new_file(self):
        if self.stream:
            try:
                self.stream.close()
            except Exception:
                pass
        path = self._current_log_path()
        self.stream = open(path, "a", encoding=self.encoding)

    def emit(self, record):
        try:
            self.acquire()
            msg = self.format(record)

            today = time.strftime("%Y-%m-%d", time.localtime())
            if today != self.current_date:
                self.current_date = today
                self.file_index = 1
                self._open_new_file()

            self.stream.seek(0, os.SEEK_END)
            if self.maxBytes and self.stream.tell() >= self.maxBytes:
                self.file_index += 1
                self._open_new_file()

            self.stream.write(msg + "\n")
            self.stream.flush()
        except Exception:
            self.handleError(record)
        finally:
            self.release()

    def close(self):
        try:
            if self.stream:
                self.stream.close()
        finally:
            super().close()


def get_logger(
    logger_name: str = "diet_logger",
    log_dir: str = os.path.join(project_root, "logs"),
    base_filename: str = DEFAULT_FILE_NAME, 
    level: int = logging.INFO,
    max_bytes: int = MAX_BYTES,
    encoding: str = "utf-8",
    clean_root: bool = True,       
    clear_existing: bool = True,   
):
    if clean_root:
        root = logging.getLogger()
        for h in list(root.handlers):
            root.removeHandler(h)
            try:
                h.close()
            except Exception:
                pass
        root.filters.clear()
        root.setLevel(logging.NOTSET)

    logger = logging.getLogger(logger_name)

    if clear_existing:
        for h in list(logger.handlers):
            logger.removeHandler(h)
            try:
                h.close()
            except Exception:
                pass

    logger.setLevel(level)
    logger.propagate = False

    fmt = "%(asctime)s [%(levelname)s] [%(filename)s:%(lineno)d] - %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(ColorFormatter(fmt=fmt, datefmt=datefmt))
    logger.addHandler(console_handler)

    os.makedirs(log_dir, exist_ok=True)

    stem, ext = os.path.splitext(base_filename)
    file_stub = os.path.join(log_dir, f"{stem}{ext or '.log'}") 
    file_handler = DailySizeRotatingFileHandler(
        filename=file_stub,
        maxBytes=max_bytes,
        encoding=encoding,
    )
    file_handler.setFormatter(logging.Formatter(fmt=fmt, datefmt=datefmt))
    logger.addHandler(file_handler)

    return logger

logger = get_logger()


if __name__ == "__main__":
    print('---start---')