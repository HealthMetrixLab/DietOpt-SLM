import socket
import json
import psycopg2
from psycopg2 import errors, Error
import datetime
from typing import List, Dict, Union

from clazz.common.yaml_config_manager_class import YamlConfigManager
from clazz.utils.logger_util import logger

from clazz.database.sequence_manager_class import SequenceManager

class PostgreSQLManager:

    def __init__(self, db_config: dict=None):
        if not db_config:
            host = YamlConfigManager.get('database.master.host')
            port = YamlConfigManager.get('database.master.port')
            database = YamlConfigManager.get('database.master.database')
            user = YamlConfigManager.get('database.master.user')
            password = YamlConfigManager.get('database.master.password')
            db_config = {
                'host': host,
                'port': port,
                'database': database,
                'user': user,
                'password': password
            }

        self.db_config = db_config
        self.conn = None
        self.cursor = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close_connection()
        if exc_type:
            return False
        return True

    def _check_config(self) -> bool:
        required_keys = ['host', 'port', 'database', 'user', 'password']
        if not self.db_config:
            logger.error("数据库配置为空")
            return False
        for key in required_keys:
            if key not in self.db_config:
                logger.error(f"数据库配置缺少 '{key}'")
                return False
        return True

    def connect(self) -> bool:
        if not self._check_config():
            return False
        try:
            self.conn = psycopg2.connect(**self.db_config)
            self.conn.autocommit = True
            self.cursor = self.conn.cursor()
            return True
        except psycopg2.Error as e:
            logger.error(f"数据库连接错误: {str(e)}")
            self.close_connection()
            return False
        except Exception as e:
            self.close_connection()
            return False

    def close_connection(self):
        if self.cursor:
            self.cursor.close()
            self.cursor = None
        if self.conn:
            self.conn.close()
            self.conn = None

    def test_network_connection(self, show_log:bool=True) -> bool:
        if not self._check_config():
            return False
        host = self.db_config['host']
        port = self.db_config['port']
        try:
            sock = socket.create_connection((host, port), timeout=5)
            sock.close()
            if show_log:
                logger.info(f"✅ 网络连接测试成功: {host}:{port}")
            return True
        except Exception as e:
            if show_log:
                logger.error(f"❌ 网络连接失败: {str(e)}")
            return False

    def _execute_query(self, query_sql: str, query_model: str = 'public', params: tuple = None) -> Union[List, bool]:
        if not self.conn:
            logger.error("数据库连接未建立")
            return []

        try:
            self.cursor.execute(f"SET search_path TO {query_model};")
            if params:
                self.cursor.execute(query_sql, params)
            else:
                self.cursor.execute(query_sql)

            try:
                self.conn.commit()
            except psycopg2.ProgrammingError:
                pass 

            return True
        except errors.Error as e:
            logger.error(f"错误详情: {e.pgcode}, {e.pgerror}, SQL: {query_sql}")
            return False
        except Exception as e:
            logger.error(f"未知错误: {str(e)}, SQL: {query_sql}")
            return False

    def query_data_list(self, query_sql: str, query_model: str = 'public') -> List[tuple]:
        if not query_sql:
            print("错误: SQL为空")
            return []

        if not self.connect():
            return []

        try:
            self.cursor.execute(f"SET search_path TO {query_model};")
            self.cursor.execute(query_sql)
            return self.cursor.fetchall()
        except errors.Error as e:
            return []
        finally:
            self.close_connection()

    def query_data_list_dict(self, query_sql: str, query_model: str = 'public', params: tuple = None) -> List[Dict[str, Union[str, int]]]:
        if not query_sql:
            return []

        if not self.connect():
            return []

        try:
            self.cursor.execute(f"SET search_path TO {query_model};")
            if params:
                self.cursor.execute(query_sql, params)
            else:
                self.cursor.execute(query_sql)

            columns = [desc[0] for desc in self.cursor.description]
            result = []
            for row_tuple in self.cursor.fetchall():
                row_dict = dict(zip(columns, row_tuple))
                for key, value in row_dict.items():
                    if isinstance(value, datetime.datetime):
                        row_dict[key] = value.strftime("%Y-%m-%d %H:%M:%S")
                result.append(row_dict)
            return result
        except Exception as e:
            return []
        finally:
            self.close_connection()

    def execute_sql(self, sql: str, query_model: str = 'public', params: tuple = None) -> bool:
        if not sql:
            return False

        if not self.connect():
            return False

        try:
            self.cursor.execute(f"SET search_path TO {query_model};")
            if params:
                self.cursor.execute(sql, params)
            else:
                self.cursor.execute(sql)
            self.conn.commit()  # 显式提交
            return True
        except errors.Error as e:
            logger.error(f"错误详情: {e.pgcode}, {e.pgerror}, SQL: {sql}")
            return False
        finally:
            self.close_connection()

    def check_is_exists_table(self, table_name: str, query_model: str = 'public') -> bool:
        if not table_name:
            logger.error("表名为空")
            return False

        if not self.connect():
            return False

        try:
            self.cursor.execute(f"SET search_path TO {query_model};")
            self.cursor.execute("SELECT 1 FROM information_schema.tables WHERE table_name = %s", (table_name,))
            return self.cursor.fetchone() is not None
        except errors.Error as e:
            logger.error(f"错误详情: {e.pgcode}, {e.pgerror}, SQL: {table_name}")
            return False
        finally:
            self.close_connection()

    def truncate_table(self, table_name: str, query_model: str = 'public') -> bool:
        if not table_name:
            logger.error("表名为空")
            return False

        return self.execute_sql(f"TRUNCATE TABLE {table_name};", query_model)

    def del_table(self, table_name: str, query_model: str = 'public') -> bool:
        if not table_name:
            logger.error("表名为空")
            return False

        return self.execute_sql(f"DROP TABLE IF EXISTS {table_name};", query_model)

    def get_sequence_next_value(self, sequence_name: str, start_value: int = 1, increment_by: int = 1,
                                create_sequence_flag: bool = True) -> int:
        manager = None
        try:
            manager = SequenceManager(self.db_config)

            sequence_ready = manager.check_and_create_sequence(sequence_name, start_value, increment_by,
                                                               create_sequence_flag)

            if not sequence_ready:
                return -1

            next_value = manager.get_sequence_next_value(sequence_name)
            return next_value
        except ImportError:
            logger.error("缺少 SequenceManager 类，请确保其路径正确。")
            return -1
        except Exception as e:
            logger.error(f"获取序列值时发生未预期错误: {e}")
            return -1
        finally:
            if manager:
                manager.close_connection()


# 示例使用
if __name__ == '__main__':
        print('---start---')