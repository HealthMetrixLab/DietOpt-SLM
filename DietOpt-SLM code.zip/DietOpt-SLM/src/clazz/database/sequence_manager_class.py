import psycopg2
from psycopg2 import Error

class SequenceManager:
    def __init__(self, db_config: dict):
        self.db_config = db_config
        self.connection = None

    def _get_db_connection(self):
        if self.connection is None or self.connection.closed:
            try:
                self.connection = psycopg2.connect(**self.db_config)
                self.connection.autocommit = True
            except Error as e:
                raise
        return self.connection

    def close_connection(self):
        if self.connection and not self.connection.closed:
            self.connection.close()
            #print("序列管理类---数据库连接已关闭。")

    def check_and_create_sequence(
            self,
            sequence_name: str,
            start_value: int = 1,
            increment_by: int = 1,
            create_sequence_flag: bool = True) -> bool:
        conn = None
        cursor = None
        try:
            conn = self._get_db_connection()
            cursor = conn.cursor()

            cursor.execute(f"SELECT 1 FROM pg_class WHERE relkind = 'S' AND relname = '{sequence_name}'")
            exists = cursor.fetchone()

            if exists:
                return True
            else:
                if create_sequence_flag:
                    # --- 2. 如果不存在，则创建序列 ---
                    create_sql = f"CREATE SEQUENCE {sequence_name} START WITH {start_value} INCREMENT BY {increment_by}"
                    cursor.execute(create_sql)
                    return True
                else:
                    return False

        except Error as e:
            return False
        finally:
            if cursor:
                cursor.close()
            # 注意：连接在这里不关闭，因为可能后续还要获取序列值

    def get_sequence_next_value(self, sequence_name: str) -> int | None:
        conn = None
        cursor = None
        try:
            conn = self._get_db_connection()
            cursor = conn.cursor()
            cursor.execute(f"SELECT nextval('{sequence_name}')")
            next_value = cursor.fetchone()[0]
            return next_value

        except Error as e:
            return None
        finally:
            if cursor:
                cursor.close()