import time
import threading
from pathlib import Path
import sys
from typing import Optional

import httpx
from openai import OpenAI

project_root = str(Path(__file__).parent.parent.parent.parent)
sys.path.append(project_root)

from src.clazz.common.yaml_config_manager_class import YamlConfigManager
from src.clazz.utils.logger_util import logger

MODEL_NAME = YamlConfigManager.get('llm-config.model-path-name') or YamlConfigManager.get('llm-config.model-name')
LLM_REQUEST_TIMEOUT = httpx.Timeout(60.0, connect=20.0)
LLM_SDK_MAX_RETRIES = 2
LLM_MAX_ATTEMPTS = 3


class MyNutritionLLMExecutor:

    _instance = None
    _lock = threading.Lock()

    def __init__(self, api_key: str, base_url: str):
        if not api_key:
            raise ValueError("API密钥不能为空。")
        if not base_url:
            raise ValueError("基础URL不能为空。")
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url,
            timeout=LLM_REQUEST_TIMEOUT,
            max_retries=LLM_SDK_MAX_RETRIES,
        )

    @classmethod
    def get_instance(cls) -> "MyNutritionLLMExecutor":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    api_key = YamlConfigManager.get('llm-config.key') or YamlConfigManager.get('llm-config.api-key')
                    base_url = YamlConfigManager.get('llm-config.base-url') or YamlConfigManager.get('llm-config.api-base-url')
                    cls._instance = cls(api_key, base_url)
        return cls._instance

    def _request_with_retry(self, params: dict, model: str) -> Optional[str]:
        for attempt in range(1, LLM_MAX_ATTEMPTS + 1):
            try:
                completion = self.client.chat.completions.create(**params)
                content = completion.choices[0].message.content if completion.choices else None
                if content:
                    return content.strip()
                logger.warning(f"调用模型 {model} 返回空内容")
                return None
            except Exception as e:
                logger.error(f"调用模型 {model} 第{attempt}/{LLM_MAX_ATTEMPTS}次失败：{e}")
                if attempt < LLM_MAX_ATTEMPTS:
                    sleep_seconds = attempt
                    logger.info(f"调用模型 {model} 将在 {sleep_seconds} 秒后重试")
                    time.sleep(sleep_seconds)
        return None

    def execute_llm(self, text: str, model: str, prefix: str, temperature: float = 0.85) -> Optional[str]:
        """
        简单调用大模型处理
        """
        if not text:
            return None
        params = {
            "model": model,
            "messages": [
                {'role': 'system', 'content': prefix},
                {'role': 'user', 'content': text}
            ],
            "temperature": temperature
        }
        return self._request_with_retry(params, model)

    def default_modell_execute_llm(self, text: str, prefix: str, model_name: str = MODEL_NAME, temperature: float = 0.85) -> Optional[str]:
        return self.execute_llm(text, model_name, prefix, temperature)

    def execute_llm_with_complicated_params(
        self,
        text: str,
        prefix: str,
        query_llm_params: dict,
        model: str = MODEL_NAME
    ) -> Optional[str]:
        if not text:
            return None

        params = {
            "model": model,
            "messages": [
                {"role": "system", "content": prefix},
                {"role": "user", "content": text}
            ]
        }
        if query_llm_params:
            for k, v in query_llm_params.items():
                if v is not None:
                    params[k] = v
        return self._request_with_retry(params, model)

if __name__ == "__main__":
    print("---start---")
