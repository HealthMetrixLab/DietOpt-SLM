import yaml
from pathlib import Path

class YamlConfigManager:

    _config = None

    _base_dir = Path(__file__).resolve().parent
    _config_path = _base_dir.parent.parent / 'config' / 'config.yaml'

    @classmethod
    def load_config(cls):
        if cls._config is None:
            if not cls._config_path.is_file():
                raise FileNotFoundError(f"配置文件未找到: {cls._config_path}")

            with open(cls._config_path, 'r', encoding='utf-8') as file:
                cls._config = yaml.safe_load(file)

    @classmethod
    def get(cls, key: str, default=None):
        if cls._config is None:
            cls.load_config()  # 自动加载配置

        keys = key.split('.')
        value = cls._config
        try:
            for k in keys:
                value = value[k]
            return value
        except (KeyError, TypeError):
            return default


if __name__ == '__main__':
    print('---start---')