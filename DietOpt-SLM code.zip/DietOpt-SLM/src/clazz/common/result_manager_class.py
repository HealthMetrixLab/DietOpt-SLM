from uuid import uuid4
from datetime import datetime
from typing import Optional
import json

class ResultManager:

    @staticmethod
    def success(msg: str, data: Optional[dict] = None, serial_number: str = None) -> dict:
        return {
            "code": 200,
            "success": True,
            "msg": msg,
            "data": data,
            "serial_number": serial_number,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    @staticmethod
    def error(msg: str, data: Optional[dict] = None, serial_number: str = None) -> dict:
        return {
            "code": 500,
            "success": False,
            "msg": msg,
            "data": data,
            "serial_number": serial_number,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    @staticmethod
    def error_with_code(code: int, msg: str, data: Optional[dict] = None, serial_number: str = None) -> dict:
        return {
            "code": code,
            "success": False,
            "msg": msg,
            "data": data,
            "serial_number": serial_number,
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }