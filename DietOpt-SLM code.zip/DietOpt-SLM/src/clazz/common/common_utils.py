from uuid import uuid4
from datetime import datetime
from typing import Optional
import json
import random

class CommonUtils:
    @staticmethod
    def get_uuid() -> str:
        return str(uuid4()).replace("-", "")

    @staticmethod
    def get_current_time_str() -> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def get_current_date() -> datetime:
        return datetime.now()

    @staticmethod
    def remove_special_characters(text: str) -> str:
        if not text:
            return ""
        special_chars = "!@#$%^&*;"
        translator = str.maketrans("", "", special_chars)
        return text.translate(translator)

    @staticmethod
    def replace_the_line_of_break_character(text: str) -> str:
        if not text:
            return ""
        return text.replace("\n", "")

    @staticmethod
    def line_data_to_json(line: str):
        if not line:
            return None
        try:
            json_data = json.loads(line)
            return json_data
        except Exception as e:
            print(f"错误: STR 转换 JSON 数据时发生意外错误: {e}")
            return None


    @staticmethod
    def json_data_to_str(json_data: json) -> str:
        if not json_data:
            return ""
        try:
            json_str = json.dumps(json_data, ensure_ascii=False)
            return json_str
        except Exception as e:
            print(f"错误: JSON 转换 STR 数据时发生意外错误: {e}")
            return None

    @staticmethod
    def check_is_valid_json(value: str) -> bool:
        try:
            json.loads(value)
        except json.JSONDecodeError:
            return False
        return True

    @staticmethod
    def balanced_random_meal(choices, days=7):
        n = len(choices)
        if days < n:
            raise ValueError("天数不能少于可选餐数，否则无法保证每种至少一次")
        result = list(choices)
        remaining = days - n
        for _ in range(remaining):
            result.append(random.choice(choices))
        random.shuffle(result)

        return result
if __name__ == "__main__":
    print('---start---')