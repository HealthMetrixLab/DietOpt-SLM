import redis
import json
from typing import Any, Optional
from clazz.common.yaml_config_manager_class import YamlConfigManager

class RedisTool:
    def __init__(self, host: str = None, port: int = None, db: int = None, password: Optional[str] = None):
        if not host:
            host = YamlConfigManager.get('redis.host')
            port = YamlConfigManager.get('redis.port')
            db = YamlConfigManager.get('redis.db')
            password = YamlConfigManager.get('redis.password')


        self.pool = redis.ConnectionPool(host=host, port=port, db=db, password=password, decode_responses=True)
        self.client = redis.Redis(connection_pool=self.pool)

    def set(self, key: str, value: Any, expire: int = None) -> bool:
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        return self.client.set(name=key, value=value, ex=expire)

    def get(self, key: str) -> Any:
        value = self.client.get(key)
        try:
            return json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return value

    def delete(self, key: str) -> int:
        return self.client.delete(key)

    def exists(self, key: str) -> bool:
        return self.client.exists(key) == 1

    def hset(self, name: str, key: str, value: Any) -> int:
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        return self.client.hset(name, key, value)

    def hget(self, name: str, key: str) -> Any:
        value = self.client.hget(name, key)
        try:
            return json.loads(value)
        except (TypeError, json.JSONDecodeError):
            return value

    def hgetall(self, name: str) -> dict:
        data = self.client.hgetall(name)
        result = {}
        for k, v in data.items():
            try:
                result[k] = json.loads(v)
            except (TypeError, json.JSONDecodeError):
                result[k] = v
        return result

    def lpush(self, name: str, *values) -> int:
        return self.client.lpush(name, *values)

    def rpush(self, name: str, *values) -> int:
        return self.client.rpush(name, *values)

    def lpop(self, name: str) -> Optional[str]:
        return self.client.lpop(name)

    def rpop(self, name: str) -> Optional[str]:
        return self.client.rpop(name)

    def lrange(self, name: str, start: int = 0, end: int = -1) -> list:
        return self.client.lrange(name, start, end)

    def close(self):
        self.pool.disconnect()


if __name__ == "__main__":
    print('---start---')