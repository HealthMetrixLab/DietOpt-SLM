import requests
import json
from typing import Any, Dict, Optional, Union
import sys
import time
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from clazz.utils.logger_util import logger

class APIClientManager:
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.headers: Dict[str, str] = {}
        self.token: Optional[str] = None

    def set_token(self, token: str, token_type: str = "Bearer"):
        self.token = token
        self.headers['Authorization'] = f"{token_type} {self.token}"

    def set_header(self, key: str, value: str):
        self.headers[key] = value

    def _request(self, method: str, endpoint: str, timeout: int = 30, **kwargs: Any) -> Union[Dict, str, bytes, None]:
        url = f"{self.base_url}{endpoint}"
        headers = self.headers.copy()
        if 'headers' in kwargs:
            headers.update(kwargs['headers'])
        kwargs['headers'] = headers

        kwargs['timeout'] = timeout
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            try:
                return response.json()
            except json.JSONDecodeError:
                content_type = response.headers.get('Content-Type', '')
                if 'application/octet-stream' in content_type:
                    return response.content
                return response.text

        except requests.exceptions.RequestException as e:
            logger.error(f"请求失败，URL: {url}, 错误: {e}")
            return None

    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None, timeout: int = 30, **kwargs: Any) -> Union[
        Dict, str, bytes, None]:
        return self._request("GET", endpoint, params=params, timeout=timeout, **kwargs)

    def post(self, endpoint: str, data: Optional[Union[Dict, str]] = None, json_data: Optional[Dict] = None,
             timeout: int = 30, **kwargs: Any) -> Union[Dict, str, bytes, None]:
        if json_data:
            kwargs['json'] = json_data
        elif data:
            kwargs['data'] = data
        return self._request("POST", endpoint, timeout=timeout, **kwargs)

if __name__ == '__main__':
    print('---start---')