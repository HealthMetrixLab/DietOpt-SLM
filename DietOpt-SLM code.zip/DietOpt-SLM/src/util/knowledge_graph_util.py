import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from config.constants import Constants
from clazz.utils.logger_util import logger

def load_food_list_by_cons(ingredients:set, cooking:set, taste:set, query_type:str='0') -> list:
    from src.util.database_util import load_entity_list, load_food_entity_list

    result_list = []

    extra_forbidden_ingredients = filter_by_query_type(
        ingredients, cooking, taste, query_type
    )

    ingredients_entity_list = load_entity_list(ingredients, Constants.INGREDIENT_ENTITY_TYPE_NAME)
    cooking_entity_list = load_entity_list(cooking, Constants.COOKING_ENTITY_TYPE_NAME)
    taste_entity_list = load_entity_list(taste, Constants.TASTE_ENTITY_TYPE_NAME)

    check_exists_food = {}

    temp_arr = []
    if ingredients_entity_list  and len(ingredients_entity_list) > 0:
        for entity in ingredients_entity_list:
            temp_arr.append(entity[Constants.ENTITY_FIELD_NAME])
    
    if query_type == '1':
        temp_arr.extend(extra_forbidden_ingredients)

    food_of_ingredients = load_food_entity_list(
        temp_arr,
        Constants.INGREDIENT_ENTITY_TYPE_NAME,
        Constants.INGREDIENT_RELATION_SHIP_ID
    )
    check_exists_food = deal_food_entity_list(food_of_ingredients, check_exists_food, "hit_ingredients")
    

    temp_arr = []
    if cooking_entity_list and len(cooking_entity_list) > 0:
        for entity in cooking_entity_list:
            temp_arr.append(entity[Constants.ENTITY_FIELD_NAME])

    food_of_cooking = load_food_entity_list(
        temp_arr,
        Constants.COOKING_ENTITY_TYPE_NAME,
        Constants.COOKING_RELATION_SHIP_ID
    )
    check_exists_food = deal_food_entity_list(food_of_cooking, check_exists_food, "hit_cooking")
    
    temp_arr = []
    if taste_entity_list  and len(taste_entity_list) > 0:
        for entity in taste_entity_list:
            temp_arr.append(entity[Constants.ENTITY_FIELD_NAME])

    food_of_taste = load_food_entity_list(
        temp_arr,
        Constants.TASTE_ENTITY_TYPE_NAME,
        Constants.TASTE_RELATION_SHIP_ID
    )
    check_exists_food = deal_food_entity_list(food_of_taste, check_exists_food, "hit_taste")
    

    for food_id, entity in check_exists_food.items():
        result_list.append(entity)
    return result_list

def deal_food_entity_list(entity_list:list, check_exists_food:dict, key_word: str) :

    if entity_list:
        for entity in entity_list:
            if check_exists_food.get(entity["food_id"]) is None:
                entity[key_word] = [entity[Constants.TARGET_ENTITY_NAME_FIELD_NAME]]
                check_exists_food[entity["food_id"]] = entity
            else:
                if key_word in check_exists_food[entity["food_id"]].keys():
                    check_exists_food[entity["food_id"]][key_word].append(entity[Constants.TARGET_ENTITY_NAME_FIELD_NAME])
                else:
                    check_exists_food[entity["food_id"]][key_word] = [entity[Constants.TARGET_ENTITY_NAME_FIELD_NAME]]
    return check_exists_food


def filter_by_query_type(ingredients:set, cooking:set, taste:set, query_type:str='0') -> list:
 
    from src.util.database_util import load_entity_list, load_food_entity_list
    if query_type == '1':
        extra_entity_list = load_entity_list(ingredients, Constants.INGREDIENT_ALLERGEN_CATEGORY_ENTITY_TYPE_NAME)
        if not extra_entity_list:
            return []
        ingredient_allergen_category_list = [entity[Constants.ENTITY_FIELD_NAME] for entity in extra_entity_list]
        if not ingredient_allergen_category_list:
            return []
        forbidden_ingredient_list = load_food_entity_list(
            ingredient_allergen_category_list,
            Constants.INGREDIENT_ALLERGEN_CATEGORY_ENTITY_TYPE_NAME,
            Constants.INGREDIENT_ALLERGEN_CATEGORY_RELATION_SHIP_ID,
            Constants.INGREDIENT_ENTITY_TYPE_NAME
        )
        if not forbidden_ingredient_list:
            return []
        return [entity['food_name'] for entity in forbidden_ingredient_list]
    return []

def load_forbidden_lineage_ingredient_obj() -> dict:
    from src.util.database_util import load_forbidden_lineage_ingredient

    result_dict = {}
    forbidden_lineage_ingredient_list = load_forbidden_lineage_ingredient()
    if forbidden_lineage_ingredient_list:
        for entity in forbidden_lineage_ingredient_list:
            if entity['source_entity_id'] not in result_dict.keys():
                result_dict[entity['source_entity_id']] = []
            result_dict[entity['source_entity_id']].append(entity['target_entity_id'])

            if entity['target_entity_id'] not in result_dict.keys():
                result_dict[entity['target_entity_id']] = []
            result_dict[entity['target_entity_id']].append(entity['source_entity_id'])

    return result_dict


def load_forbidden_food_list_by_food_label(forbidden_label_arr: set) -> list:
    from src.util.database_util import load_entity_list, load_food_entity_list,load_all_food_label

    final_label_set = set()
    all_food_label_list = load_all_food_label()

    add_label_to_forbidden_label(forbidden_label_arr, '高GI值', '高GI')
    add_label_to_forbidden_label(forbidden_label_arr, '高GI值', '高糖')
    add_label_to_forbidden_label(forbidden_label_arr, '高糖', '稀饭')
    add_label_to_forbidden_label(forbidden_label_arr, '高脂肪', '高脂')
    add_label_to_forbidden_label(forbidden_label_arr, '高胆固醇', '高胆固醇类')
    add_label_to_forbidden_label(forbidden_label_arr, '高油', '大量油')
    add_label_to_forbidden_label(forbidden_label_arr, '精制碳水', '精制主食')

    for label in forbidden_label_arr:
        for food_label in all_food_label_list:
            if label == food_label or label in food_label or food_label in label:
                final_label_set.add(food_label)
    all_forbidden_list = list(final_label_set)

    forbidden_food_list = load_food_entity_list(
        all_forbidden_list,
        Constants.LABEL_ENTITY_TYPE_NAME,
        Constants.FOOD_LABEL_RELATION_SHIP_ID
    )
    count_map = {}
    for food in forbidden_food_list:
        label_name = food[Constants.TARGET_ENTITY_NAME_FIELD_NAME]
        if label_name in count_map:
            count_map[label_name] += 1
        else:
            count_map[label_name] = 1
    for label_name in sorted(count_map.keys()):
        count = count_map[label_name]
        logger.info(f"禁忌食物标签：{label_name}，数量：{count}")
    return forbidden_food_list


def add_label_to_forbidden_label(forbidden_label_set:set, label:str, same_label:str = None):
    new_set = set()
    if not forbidden_label_set:
        return forbidden_label_set
    for temp_label in forbidden_label_set:
        if label in temp_label or temp_label in label:
            new_set.add(same_label)
        if not same_label and same_label in temp_label or temp_label in same_label:
            new_set.add(label)
    if new_set and len(new_set) > 0:
        forbidden_label_set.update(new_set)
    return forbidden_label_set


def load_alter_food_data_by_user_disease(disease_name:str) -> list:
    from src.util.database_util import load_entity_list, load_food_entity_list,load_all_food_label
    result_list = []
    target_entity_name_arr = []
    disease_name = '高血糖'
    if '食物库' not in disease_name:
        disease_name += '食物库'
    target_entity_name_arr.append(disease_name)

    if '高血糖食物库' in disease_name:
        target_entity_name_arr.append('糖尿病食物库')
    if '糖尿病食物库' in disease_name:
        target_entity_name_arr.append('高血糖食物库')

    food_entity_list = load_food_entity_list(
        target_entity_name_arr,
        Constants.LABEL_ENTITY_TYPE_NAME,
        Constants.FOOD_LABEL_RELATION_SHIP_ID
    )
    if food_entity_list:
        for food in food_entity_list:
            if food['food_id'] and food['food_id'] not in result_list:
                result_list.append(food['food_id'])
    return result_list


def load_food_list_by_food_label(food_label_arr: list,strong_correlation:bool = True) -> list:
    from src.util.database_util import load_food_entity_list,load_all_food_label

    final_label_set = set()
    all_food_label_list = load_all_food_label()

    for label in food_label_arr:
        for food_label in all_food_label_list:
            if strong_correlation:
                if label == food_label:
                    final_label_set.add(food_label)
            else:
                if label == food_label or label in food_label or food_label in label:
                    final_label_set.add(food_label)

    all_label_list = list(final_label_set)

    food_list = load_food_entity_list(
        all_label_list,
        Constants.LABEL_ENTITY_TYPE_NAME,
        Constants.FOOD_LABEL_RELATION_SHIP_ID
    )
    count_map = {}
    for food in food_list:
        label_name = food[Constants.TARGET_ENTITY_NAME_FIELD_NAME]
        if label_name in count_map:
            count_map[label_name] += 1
        else:
            count_map[label_name] = 1
    for label_name in sorted(count_map.keys()):
        count = count_map[label_name]
        logger.info(f"食物标签：{label_name}，数量：{count}")
    return food_list

