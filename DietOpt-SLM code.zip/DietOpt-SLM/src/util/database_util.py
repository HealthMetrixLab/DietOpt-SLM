import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)

from config.constants import Constants


MAX_ARR_SIZE = 200

def load_entity_list(name_set:set, entity_type:str) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager

    filter_sql = ""
    name_set = {name for name in name_set if name and name != ""}
    if not name_set or len(name_set) == 0:
        return []

    if not entity_type:
        return []
    db_manager = None
    try:
        filter_list = []
        for name in name_set:
            filter_list.append(f"{Constants.ENTITY_FIELD_NAME} like '%{name}%'")
        filter_sql = " or ".join(filter_list)
        filter_sql = f" AND ({filter_sql})"

        query_sql = f"""
        SELECT
        id ,entity_name ,entity_type ,way ,forbidden_for ,nutritional_value ,food_category ,
        food_taste ,food_cuisine ,food_unit ,calories ,protein ,fat ,carbo,food_id
        FROM
            {Constants.ENTITY_TABLE_NAME}
        WHERE
        1 = 1 and del_flag='0'
        {filter_sql} and {Constants.ENTITY_TYPE_FIELD_NAME} = '{entity_type}'
        """
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []

def average_set_by_size(set_arr:list, size:int) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager

    result_list = []
    for i in range(0, len(set_arr), size):
        result_list.append(set_arr[i:i+size])
    return result_list


def load_food_entity_list(
        target_entity_name_arr:list,
        target_entity_type:str,
        relationship_id:str,
        source_entity_type:str=Constants.FOOD_ENTITY_TYPE_NAME
) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    
    if not target_entity_name_arr or len(target_entity_name_arr) == 0:
        return []
    filter_sql = ""
    db_manager = None
    try:
        if len(target_entity_name_arr) <= MAX_ARR_SIZE:
            filter_sql = ",".join([f"'{name}'" for name in target_entity_name_arr])
            filter_sql = f" AND {Constants.TARGET_ENTITY_NAME_FIELD_NAME} IN ({filter_sql}) "
        else:
            split_arr = average_set_by_size(target_entity_name_arr, MAX_ARR_SIZE)
            filter_list = []
            for split_set in split_arr:
                temp_filter_sql = ",".join([f"'{name}'" for name in split_set])
                temp_filter_sql = f" {Constants.TARGET_ENTITY_NAME_FIELD_NAME} IN ({temp_filter_sql}) "
                filter_list.append(temp_filter_sql)
            filter_sql = " OR ".join(filter_list)
            filter_sql = f" AND ({filter_sql}) "

        query_sql = f"""
        SELECT
        {Constants.SOURCE_ENTITY_ID_FIELD_NAME} as food_id,
        {Constants.SOURCE_ENTITY_NAME_FIELD_NAME} as food_name,
        {Constants.TARGET_ENTITY_NAME_FIELD_NAME},
        {Constants.TARGET_ENTITY_ID_FIELD_NAME}
        FROM {Constants.TRIPLE_TABLE_NAME}
        WHERE
        1 = 1 and del_flag='0'
        {filter_sql} 
        and {Constants.RELATIONSHIP_ID_FIELD_NAME} = '{relationship_id}' 
        and {Constants.TARGET_ENTITY_TYPE_FIELD_NAME} = '{target_entity_type}'
        and {Constants.SOURCE_ENTITY_TYPE_FIELD_NAME} = '{source_entity_type}'
        and {Constants.SOURCE_ENTITY_ID_FIELD_NAME} is not null 
        and {Constants.SOURCE_ENTITY_NAME_FIELD_NAME} is not null 
        """
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []



def load_food_entity_list_by_entity_id(entity_id_arr:list) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager

    filter_sql = ""

    db_manager = None
    try:
        if len(entity_id_arr) <= MAX_ARR_SIZE:
            filter_sql = ",".join([f"'{name}'" for name in entity_id_arr])
            filter_sql = f" AND id IN ({filter_sql}) "
        else:
            split_arr = average_set_by_size(entity_id_arr, MAX_ARR_SIZE)
            filter_list = []
            for split_set in split_arr:
                temp_filter_sql = ",".join([f"'{name}'" for name in split_set])
                temp_filter_sql = f" id IN ({temp_filter_sql}) "
                filter_list.append(temp_filter_sql)
            filter_sql = " OR ".join(filter_list)
            filter_sql = f" AND ({filter_sql}) "

        query_sql = f"""
        SELECT
        id ,entity_name ,entity_type ,way ,forbidden_for ,nutritional_value ,food_category ,
        food_taste ,food_cuisine ,food_unit ,calories ,protein ,fat ,carbo ,food_id
        FROM {Constants.ENTITY_TABLE_NAME}
        WHERE
        1 = 1 and del_flag='0' and food_category <> '调味品'
        {filter_sql}
        """
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_all_food_entity_threaded(food_id_arr:list = None) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager

    filter_sql = ""
    if food_id_arr and len(food_id_arr) > 0:
        if len(food_id_arr) <= MAX_ARR_SIZE:
            filter_sql = ",".join([f"'{food_id}'" for food_id in food_id_arr])
            filter_sql = f" AND id IN ({filter_sql}) "
        else:
            split_arr = average_set_by_size(food_id_arr, MAX_ARR_SIZE)
            filter_list = []
            for split_set in split_arr:
                temp_filter_sql = ",".join([f"'{food_id}'" for food_id in split_set])
                temp_filter_sql = f" id IN ({temp_filter_sql}) "
                filter_list.append(temp_filter_sql)
            filter_sql = " OR ".join(filter_list)
            filter_sql = f" AND ({filter_sql}) "

    query_sql = f"""
    select
    food.id ,food.entity_name ,food.entity_type ,food.way ,food.forbidden_for ,food.nutritional_value ,food.food_category ,
    food.food_taste ,food.food_cuisine ,food.food_unit ,food.calories ,food.protein ,food.fat ,food.carbo  ,food.food_id,
    '' as required_ingredient_ids
    from 
    {Constants.ENTITY_TABLE_NAME} food
    where 1=1 and food.del_flag='0' 
    and food.{Constants.ENTITY_TYPE_FIELD_NAME} = '{Constants.FOOD_ENTITY_TYPE_NAME}'
    {filter_sql}
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []



def load_food_category_combinations() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    
    query_sql = f"""
    select 
    id ,category_1 ,category_2 ,suit_weight ,reason_text ,category_1_all ,category_2_all 
    from 
    {Constants.FOOD_CATEGORY_COMBINATIONS_TABLE_NAME} 
    where 1=1 and success='1' and del_flag='0'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_meal_suitability() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager

    query_sql = f"""
    select 
    id ,food_id ,food_name ,required_ingredients ,breakfast_suit_weight ,
    lunch_suit_weight ,dinner_suit_weight ,extra_suit_weight 
    from 
    {Constants.MEAL_SUITABILITY_TABLE_NAME} 
    where 1=1 and success='1' and del_flag='0'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_food_category_meal_suitability_table_name() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    id ,category_name ,category_name_all ,breakfast_suit_weight ,lunch_suit_weight ,
    dinner_suit_weight ,extra_suit_weight 
    from 
    {Constants.FOOD_CATEGORY_MEAL_SUITABILITY_TABLE_NAME} 
    where 1=1 and success='1' and del_flag='0'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_all_home_cooked_food_list() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    
    query_sql = f"""
    select 
    source_entity_id as food_id,
    source_entity_name as food_name 
    from 
    {Constants.TRIPLE_TABLE_NAME} 
    where del_flag='0' and target_entity_id='{Constants.HOME_COOKED_CUISINES_ENTITY_ID}'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_user_suit_suisine(user_province:str) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    id ,area ,province, cuisine
    from 
    {Constants.CUISINE_PROVINCE_RELATION_TABLE} 
    where 1=1 and del_flag='0'
    """
    db_manager = None
    try:
        cuisine_list = []
        data_list = []
        with PostgreSQLManager() as db_manager:
            data_list = db_manager.query_data_list_dict(query_sql)
        if data_list:
            for item in data_list:
                if item['province'] in user_province or user_province in item['province']:
                    cuisine_list.append(item['cuisine'])
        return cuisine_list
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_forbidden_lineage_ingredient() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    source_entity_id, target_entity_id, value  
    from {Constants.TRIPLE_TABLE_NAME} 
    where relation_id='{Constants.FORBIDDEN_LINEAGE_RELATION_SHIP_ID}' 
    and target_entity_id is not null and del_flag='0';
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_food_ingredient_by_food_id(food_entity_id:str) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    food.id ,
    food.food_id,
    ingredient.required_ingredient_ids
    from 
    t_food_knowledge_graph_entity food
    LEFT JOIN ( 
        SELECT string_agg ( target_entity_id, ',' ORDER BY target_entity_id ) AS required_ingredient_ids, source_entity_id 
        FROM t_food_knowledge_graph
        WHERE relation_id = 'm3n4o5p6-3333-aaaa-bbbb-cccccccccccc' and del_flag='0' 
        GROUP BY source_entity_id 
    ) ingredient ON ingredient.source_entity_id = food.id
    where 1=1 and food.del_flag='0' 
    and food.food_id in ({food_entity_id})
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_all_food_label() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    entity_name
    from {Constants.ENTITY_TABLE_NAME} 
    where entity_type='{Constants.LABEL_ENTITY_TYPE_NAME}' 
    and del_flag='0';
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            data_list = db_manager.query_data_list_dict(query_sql)
            if data_list:
                return [item['entity_name'] for item in data_list]
            return []
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []

def load_all_drug_ingredient_taboo() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    *
    from t_food_drug_ingredient_taboo
    where 
    del_flag='0'
    order by id
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_food_entity_by_food_id(food_id:str) -> dict:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select * from {Constants.ENTITY_TABLE_NAME}
    where 1=1
    and id = '{food_id}'
    limit 1
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            data_list = db_manager.query_data_list_dict(query_sql)
            if data_list:
                return data_list[0]
            return {}
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def load_food_ingredient_list_by_food_id(food_id:str) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select target_entity_id, target_entity_name , value, unit
    from {Constants.TRIPLE_TABLE_NAME} 
    where 1=1 and relation_id='{Constants.INGREDIENT_RELATION_SHIP_ID}' 
    and del_flag='0' 
    and source_entity_id = '{food_id}'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []

def load_food_ingredient_of_fuliao_list_by_food_id(food_id:str) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select target_entity_id, target_entity_name , value, unit
    from {Constants.TRIPLE_TABLE_NAME} 
    where 1=1 and relation_id='{Constants.INGREDIENT_OF_FULIAO_RELATION_SHIP_ID}' 
    and del_flag='0' 
    and source_entity_id = '{food_id}'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []

def load_food_healthy_recipe_info() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    *
    from t_food_healthy_recipe_info
    where del_flag='0' 
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []


def t_food_healthy_recipe_and_food_relation(recipe_id:str) -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    *
    from t_food_healthy_recipe_and_food_relation
    where del_flag='0' and recipe_id = '{recipe_id}'
    order by meal
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []



def load_all_ingredient_info_list() -> list:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    *
    from {Constants.ENTITY_TABLE_NAME}
    where del_flag='0' and entity_type = '{Constants.INGREDIENT_ENTITY_TYPE_NAME}'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.query_data_list_dict(query_sql)
    except Exception as e:
        return []
    finally:
        if db_manager:
            db_manager.close_connection()
    return []



def load_ingredient_cooked_data(ingredient_name) -> dict:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    *
    from t_food_ingredient_raw_and_cooked_ratio
    where del_flag='0' and name = '{ingredient_name}'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            data_list = db_manager.query_data_list_dict(query_sql)
            if data_list and len(data_list) > 0:
                return data_list[0]
            else:
                return None
    except Exception as e:
        return None
    finally:
        if db_manager:
            db_manager.close_connection()
    return None