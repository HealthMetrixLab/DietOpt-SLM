import sys
import time
import re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from src.util.execute_llm import (execute_llm_2_analyse_preference,
                                  execute_llm_2_analyse_forbidden_data,
                                  execute_llm_analyse_disease_data,
                                  execute_llm_analyse_take_drug_data,
                                  execute_llm_2_analyse_forbidden_food_label_data,
                                  execute_llm_analyse_meal_rationality)

from config.constants import Constants

from clazz.file.file_manager_class import FileManager
from clazz.common.common_utils import CommonUtils
from clazz.utils.logger_util import logger

DEFAULT_MAX_ANALYSE_TIMES_LIMIT = 2

SPECIAL_CATEGORY_MAP = {
    "绿叶蔬菜": ["蔬菜"],
    "全谷物": ["谷物"],
    "优质蛋白": ["蛋白质"],
    "深色蔬果": ["水果","蔬菜"],
    "鱼虾": ["鱼","虾"],
    "全脂牛奶": ["牛奶"],
}

def analyse_disease_by_execute_llm_by_cons(execute_params: dict) -> set:
    extract_index = 1
    result_str = ""
    time_limit = Constants.ANALYSIS_PREFERENCE_MAX_TIME_LIMIT - 2
    if time_limit <= 1:
        time_limit = DEFAULT_MAX_ANALYSE_TIMES_LIMIT
    try:
        while True:
            result_str = execute_llm_analyse_disease_data(execute_params)
            if result_str and len(result_str) > 0:
                break
            else:
                result_str = execute_llm_analyse_disease_data(execute_params)
                extract_index += 1
                if extract_index > Constants.ANALYSIS_PREFERENCE_MAX_TIME_LIMIT:
                    break
    except Exception as e:
        logger.error(f'【调用模型分析疾病信息】------{e}')

    disease_set = set()
    if result_str and len(result_str) > 0:
        result_str = result_str.replace("，", "").replace(",", "")
        disease_arr = result_str.split("、")
        for disease in disease_arr:
            if len(disease) > 0:
                disease_set.add(disease)

    return disease_set


def analyse_take_drug_status_execute_llm_by_cons(execute_params: dict) -> list:
    execute_index = 0
    execute_result_str = ""
    result_list = []
    print(execute_params)
    try:
        while execute_index < DEFAULT_MAX_ANALYSE_TIMES_LIMIT:
            execute_index += 1
            execute_result_str = execute_llm_analyse_take_drug_data(execute_params)
            if execute_result_str and len(execute_result_str) > 0:
                execute_result_str = execute_result_str.replace("```", "")
                if CommonUtils.check_is_valid_json(execute_result_str):
                    execute_result_dict = CommonUtils.line_data_to_json(execute_result_str)
                    result_list.append(execute_result_dict)
                    break
    except Exception as e:
        logger.error(f'【调用模型分析服药情况】------调用模型分析服药情况失败：{e}')
        return None
    return result_list

def analyse_user_preference_by_execute_llm_by_cons(execute_params_dict: dict) -> dict:
    extract_result_obj = {}
    try:
        extract_index = 0
        while extract_index < Constants.ANALYSIS_PREFERENCE_MAX_TIME_LIMIT:
            extract_index += 1
            result_str = execute_llm_2_analyse_preference(execute_params_dict)
            extract_result_obj = extract_preferences(result_str)
            match_size = 0
            for key, value in extract_result_obj.items():
                if value:
                    match_size += len(value)
            if match_size > 0:
                break
    except Exception as e:
        logger.error(f'【调用模型分析偏好】------提取偏好和饮食安全信息失败：{e}')
    return extract_result_obj    



def analyse_user_forbidden_by_execute_llm_by_cons(execute_params_dict: dict) -> dict:
    extract_result_obj = {}
    try:
        extract_index = 0
        while extract_index < Constants.ANALYSIS_PREFERENCE_MAX_TIME_LIMIT:
            extract_index += 1
            forbidden_result_str = execute_llm_2_analyse_forbidden_data(execute_params_dict)
            forbidden_extract_result_obj = extract_preferences(forbidden_result_str)
            match_size = 0
            for key, value in forbidden_extract_result_obj.items():
                if value:
                    match_size += len(value)
            if match_size > 0:
                extract_result_obj.update(forbidden_extract_result_obj)
                break

    except Exception as e:
        logger.error(f'【调用模型分析偏好】------提取偏好和饮食安全信息失败：{e}')
    return extract_result_obj   

def clean_items(text, exclude_words=None):
    if exclude_words is None:
        exclude_words = {"其他", "其它", "其余", "等"}

    text = re.sub(r'（.*?）|\(.*?\)', '', text)

    items = text.split('、')
    cleaned_items = set()
    for item in items:
        for w in exclude_words:
            item = item.replace(w, '')
        item = item.strip()
        if item:
            cleaned_items.add(item)

            if item in SPECIAL_CATEGORY_MAP:
                for sub_item in SPECIAL_CATEGORY_MAP[item]:
                    cleaned_items.add(sub_item)

    return cleaned_items

def extract_preferences(text):

    preferences = {}
    if not text:
        return preferences
    lines = text.strip().split('\n')
    for line in lines:
        if '：' in line:
            key, value_str = line.split('：', 1)
            key = key.strip()
            values = set(v.strip() for v in value_str.split('、'))
            if values:
                values = clean_items("、".join(values))

            preferences[key] = values

    return preferences


def analyse_forbidden_label_by_execute_llm_by_cons(analyse_preference_cons_dict: dict) -> set:
    extract_result_obj = {}
    extract_index = 0
    try:
        while extract_index < Constants.ANALYSIS_PREFERENCE_MAX_TIME_LIMIT:
            extract_index += 1

            result_str = execute_llm_2_analyse_forbidden_food_label_data(analyse_preference_cons_dict)
            extract_result_obj = extract_preferences(result_str)
            match_size = 0
            for key, value in extract_result_obj.items():
                if value:
                    match_size += len(value)
            if match_size > 0:
                break
    except Exception as e:
        logger.error(f'【调用模型分析禁忌标签】------提取禁忌标签失败：{e}')

    label_set = set()
    if extract_result_obj:
        for key, value in extract_result_obj.items():
            if '理由' not in key:
                for label in value:
                    label_set.add(label)
    return label_set


def execute_llm_analyse_meal_rationality_by_cons(execute_params_dict: dict) -> dict:
    result_obj = {}
    try:
        check_index = 0
        while check_index < Constants.ANALYSIS_PREFERENCE_MAX_TIME_LIMIT:
            check_index += 1
            result_str = execute_llm_analyse_meal_rationality(execute_params_dict)
            if not result_str:
                continue
            if CommonUtils.check_is_valid_json(result_str):
                temp_result_obj = CommonUtils.line_data_to_json(result_str)
                if not temp_result_obj:
                    continue
                must_keys = ["最终得分", "优点", "缺陷", "不建议食物清单"]
                has_all_must_keys = all(key in temp_result_obj for key in must_keys)
                if not has_all_must_keys:
                    continue
                temp_list = temp_result_obj.get("不建议食物清单", [])
                not_recommended_food_list = []
                if temp_list and len(temp_list) > 0:
                    for item in temp_list:
                        not_recommended_food_list.append(remove_brackets(item))
                result_obj = {
                    "score": temp_result_obj.get("最终得分", None),
                    "advantages": temp_result_obj.get("优点", []),
                    "disadvantages": temp_result_obj.get("缺陷", []),
                    "not_recommended_food_list": not_recommended_food_list
                }
                break
    except Exception as e:
        logger.error(f'【调用模型分析膳食合理性】------提取膳食合理性信息失败：{e}')
    return result_obj

def remove_brackets(text: str) -> str:
    text = re.sub(r'（[^）]*）', '', text)
    text = re.sub(r'\([^)]*\)', '', text)
    return text

if __name__ == '__main__':
    print('---start---')