import sys
import time
import re
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from src.util.database_util import (
    load_ingredient_cooked_data,
)

def load_ingredient_cooked_data_by_name(ingredient_name, ingredient_weight:float) -> dict:
    cooked_data = load_ingredient_cooked_data(ingredient_name)
    if cooked_data is None:
        return None
    r_c_radio = cooked_data['r_c_radio']
    r_c_radio = r_c_radio.replace(':','/').replace('：','/')
    r_c_radio_list = r_c_radio.split('/')
    if not r_c_radio_list or len(r_c_radio_list) != 2:
        return None
    r_weight = float(r_c_radio_list[0])
    c_weight = float(r_c_radio_list[1])
    cooked_weight = ingredient_weight * c_weight / r_weight
    return {
        "cooked_weight": cooked_weight
    }