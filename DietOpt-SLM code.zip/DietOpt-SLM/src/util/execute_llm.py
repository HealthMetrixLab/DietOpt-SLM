import sys
import time
from pathlib import Path

project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)


from clazz.utils.logger_util import logger
from clazz.llm.my_nutrition_llm_executor_class import MyNutritionLLMExecutor
from config.llm_prefix import LLMPrefix
from config.diet_pattern_config import DietPatternConfig

def execute_llm_2_format_user_json(params_json_str: str) -> str | None:
    try:
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(params_json_str, LLMPrefix.FORMAT_PERSON_DETAIL_PREFIX)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None

def execute_llm_2_analyse_dietary_pattern(analyse_preference_cons_dict: dict) -> str | None:
    try:
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        text_str = f"基本信息：{analyse_preference_cons_dict['user_self_report']}\n"
        if 'dietary_pattern' in analyse_preference_cons_dict and analyse_preference_cons_dict['dietary_pattern']:
            text_str += f"膳食模式：{analyse_preference_cons_dict['dietary_pattern']}\n"
        if 'diet_history_str' in analyse_preference_cons_dict and analyse_preference_cons_dict['diet_history_str']:
            text_str += f"饮食历史：{analyse_preference_cons_dict['diet_history_str']}\n"
        if 'dietary_advice_str' in analyse_preference_cons_dict and analyse_preference_cons_dict['dietary_advice_str']:
            text_str += f"饮食建议：{analyse_preference_cons_dict['dietary_advice_str']}\n"

        prefix = LLMPrefix.DIETARY_PATTERN_PREFIX + text_str
        diet_list_str = ""
        get_diet_list = DietPatternConfig.get_diet_list()
        for diet in get_diet_list:
            diet_list_str += f"- {diet['name']}: {diet['desc']}\n"

        prefix += prefix.replace("==A膳食模式A==", diet_list_str)
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, prefix)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None

def execute_llm_2_analyse_preference(analyse_preference_cons_dict: dict) -> str | None:
    try:
        text_str = f"基本信息：{analyse_preference_cons_dict['user_self_report']}\n"
        if 'dietary_pattern' in analyse_preference_cons_dict and analyse_preference_cons_dict['dietary_pattern']:
            text_str += f"膳食模式：{analyse_preference_cons_dict['dietary_pattern']}\n"
        if 'diet_history_str' in analyse_preference_cons_dict and analyse_preference_cons_dict['diet_history_str']:
            text_str += f"饮食历史：{analyse_preference_cons_dict['diet_history_str']}\n"
        if 'dietary_advice_str' in analyse_preference_cons_dict and analyse_preference_cons_dict['dietary_advice_str']:
            text_str += f"饮食建议：{analyse_preference_cons_dict['dietary_advice_str']}\n"
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, LLMPrefix.PREFERENCE_PREFIX)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None


def execute_llm_2_analyse_user_province_by_user_address(text_str: str) -> str | None:
    try:
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, LLMPrefix.ANALYSE_PROVINCE_PREFIX)
        if result_str:
            result_str = result_str.strip().replace("结果：", "")
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None


def execute_llm_by_cons(text_str: str, llm_prefix: str) -> str | None:
    try:
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, llm_prefix)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None



def execute_llm_2_analyse_forbidden_data(params_dict: dict) -> str | None:
    try:
        user_self_report = params_dict.get("user_self_report", "")
        dietary_pattern = params_dict.get("dietary_pattern", "")
        text_str = f"基本信息：{user_self_report}\n膳食模式：{dietary_pattern}"
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, LLMPrefix.ANALYSIS_FORBIDDEN_PREFIX)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None


def execute_llm_2_analyse_forbidden_food_label_data(params_dict: dict) -> str | None:
    try:
        user_self_report = params_dict.get("user_self_report", "")
        dietary_pattern = params_dict.get("dietary_pattern", "")
        text_str = f"基本信息：{user_self_report}\n膳食模式：{dietary_pattern}"
        if 'dietary_advice_str' in params_dict and params_dict['dietary_advice_str']:
            dietary_advice_str = params_dict.get("dietary_advice_str", "")
            text_str += f"\n饮食建议：{dietary_advice_str}"
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, LLMPrefix.ANALYSIS_FORBIDDEN_FOOD_LABEL_PREFIX)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None


def execute_llm_analyse_disease_data(params_dict: dict) -> str | None:
    try:
        user_self_report = params_dict.get("user_self_report", "")
        text_str = f"基本信息：{user_self_report}"
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, LLMPrefix.ANALYSE_DISEASE_LLM_PREFIX)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None


def execute_llm_analyse_take_drug_data(params_dict: dict) -> str | None:
    try:
        take_drug_status = params_dict.get("take_drug_status", "")
        if not take_drug_status or take_drug_status.strip() == "":
            return None
        text_str = f"{take_drug_status}"
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, LLMPrefix.ANALYSE_TAKE_DRUG_LLM_PREFIX)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None


def execute_llm_analyse_meal_rationality(params_dict: dict) -> str | None:
    try:
        user_self_report = params_dict.get("user_self_report", "")
        meal_info_str = params_dict.get("meal_info_str", "")
        text_str = LLMPrefix.ANALYSE_MEAL_RATIONALITY_LLM_INPUT_STR.format(
            user_self_report=user_self_report,
            meal_info_str=meal_info_str,
            dietary_pattern=params_dict.get("dietary_pattern", ""),
        )
        my_nutrition_llm_executor = MyNutritionLLMExecutor.get_instance()
        result_str = my_nutrition_llm_executor.default_modell_execute_llm(text_str, LLMPrefix.ANALYSE_MEAL_RATIONALITY_LLM_PREFIX)
        return result_str
    except Exception as e:
        logger.error(f"执行出错，错误原因如下：{e}")
    return None


if __name__ == "__main__":
    print("---start---")
