import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)


def save_dietary_solution_history(serial_number:str, client_ip:str, user_id:str) -> int:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
 
    insert_sql = f"""
    insert into t_dietary_solution_history (serial_number, client_ip,status,user_id)
    values ('{serial_number}', '{client_ip}','0','{user_id}')
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.execute_sql(insert_sql)
    except Exception as e:
        return 0
    finally:
        if db_manager:
            db_manager.close_connection()

def save_dietary_solution_history_params(history_id:int, params_json_str:str) -> int:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    insert_sql = f"""
    insert into t_dietary_solution_history_params (history_id, content)
    values ({history_id}, '{params_json_str}')
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.execute_sql(insert_sql)
    except Exception as e:
        return 0
    finally:
        if db_manager:
            db_manager.close_connection()


def save_dietary_solution_history_result(history_id:int, result_json_str:str) -> int:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    insert_sql = f"""
    insert into t_dietary_solution_history_result (history_id, result)
    values ({history_id}, '{result_json_str}')
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.execute_sql(insert_sql)
    except Exception as e:
        return 0
    finally:
        if db_manager:
            db_manager.close_connection()


def query_dietary_solution_history_by_serial_number(serial_number:str) -> dict|None:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    * 
    from t_dietary_solution_history 
    where serial_number = '{serial_number}' and del_flag='0'  
    order by create_time desc limit 1
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
           data_list = db_manager.query_data_list_dict(query_sql)
           if data_list:
               return data_list[0]
           else:
               return None
    except Exception as e:
        return None
    finally:
        if db_manager:
            db_manager.close_connection()

def query_dietary_solution_history_result_by_serial_number(serial_number:str) -> dict|None:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select  
    h.*, r.result
    from t_dietary_solution_history h, t_dietary_solution_history_result r 
    where h.id=r.history_id and h.del_flag='0' and r.del_flag='0' and h.serial_number='{serial_number}'
    order by r.create_time desc 
    limit 1
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
           data_list = db_manager.query_data_list_dict(query_sql)
           if data_list:
               return data_list[0]
           else:
               return None
    except Exception as e:
        return None
    finally:
        if db_manager:
            db_manager.close_connection()

def query_waiting_deal_dietary_solution_history() -> dict|None:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    h.*,p.content
    from t_dietary_solution_history h, t_dietary_solution_history_params p 
    where h.id=p.history_id and h.del_flag='0' and p.del_flag='0' and h.status='0' and p.content is not null
    order by p.update_time desc
    limit 1
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
           data_list = db_manager.query_data_list_dict(query_sql)
           if data_list:
               return data_list[0]
           else:
               return None
    except Exception as e:
        return None
    finally:
        if db_manager:
            db_manager.close_connection()

def update_dietary_solution_history_status(history_id:int, status:str) -> int:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    update_sql = f"""
    update t_dietary_solution_history set status='{status}', update_time=now() where id={history_id}
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
            return db_manager.execute_sql(update_sql)
    except Exception as e:
        return 0
    finally:
        if db_manager:
            db_manager.close_connection()

def check_is_running() -> bool:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select count(*) as sl from t_dietary_solution_history where del_flag='0' and status='1'
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
           data_list = db_manager.query_data_list_dict(query_sql)
           if data_list:
               return data_list[0]['sl'] <= 0
           else:
               return False
    except Exception as e:
        return False
    finally:
        if db_manager:
            db_manager.close_connection()


def query_dietary_solution_history_detail_by_serial_number(serial_number: str) -> dict|None:
    from clazz.database.postgre_sql_manager_class import PostgreSQLManager
    query_sql = f"""
    select 
    h.*,p.content
    from t_dietary_solution_history h, t_dietary_solution_history_params p 
    where h.id=p.history_id and h.del_flag='0' and p.del_flag='0' and p.content is not null
    and serial_number = '{serial_number}'
    order by p.update_time desc
    limit 1
    """
    db_manager = None
    try:
        with PostgreSQLManager() as db_manager:
           data_list = db_manager.query_data_list_dict(query_sql)
           if data_list:
               return data_list[0]
           else:
               return None
    except Exception as e:
        return None
    finally:
        if db_manager:
            db_manager.close_connection()