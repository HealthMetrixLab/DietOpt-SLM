import sys
import time
from pathlib import Path

project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)


from src.util.database_util import load_all_food_entity_threaded
from src.util.knowledge_graph_util import load_food_list_by_cons

from clazz.database.postgre_sql_manager_class import PostgreSQLManager
from clazz.utils.logger_util import logger
from clazz.common.common_utils import CommonUtils

def check_solver_diet_param_is_valid(params_json: dict):
    check_result = {
        'code': 500,
        'success': False,
        'msg': '校验出现问题！',
        'data': {}
    }
    if params_json is None:
        check_result['msg'] = '请求参数不能为空！'
        return check_result

    params_field_list = ['query_type','user_self_report','diet_history', 'user_info_json']

    for params_field in params_field_list:
        if params_field not in params_json:
            check_result['msg'] = f'请求参数{params_field}不能为空！'
            return check_result
    require_field_list = ['query_type']
    for require_field in require_field_list:
        if params_json[require_field] is None:
            check_result['msg'] = f'请求参数{require_field}不能为空！'
            return check_result

    query_type = params_json['query_type']
    if query_type not in ['user_info_json', 'self_report']:
        check_result['msg'] = f'请求参数query_type值{query_type}不合法！'
        return check_result

    user_info_json = params_json['user_info_json']
    if user_info_json is None:
        check_result['msg'] = f'请求参数user_info_json不能为空(query_type={query_type})！'
        return check_result

    if query_type == 'self_report':
        user_self_report = params_json['user_self_report']
        if user_self_report is None:
            check_result['msg'] = f'请求参数user_self_report不能为空(query_type={query_type})！'
            return check_result

    check_result = {
        'code': 200,
        'success': True,
        'msg': '校验通过！',
        'data': {}
    }

    return check_result

