import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)


from config.constants import Constants
from clazz.utils.logger_util import logger

from src.util.database_util import (
    load_food_entity_by_food_id,
    load_food_ingredient_list_by_food_id,
    load_food_ingredient_of_fuliao_list_by_food_id)
from src.util.common_func import load_ingredient_cooked_data_by_name

def analyse_meal_info(meal_info_dict: dict) -> dict:
    result_dict = {}
    if not meal_info_dict:
        logger.error("meal_info_dict is empty")
        return result_dict
    food_plan = meal_info_dict.get("food_plan", {})
    meal_info_list = []
    meal_arr = []
    meal_detail_list = []
    calories_day = 0.0
    protein_day = 0.0
    fat_day = 0.0
    carb_day = 0.0

    food_name_id_check_dict = {}

    for key in Constants.MEAL_NAME_MAP.keys():
        meal_arr.append(key)

    for meal_type in meal_arr:
        every_meal_food_arr = []
        every_meal_ingredient_check = {}
        every_meal_ingredient_arr = []
        temp_str = f' -- {Constants.MEAL_NAME_MAP[meal_type]}'
        meal_info_list.append(temp_str)
        #print(temp_str)
        protein_meal = 0.0
        fat_meal = 0.0
        carb_meal = 0.0
        
        meal_food_raw_weight_float = 0.0
        meal_food_cooked_weight_float = 0.0
        day_result_obj = {}
        
        for item in food_plan.get(meal_type, []):
            food_id = item.get("food_entity_id", "")

            food_data = load_food_entity_by_food_id(food_id)
            if food_data is None:
                print(f'未找到食物ID：{food_id}的详细信息')
                continue
                        
            food_name = food_data['entity_name']
            food_name_id_check_dict[food_name] = food_id
            ingredient_data_list = load_food_ingredient_list_by_food_id(food_data['id'])
            #print(f"---{food_data['id']},---{food_data['entity_name']}")
            if ingredient_data_list is None:
                print(f'未找到食物ID：{food_id}的食材信息')
                continue

            food_nutrition = item['nutrition']
            calories_day += float(food_nutrition['calories'])
            protein_day += float(food_nutrition['protein'])
            fat_day += float(food_nutrition['fat'])
            carb_day += float(food_nutrition['carb'])

            protein_meal += float(food_nutrition['protein'])
            fat_meal += float(food_nutrition['fat'])
            carb_meal += float(food_nutrition['carb'])
            
            food_name = item.get("name", "")
            amount = item.get("amount", "")
            amount = amount.replace('份', '')
            unit = item.get("unit", "")
            unit = unit.replace('每份', '').replace('g', '')

            amount_float = float(amount)
            unit_float = float(unit)
            all_weight = amount_float * unit_float
            food_raw_weight_int = int(all_weight)
            meal_food_raw_weight_float += food_raw_weight_int

            food_cooked_weight_float = 0.0

            origin_food_unit_str = food_data['food_unit']
            origin_food_unit_float = float(origin_food_unit_str)

            scaling = food_raw_weight_int / origin_food_unit_float

            max_ingredient_weight = 0
            using_ingredient_weight = 0

            for ingredient in ingredient_data_list:
                ingredient_name = ingredient['target_entity_name']
                ingredient_value = ingredient['value']
                ingredient_value_float = float(ingredient_value)
                ingredient_weight = ingredient_value_float * scaling
                ingredient_weight_int = int(ingredient_weight)

                cooked_data = load_ingredient_cooked_data_by_name(ingredient_name, ingredient_weight_int)
                if cooked_data is not None:
                    food_cooked_weight_float += cooked_data['cooked_weight']
                    

                ingredient['real_weight'] = ingredient_weight_int
                using_ingredient_weight += ingredient_weight_int
                if ingredient_weight_int > max_ingredient_weight:
                    max_ingredient_weight = ingredient_weight_int

                    
            meal_food_cooked_weight_float += food_cooked_weight_float


            interval_weight = food_raw_weight_int - using_ingredient_weight
            if interval_weight < 0:
                interval_weight = 0 - using_ingredient_weight

            check_index = 0
            for ingredient in ingredient_data_list:
                real_weight = ingredient['real_weight']
                ingredient['value'] = real_weight
                if max_ingredient_weight == real_weight and check_index == 0:
                    check_index += 1
                    temp_data = max_ingredient_weight + interval_weight
                    ingredient['value'] = str(temp_data).replace('.0', '')

            using_ingredient_arr = []
            for ingredient in ingredient_data_list:
                using_ingredient_arr.append(f"{ingredient['target_entity_name']} ({ingredient['real_weight']}克)")
                ingredient_name = ingredient['target_entity_name']
                if ingredient_name not in every_meal_ingredient_check:
                    every_meal_ingredient_check[ingredient_name] = 0
                every_meal_ingredient_check[ingredient_name] += int(ingredient['value'])
            
            fuliao_data_arr =load_food_ingredient_of_fuliao_list_by_food_id(food_id)
            fuliao_data_str = ""
            if fuliao_data_arr and len(fuliao_data_arr) > 0:
                for item in fuliao_data_arr:
                    if '适量' == item['value']:
                        fuliao_data_str += f"{item['target_entity_name']} (适量)，"
                    else:
                        fuliao_data_str += f"{item['target_entity_name']} ({item['value']}克)，"
             
            temp_str = f'食物名称：{food_name}({int(food_cooked_weight_float)}克，生重{int(food_raw_weight_int)}克)，使用的食材：{using_ingredient_arr}'
            if fuliao_data_str:
                temp_str += f'，使用辅料：{fuliao_data_str}'
            meal_info_list.append(temp_str)

            food_calories_str = food_data['calories']
            food_protein_str = food_data['protein']
            food_fat_str = food_data['fat']
            food_carbo_str = food_data['carbo']
            food_calories_float = float(food_calories_str)
            food_protein_float = float(food_protein_str)
            food_fat_float = float(food_fat_str)
            food_carbo_float = float(food_carbo_str)

            food_calories_float = food_calories_float * scaling
            food_protein_float = food_protein_float * scaling
            food_fat_float = food_fat_float * scaling
            food_carbo_float = food_carbo_float * scaling

            food_calories_int = int(food_calories_float)
            food_protein_int = int(food_protein_float)
            food_fat_int = int(food_fat_float)
            food_carbo_int = int(food_carbo_float)
            
            every_meal_food_arr.append({
                'food_name': f"{food_name}(生重{int(food_raw_weight_int)}克，熟重{int(food_cooked_weight_float)}克)",
                'calories': food_calories_int,
                'protein': food_protein_int,
                'fat': food_fat_int,
                'carbo': food_carbo_int,
            })
        protein_meal = round(protein_meal, 2)
        fat_meal = round(fat_meal, 2)
        carb_meal = round(carb_meal, 2)
        meal_detail_list.append({
            'meal_type': meal_type,
            'protein': protein_meal,
            'fat': fat_meal,
            'carbo': carb_meal,
            'food_raw_weight_float': meal_food_raw_weight_float,
            'food_weight_float': meal_food_cooked_weight_float,
        })
        for ingredient_name, weight in every_meal_ingredient_check.items():
            ingredient_name = ingredient_name.replace('\x7f', '')
            every_meal_ingredient_arr.append({
                'ingredient_name': ingredient_name,
                'weight': weight,
            })

        day_result_obj[meal_type] = {
            'food_arr': every_meal_food_arr,
            'ingredient_arr': every_meal_ingredient_arr,
            'nutrition_info': {
                'protein': protein_meal,
                'fat': fat_meal,
                'carbo': carb_meal,
            }
        }

    special_energy_int = Constants.DEFAULT_REDUCTION_ENERGY

    calories_day = round(calories_day, 2)
    calories_day = calories_day + special_energy_int
    protein_day = round(protein_day, 2)
    fat_day = round(fat_day, 2)
    carb_day = round(carb_day, 2)
    temp_str = f'今日营养统计：蛋白质={protein_day}克，脂肪={fat_day}克(每日用油约25克)，碳水={carb_day}克'
    meal_info_list.append(temp_str)
    protein_calories_day = protein_day * 4 / calories_day
    fat_calories_day = (fat_day * 9 + 225) / calories_day
    carb_calories_day = carb_day * 4 / calories_day

    temp_str = f'今日能量配比之和：{protein_calories_day + fat_calories_day + carb_calories_day:.4f}'
    meal_info_list.append(temp_str)
    
    temp_str = f'其中，蛋白质:{protein_calories_day:.4f}，脂肪:{fat_calories_day:.4f}，碳水:{carb_calories_day:.4f}'
    meal_info_list.append(temp_str)

    temp_str = f'今日营养详情：{len(meal_detail_list)} 餐'
    meal_info_list.append(temp_str)

    food_weight_arr = []
    food_cooked_weight_arr = []
    for meal_detail in meal_detail_list:
        meal_type = meal_detail['meal_type']
        protein = meal_detail['protein']
        fat = meal_detail['fat']
        carbo = meal_detail['carbo']
        food_raw_weight_float = meal_detail['food_raw_weight_float']
        food_weight_float = meal_detail['food_weight_float']
        food_weight_arr.append(int(food_weight_float))
        food_cooked_weight_arr.append(int(food_raw_weight_float))
        temp_str = f' - {Constants.MEAL_NAME_MAP[meal_type]}，生重{int(food_raw_weight_float)}克，熟重{int(food_weight_float)}克。营养信息：蛋白质={protein:<5}克，脂肪={fat:<5}克，碳水={carbo:<6}克，熟重={int(food_weight_float):<4}克'
        meal_info_list.append(temp_str)

    result_dict = {
        'meal_info_list': meal_info_list,
        'day_result_obj': day_result_obj,
        'total_nutrition': {
            'calories': calories_day,
            'protein': protein_day,
            'fat': fat_day,
            'carbo': carb_day,
        },
        'food_name_id_check_dict': food_name_id_check_dict,
    }
    return result_dict