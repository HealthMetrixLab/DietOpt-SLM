import json
import sys
import time
from pathlib import Path

project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)


from clazz.common.common_utils import CommonUtils
from clazz.common.result_manager_class import ResultManager
from clazz.utils.logger_util import logger


def solver_diet_main_function_of_sync(client_ip: str, params_json: dict) -> dict:
    from src.util.valid_data_util import check_solver_diet_param_is_valid
    from src.util.sync_work_process_database_util import save_dietary_solution_history, save_dietary_solution_history_params,query_dietary_solution_history_by_serial_number
    final_result = {}
    serial_number = CommonUtils.get_uuid()
    start_time = time.time()
    try:
        # 1、校验参数
        check_result = check_solver_diet_param_is_valid(params_json)
        if not check_result['success']:
            logger.error(f"【求解器-获取七日饮食数据(solver/dietSync)】---校验参数失败，{check_result['msg']}")
            return ResultManager.error_with_code(check_result['code'], check_result['msg'], None, serial_number)

        # 2、保存求解历史
        user_id = ''
        user_info = params_json.get('user_info_json', {})
        if 'id' in user_info and user_info['id']:
            user_id = str(user_info['id'])
        save_flag = save_dietary_solution_history(serial_number, client_ip, user_id)
        logger.info(f"【求解器-获取七日饮食数据(solver/dietSync)】---保存求解历史：{save_flag}")
        solution_history_obj = query_dietary_solution_history_by_serial_number(serial_number)
        if not solution_history_obj:
            logger.error(f"【求解器-获取七日饮食数据(solver/dietSync)】---保存求解历史，serial_number：{serial_number}")
            return ResultManager.error_with_code(406, "保存求解历史失败！", None, serial_number)

        # 3、保存参数结果
        params_json_str = json.dumps(params_json, ensure_ascii=False)
        history_id = solution_history_obj['id']
        save_flag = save_dietary_solution_history_params(history_id, params_json_str)
        logger.info(f"【求解器-获取七日饮食数据(solver/dietSync)】---保存参数结果：{save_flag}")

        final_result['serial_number'] = serial_number
        logger.info(
            f"【求解器-获取七日饮食数据(solver/dietSync)】------耗时：{time.time() - start_time:.2f} 秒，客户端IP：{client_ip}")
        return ResultManager.success("访问成功！", final_result, serial_number)
    except Exception as e:
        logger.error(f"【求解器-获取七日饮食数据(solver/dietSync)】---访问失败,{e}")
    return ResultManager.error("访问失败！请联系管理员！", {}, serial_number)


def query_diet_main_function_of_sync_result(client_ip: str, params_json: dict) -> dict:
    from src.util.sync_work_process_database_util import query_dietary_solution_history_by_serial_number,query_dietary_solution_history_result_by_serial_number
    serial_number = CommonUtils.get_uuid()
    final_result = {}
    start_time = time.time()
    try:
        if not params_json or 'serial_number' not in params_json:
            logger.error(f"【求解器-查询求解器-获取七日饮食数据异步结果(solver/query_diet)】---校验参数失败，serial_number不能为空")
            return ResultManager.error_with_code(400, "校验参数失败，serial_number不能为空", None, serial_number)

        query_serial_number = params_json['serial_number']
        solution_history_obj = query_dietary_solution_history_by_serial_number(query_serial_number)
        if not solution_history_obj:
            logger.error(f"【求解器-查询求解器-获取七日饮食数据异步结果(solver/query_diet)】---检索的求解历史不存在：{query_serial_number}")
            return ResultManager.error_with_code(404, "检索的求解历史不存在！", None, serial_number)

        # -1-执行失败，0-未执行，1-执行中，2-执行成功
        if solution_history_obj['status'] != "2":
            logger.error(f"【求解器-查询求解器-获取七日饮食数据异步结果(solver/query_diet)】---求解历史正在进行中：{query_serial_number}")
            return ResultManager.error_with_code(406, "求解历史正在进行中！", None, serial_number)

        solution_history_result = query_dietary_solution_history_result_by_serial_number(query_serial_number)
        if not solution_history_result:
            logger.error(f"【求解器-查询求解器-获取七日饮食数据异步结果(solver/query_diet)】---检索的求解历史结果不存在：{query_serial_number}")
            return ResultManager.error_with_code(404, "检索的求解历史结果不存在！", None, serial_number)

        result_json_str = solution_history_result['result']
        if not result_json_str:
            logger.error(f"【求解器-查询求解器-获取七日饮食数据异步结果(solver/query_diet)】---求解历史结果为空：{query_serial_number}")
            return ResultManager.error_with_code(404, "求解历史结果为空！", None, serial_number)
        final_result = json.loads(result_json_str)
        logger.info(
            f"【求解器-获取七日饮食数据(solver/dietSync)】------耗时：{time.time() - start_time:.2f} 秒，客户端IP：{client_ip}")
        return ResultManager.success("访问成功！", final_result, serial_number)
    except Exception as e:
        logger.error(f"【求解器-获取七日饮食数据(solver/dietSync)】---访问失败,{e}")

    return ResultManager.error("访问失败！请联系管理员！", {}, serial_number)