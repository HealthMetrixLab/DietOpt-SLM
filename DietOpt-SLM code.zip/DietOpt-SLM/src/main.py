import sys
from pathlib import Path
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
import time
import asyncio
from concurrent.futures import ProcessPoolExecutor
from apscheduler.schedulers.asyncio import AsyncIOScheduler

project_root = str(Path(__file__).parent.parent)
sys.path.append(project_root)

from clazz.common.result_manager_class import ResultManager

from config.constants import Constants

from src.schedule.diet_solver_schedule import diet_solver_schedule_main_function

# fastapi 应用
app = FastAPI()

executor = ProcessPoolExecutor(max_workers=Constants.SOLVER_MAX_CONCURRENCY)


scheduler = AsyncIOScheduler()
scheduler.add_job(diet_solver_schedule_main_function, 'interval', seconds=60)
#scheduler.start()

@app.post("/solver/diet")
async def solver_diet_inter(request: Request, params_json: dict):
    from src.work_process import solver_diet_main_function
    client_ip = get_client_ip(request)
    loop = asyncio.get_running_loop()
    result = await loop.run_in_executor(executor, solver_diet_main_function, client_ip, params_json) 
    return result

def get_client_ip(request):
    x_forwarded_for = request.headers.get("x-forwarded-for")
    if not x_forwarded_for:
        return request.client.host
    return x_forwarded_for.split(",")[0]


@app.post("/solver/testPost")
def solver_test_inter(request: Request, params_json: dict):
    return ResultManager.success("访问成功！", params_json)

@app.get("/solver/testGet")
def solver_test_inter_get(request: Request, params_json: dict):
    return ResultManager.success("访问成功！", params_json)


@app.post("/solver/diet_sync")
async def solver_diet_inter_sync(request: Request, params_json: dict):
    from src.sync_work_process import solver_diet_main_function_of_sync
    return solver_diet_main_function_of_sync(get_client_ip(request), params_json)

@app.post("/solver/query_diet")
async def query_diet(request: Request, params_json: dict):
    from src.sync_work_process import query_diet_main_function_of_sync_result
    return query_diet_main_function_of_sync_result(get_client_ip(request), params_json)

@app.post("/solver/solver_by_serial_number")
async def diet_solver_inter_by_serial_number(request: Request, params_json: dict):
    from src.schedule.diet_solver_schedule_inter import diet_solver_inter_by_serial_number
    return diet_solver_inter_by_serial_number(get_client_ip(request), params_json)