import sys
from pathlib import Path


project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from ortools.sat.python import cp_model
from clazz.utils.logger_util import logger
from config.constants import Constants
from src.solver.solver_constraint.hyperglycemia_constraint_of_first_stage import add_constraint_of_the_first_stage_hyperglycemia
from src.solver.solver_constraint.common_constraint_of_first_stage import add_constraint_of_the_first_stage_common

def add_constraint_of_the_first_stage(model, cons_dict:dict):
  
    SCALE_FACTOR = Constants.SCALE_FACTOR

    logger.info(f"【求解器】----添加第一阶段的约束条件----（开始）")
    health_risk_arr = cons_dict["health_risk_arr"]
    
    day_name = cons_dict["day_name"]
    include_snack = cons_dict["include_snack"]
    meal_keys = cons_dict["meal_keys"]
    serving_increment = cons_dict["serving_increment"]

    type_info = cons_dict["type_info"]

    num_day = len(day_name)
    num_type = len(type_info["type_data_flat"])
    type_category_list = type_info["type_category_list"]
    type_scaled_u_per_increment = type_info["type_scaled_u_per_increment"]
    category_list = type_info["type_category_list"]
    context_data = type_info["context_data"]
    type_pairing_data = type_info["type_pairing_data"]


    y: dict[int, dict[str, dict[int, cp_model.IntVar]]] = {}
    var_count = 0
    var_dict = {} 
    logger.info(f"【求解器】----添加第一阶段的约束条件----health_risk_arr: {health_risk_arr}")

    if "高血糖" in health_risk_arr or "糖尿病" in health_risk_arr:
        logger.warning(f"【求解器】----添加第一阶段的约束条件----高血糖")
        model,y,cons_count =add_constraint_of_the_first_stage_hyperglycemia(model, cons_dict)
    else:
        logger.warning(f"【求解器】----添加第一阶段的约束条件----其他通用约束")
        model,y,cons_count = add_constraint_of_the_first_stage_common(model, cons_dict)

    pref_expr = sum(type_scaled_u_per_increment[i] * y[d][m][i]
                    for d in range(num_day) for m in meal_keys if m in y[d]
                    for i in range(num_type) if i in y[d][m])
    N_pref = 1 / type_info["type_scaled_u_per_increment_max"]

    pairing_expr = 0
    for d in range(num_day):
        for m in meal_keys:
            if m in y[d]:
                for i in range(num_type):
                    if i in y[d][m]:
                        for j in range(num_type):
                            if j in y[d][m]:
                                pair_ij = model.NewIntVar(
                                    0, 1000,
                                    f"pair_ij_d{d}_m{m}_i{i}_j{j}")
                                model.AddMultiplicationEquality(
                                    pair_ij, [y[d][m][i], y[d][m][j]])
                                pairing_expr += type_pairing_data[category_list[i][-1]][category_list[j][-1]] \
                                    * SCALE_FACTOR * serving_increment * SCALE_FACTOR * pair_ij
    N_pairing = 1 / type_info["type_pairing_data_max"]

    context_expr = sum(context_data[i][m] * y[d][m][i]
                        for d in range(num_day) for m in meal_keys
                        if m in y[d] for i in range(num_type)
                        if i in y[d][m])
    N_context = 1 / type_info["context_data_max"]
    objective_expr = pref_expr * N_pref + pairing_expr * N_pairing + context_expr * N_context
    model.Maximize(objective_expr)

    logger.info(f"【求解器】----添加第一阶段的约束条件----（结束）")
    return model, y, cons_count

if __name__ == '__main__':
    pass