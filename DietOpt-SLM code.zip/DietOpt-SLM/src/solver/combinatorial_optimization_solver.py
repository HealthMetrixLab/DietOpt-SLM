import sys
import time
from pathlib import Path
import re
import asyncio
from concurrent.futures import ProcessPoolExecutor

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from config.solver_dictionary import DictUtil
from config.constants import Constants

from src.solver.main_solver_process import execute_solver
from src.util.knowledge_graph_util import load_forbidden_lineage_ingredient_obj
from src.util.database_util import load_food_ingredient_by_food_id

from clazz.common.result_manager_class import ResultManager

from clazz.file.file_manager_class import FileManager
from clazz.utils.logger_util import logger

export_path = './user_analysis_results'


def execute_solver_async(solver_params: dict) -> dict:
    start_time = time.time()
    logger.info("==============================执行组合优化求解器(开始)======================================")
    success = solver_params.pop("success", None)

    user_info_params = solver_params['user_info']
    user_info_params = check_user_info_params(user_info_params)

    solver_params['user_info'] = user_info_params

    logger.info(f"【组合优化求解器】用户信息请求参数：\n{solver_params['user_info']}")

    dietary_pattern = solver_params['user_info'].get("dietary_pattern", "")
    dietary_pattern_name = solver_params['user_info'].get("dietary_pattern_name", "")
    logger.info(f"【组合优化求解器】用户膳食模式：{dietary_pattern}，膳食模式名称：{dietary_pattern_name}")

    is_save_main_process_result = solver_params.get("is_save_main_process_result", "0")
    logger.info(f"【组合优化求解器】是否保存主工作流程结果到文件：{is_save_main_process_result}")
    if is_save_main_process_result == 1 or is_save_main_process_result == '1':
        serial_number = solver_params.get("serial_number", "")
        save_main_process_result_to_file(solver_params, solver_params['user_info'].get("id", "unknown_user"),
                                         serial_number)

    food_matching_relationship_obj = extract_food_matching_relationship(solver_params.get("alternative_foods", {}))
    logger.info(f"【组合优化求解器】提取食物匹配关系完成，食物匹配关系数量：{len(food_matching_relationship_obj)}")

    check_obj = load_forbidden_lineage_ingredient_obj()

    format_solver_result = {}

    solver_index = 1

    while True:
        logger.info(f"【组合优化求解器】校验求解器结果，第{solver_index}次求解！")
        final_result = {}

        solver_result = load_execute_solver_result(solver_params)

        format_solver_result = format_solver_result_fun(solver_result, food_matching_relationship_obj)

        logger.info(f"【组合优化求解器】校验求解器结果，食材冲突标识(开始)")
        check_food_ingredient_conflict_flag = check_food_ingredient_conflict(format_solver_result, check_obj)
        logger.info(f"【组合优化求解器】校验求解器结果，食材冲突标识：{check_food_ingredient_conflict_flag}")
        if not check_food_ingredient_conflict_flag:
            break
        logger.info(f"【组合优化求解器】校验求解器结果，发现食材冲突---------重新求解！")
        solver_index += 1

        if solver_index > 5:
            return ResultManager.error_with_code(503, "【组合优化求解器】校验求解器结果，超过最大求解次数！")

    if format_solver_result and format_solver_result['success']:
        final_result = format_solver_result['data']
        final_result['dietary_pattern'] = dietary_pattern
        final_result['dietary_pattern_name'] = dietary_pattern_name

    else:
        return format_solver_result

    logger.info(f"【组合优化求解器】------耗时：{time.time() - start_time:.2f} 秒")
    logger.info("==============================执行组合优化求解器(结束)======================================")
    return ResultManager.success("访问成功！", final_result)


def save_main_process_result_to_file(main_process_result: dict, user_id: str, serial_number: str) -> None:
    year_mondth_day_str = time.strftime('%Y%m%d')
    file_path = f"{export_path}/{year_mondth_day_str}_main_process_result/{user_id}_main_result_{serial_number}.json"

    FileManager.write_json_to_file(main_process_result, file_path)
    logger.info(f"【保存主工作流程结果到文件】------文件路径：{file_path}")
    return


def format_solver_result_fun(solver_result: dict, food_matching_relationship_obj: dict) -> dict:
   
    if not solver_result or len(solver_result) == 0:
        return ResultManager.error_with_code(503, "【组合优化求解器】返回结果为空！", solver_result)

    final_result = {}

    optimal_meal_plan = solver_result.get('optimal_meal_plan', {})

    origin_solve_dialog = optimal_meal_plan.get('solve_dialog', {})
    origin_weekly_plan = optimal_meal_plan.get('weekly_plan', {})

    nutrition_solver_params = optimal_meal_plan.get('nutrition_solver_params', {})

    week_day_arr = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']

    check_week_day_is_valid = {}
    for week_day in week_day_arr:
        check_week_day_is_valid[week_day] = -1

    solver_result_type_map = {
        "FEASIBLE": 1,
        "OPTIMAL": 2,
        "INFEASIBLE": -1,
    }

    first_stage_status = origin_solve_dialog.get('first_stage', {}).get('status', 'INFEASIBLE')

    if solver_result_type_map[first_stage_status] and solver_result_type_map[first_stage_status] < 0:
        logger.error(f"【第一阶段】未找到可行解！origin_solve_dialog: {origin_solve_dialog}")
        return ResultManager.error_with_code(501, "【第一阶段】未找到可行解！", final_result)

    second_stage = origin_solve_dialog['second_stage']
    if second_stage:
        for week_day in week_day_arr:
            day_result = second_stage.get(week_day, {})
            day_status = day_result.get('status', None)
            if day_status:
                day_result_type = solver_result_type_map.get(day_status, -1)
                if day_result_type > 0:
                    check_week_day_is_valid[week_day] = day_result_type

    has_valid_day = False
    for week_day in week_day_arr:
        if check_week_day_is_valid.get(week_day, -1) > 0:
            has_valid_day = True
            break

    if not has_valid_day:
        logger.error(f"【第二阶段】未找到可行解！origin_solve_dialog: {origin_solve_dialog}")
        return ResultManager.error_with_code(502, "【第二阶段】未找到可行解！", final_result)

    final_week_day_arr = []
    for week_day in week_day_arr:
        day_plan = origin_weekly_plan.get(week_day, {})

        breakfast = []
        lunch = []
        dinner = []
        snack = []
        nutrition = {}

        this_day_is_valid = check_week_day_is_valid.get(week_day, -1)

        if day_plan and this_day_is_valid > 0:

            food_plan = day_plan.get('food_plan', {})

            breakfast = format_one_meal_food_list(food_plan.get('breakfast', []), food_matching_relationship_obj)
            lunch = format_one_meal_food_list(food_plan.get('lunch', []), food_matching_relationship_obj)
            dinner = format_one_meal_food_list(food_plan.get('dinner', []), food_matching_relationship_obj)
            snack = format_one_meal_food_list(food_plan.get('snack', []), food_matching_relationship_obj)

            nutrition = day_plan.get('nutrition', {})
        else:
            if not day_plan:
                logger.error("【第二阶段】当前日饮食计划为空！")
            if this_day_is_valid <= 0:
                logger.error(f"【第二阶段】当前日饮食计划无可行解！week_day: {week_day}")

        one_day_plan = {
            "day": week_day,
            "breakfast": breakfast,
            "lunch": lunch,
            "dinner": dinner,
            "snack": snack,
            "nutrition": nutrition
        }
        final_week_day_arr.append(one_day_plan)
    return ResultManager.success("访问成功！", {
        "solve_dialog": origin_solve_dialog,
        "weekly_plan": final_week_day_arr,
        "nutrition_solver_params": nutrition_solver_params,
    })


def check_user_info_params(user_info_params: dict) -> dict:
   
    if user_info_params['activity_level']:
        temp_pa = DictUtil.get_code("ACTIVITY_LEVEL_PA", user_info_params['activity_level'])
        if temp_pa:
            user_info_params['pa'] = temp_pa
    if 'pa' not in user_info_params or not user_info_params['pa']:
        user_info_params['pa'] = DictUtil.get_code("ACTIVITY_LEVEL_PA", "轻度活动")

    if 'snack' not in user_info_params or not user_info_params['snack']:
        user_info_params['snack'] = DictUtil.get_code("YES_OR_NO", "否")
    return user_info_params


def load_execute_solver_result(params):
    return execute_solver({'data': params})

def extract_food_matching_relationship(alternative_foods: dict) -> dict:
    try:
        food_matching_relationship = {}
        for food_entity_id in alternative_foods:
            food_data = alternative_foods[food_entity_id]
            food_matching_relationship[food_data['name']] = food_data['food_id']
        return food_matching_relationship
    except Exception as e:
        logger.error(f"【提取食物匹配关系】---访问失败,{e}")
    return {}


def format_one_meal_food_list(food_list: list, food_matching_relationship: dict) -> list:
    if not food_list or len(food_list) == 0:
        return []

    final_food_list = []
    for food in food_list:
        food_name = food.get('name', '')

        food_id = food_matching_relationship.get(food_name, 'unknown_food_id')
        food['id'] = food_id

        amount = food.get('amount', '')
        amount = amount.replace('份', '')
        food['amount'] = amount

        unit = food.get('unit', '')
        unit = unit.replace('每份', '').replace('g', '')
        food['unit'] = unit

        final_food_list.append(food)
    return final_food_list


def check_food_ingredient_conflict(format_solver_result: dict, food_ingredient_relationship: dict) -> bool:
   
    if not format_solver_result or not format_solver_result['success']:
        return False
    final_result = format_solver_result['data']

    if not final_result or len(final_result) == 0:
        return False

    if not food_ingredient_relationship or len(food_ingredient_relationship) == 0:
        return False

    origin_weekly_plan = final_result.get('weekly_plan', {})
    meal_arr = ['breakfast', 'lunch', 'dinner', 'snack']

    for one_day_plan in origin_weekly_plan:
        for meal in meal_arr:
            meal_food_list = one_day_plan.get(meal, [])
            food_id_arr = []
            for food in meal_food_list:
                food_id = food.get('id', '')
                if food_id:
                    food_id_arr.append(food_id)
            if not food_id_arr or len(food_id_arr) == 0:
                continue
            check_one_meal_flag = check_food_ingredient_conflict_in_meal(food_id_arr, food_ingredient_relationship)
            if check_one_meal_flag:
                return True

    return False


def check_food_ingredient_conflict_in_meal(one_meal_food_id_arr: list, food_ingredient_relationship: dict) -> bool:
   
    food_id_sql_str = "'" + "','".join(one_meal_food_id_arr) + "'"
    food_ingredient_list = load_food_ingredient_by_food_id(food_id_sql_str)

    if len(food_ingredient_list) == 0:
        return False

    all_ingredient_id_arr = []
    for food in food_ingredient_list:
        required_ingredient_ids = food.get('required_ingredient_ids', '')
        if not required_ingredient_ids:
            continue
        required_ingredient_ids = required_ingredient_ids.split(',')
        all_ingredient_id_arr.extend(required_ingredient_ids)

    all_ingredient_id_arr = list(set(all_ingredient_id_arr))

    for ingredient_id in all_ingredient_id_arr:
        exists_forbidden_ingredient = food_ingredient_relationship.get(ingredient_id, None)
        if not exists_forbidden_ingredient:
            continue

        for exists_forbidden_ingredient_id in exists_forbidden_ingredient:
            if exists_forbidden_ingredient_id in one_meal_food_id_arr:
                return True
    return False

    