import time
from ortools.sat.python import cp_model

import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from src.solver.alternative_food_process import alternative_food_process
from clazz.utils.logger_util import logger
from config.constants import Constants
from config.solver_constraint_config.meal_carb_ratio_limits_config import MealCarbRatioLimitsConfig
from config.solver_constraint_config.meal_weight_limits_config import MealWeightLimitsConfig



def food_solver(alternative_food,
                serving_increment,
                current_day,
                user_nutrition_info,
                SCALE_FACTOR,
                min_steps_per_selection,
                type_serving_weight_range,
                first_output,
                solver_params_dict,
                used_foods=None,
                decay_factor=0.5):
    
    logger.info(f"  二阶段求解开始: 当前求解日期{current_day}")
    model = cp_model.CpModel()
    epsilon = 1e-6
    food_steps = {}
    food_choose = {}
    food_var_count = 0
    DEFAULT_MAX_STEPS_PER_ITEM = 30

    not_recommended_food_list = solver_params_dict.get('not_recommended_food_list', [])

    OIL_GRAMS = Constants.DEFAULT_OIL_WEIGHT
    OIL_CALORIES_VAL = Constants.DEFAULT_OIL_ENERGY
    
    scaled_oil_cal = int(OIL_CALORIES_VAL * SCALE_FACTOR)
    
    scaled_oil_fat_cal = scaled_oil_cal 
    scaled_oil_protein_cal = 0
    scaled_oil_carb_cal = 0

    scaled_min_total_cal, scaled_max_total_cal = user_nutrition_info["scaled_calories_range"]
    meal_ratio_ranges = user_nutrition_info["meal_ratio_ranges"]
    macro_ratio_ranges = user_nutrition_info["macro_ratio_ranges"]
    day_plan = first_output["weekly_plan"][current_day]
    day_allowed_category_total_list = []
    meal_allowed_category = {}
    PROTEIN_CAL_FACTOR = 4
    FAT_CAL_FACTOR = 9
    CARB_CAL_FACTOR = 4
    day_food_plan_details = {}

    logger.info(f" - {current_day}--day_plan--{day_plan}")
    for meal, allowed_category_list in day_plan.items():
        meal_allowed_category[meal] = []
        this_meal_allowed_category = []
        for category in allowed_category_list:
            meal_allowed_category[meal].append(category["category_name"][-1])

            this_meal_allowed_category.append(category["category_name"][-1])

            if category["category_name"][-1] not in day_allowed_category_total_list:
                day_allowed_category_total_list.append(category["category_name"][-1])
            
        logger.info(f"  二阶段求解开始: 当前求解日期{current_day}---{meal}--允许的食物类别{this_meal_allowed_category}")
    other_params_dict = {
        "not_recommended_food_list": not_recommended_food_list
    }
    
    categories_food_data = alternative_food_process(
        alternative_food,
        day_allowed_category_total_list,
        serving_increment,
        SCALE_FACTOR,
        other_params_dict,
        used_foods=used_foods,
        decay_factor=decay_factor)
    if not isinstance(categories_food_data, dict):
        logger.error(f"严重警告：当前日期{current_day}食物备选库食物类别过少，跳过此餐")
        return None

    food_data_flat = categories_food_data["food_data_flat"]
    scaled_cal_per_increment = categories_food_data["scaled_cal_per_increment"]
    scaled_c_per_increment = categories_food_data["scaled_c_per_increment"]
    scaled_f_per_increment = categories_food_data["scaled_f_per_increment"]
    scaled_p_per_increment = categories_food_data["scaled_p_per_increment"]
    scaled_u_per_increment = categories_food_data["scaled_u_per_increment"]
    scaled_u_per_increment_max = categories_food_data["scaled_u_per_increment_max"]
    food_cal_per_increment_unscaled = categories_food_data["cal_per_increment_unscaled"]
    food_p_per_increment_unscaled = categories_food_data["p_per_increment_unscaled"]
    food_f_per_increment_unscaled = categories_food_data["f_per_increment_unscaled"]
    food_c_per_increment_unscaled = categories_food_data["c_per_increment_unscaled"]

    food_category_list = categories_food_data["category_list"]
    nutrition_unit_list = categories_food_data["nutrition_unit_list"]
    context_data = categories_food_data["context_data"]
    context_data_max = categories_food_data["context_data_max"]
    food_name_map = categories_food_data["food_name_map"]
    category_list = categories_food_data["category_list"]

    food_index_id_map = {}
    for food_data in food_data_flat:
        food_index_id_map[food_data["internal_idx"]] = food_data["id"]

    food_index_category_map = {}
    for food_data in food_data_flat:
        food_index_category_map[food_data["internal_idx"]] = food_data["category"]

    num_food = len(food_data_flat)
    serving_weight_per_increment_list = []
    for i in range(num_food):
        serving_weight_per_increment_list.append(
            int(serving_increment * nutrition_unit_list[i]))
    for m in day_plan:
        food_steps[m] = {}
        food_choose[m] = {}
        meal_category = meal_allowed_category[m]
        for i in range(num_food):
            if category_list[i][-1] in meal_category:
                food_steps[m][i] = model.NewIntVar(0, DEFAULT_MAX_STEPS_PER_ITEM, name=f"food_steps_{m}_{i}")
                food_choose[m][i] = model.NewBoolVar(f"food_choose_{m}_{i}")
                model.Add(food_steps[m][i] == 0).OnlyEnforceIf(food_choose[m][i].Not())
                model.Add(food_steps[m][i] >= min_steps_per_selection).OnlyEnforceIf(food_choose[m][i])
                food_var_count += 2



    logger.info(f"【求解器】---二阶段求解——创建了 {food_var_count} 个核心 CP-SAT 决策变量 (food_steps)。")


    cons_count = 0
    logger.info("【求解器】---二阶段求解——添加每日总热量约束 (Scaled)...")
    daily_total_scaled_calories_expr = sum(
        int(scaled_cal_per_increment[i]) * food_steps[m][i] for m in day_plan
        for i in range(num_food) if i in food_steps[m])
    model.AddLinearConstraint(daily_total_scaled_calories_expr,
                              int(scaled_min_total_cal) - scaled_oil_cal,
                              int(scaled_max_total_cal) - scaled_oil_cal).WithName(f"daily_cal_food_only")
    cons_count += 1

    logger.info("【求解器】---二阶段求解——添加餐次热量比例约束 (Scaled)...")
    for m in day_plan:
        min_r, max_r = meal_ratio_ranges[m]
        meal_scaled_calories_expr = sum(
            int(scaled_cal_per_increment[i]) * food_steps[m][i]
            for i in range(num_food) if i in food_steps[m])
        if min_r > epsilon:
            model.Add(
                SCALE_FACTOR * meal_scaled_calories_expr -
                int(min_r * SCALE_FACTOR) * daily_total_scaled_calories_expr >=
                0).WithName(f"{m}_ratio_lb")
            cons_count += 1
        if max_r < (1.0 - epsilon):
            model.Add(
                SCALE_FACTOR * meal_scaled_calories_expr -
                int(max_r * SCALE_FACTOR) * daily_total_scaled_calories_expr <=
                0).WithName(f"{m}_ratio_ub")
            cons_count += 1

    logger.info("【求解器】---二阶段求解——添加宏量营养素供能比惩罚约束 (方案C)...")
    daily_total_scaled_protein_expr = sum(
        int(scaled_p_per_increment[i]) * food_steps[m][i] for m in day_plan
        for i in range(num_food) if i in food_steps[m]
    )
    daily_total_scaled_fat_expr = sum(
        int(scaled_f_per_increment[i]) * food_steps[m][i] for m in day_plan
        for i in range(num_food) if i in food_steps[m]
    )
    daily_total_scaled_carb_expr = sum(
        int(scaled_c_per_increment[i]) * food_steps[m][i] for m in day_plan
        for i in range(num_food) if i in food_steps[m]
    )
    daily_total_scaled_calories_expr = sum(
        int(scaled_cal_per_increment[i]) * food_steps[m][i] for m in day_plan
        for i in range(num_food) if i in food_steps[m]
    )


    if "breakfast" in day_plan:

        meals_today = list(day_plan.keys())   # 如 ["breakfast", "lunch", "dinner"]

        protein_mg = [int(round(p * 1000)) for p in food_p_per_increment_unscaled]

        breakfast_protein_terms = []
        for i in range(num_food):
            if i in food_steps["breakfast"]:
                breakfast_protein_terms.append(
                    protein_mg[i] * food_steps["breakfast"][i]
                )

        if len(breakfast_protein_terms) == 0:
            logger.warning("【求解器】早餐没有可计入蛋白质的食物，跳过蛋白质占比约束")

        else:
            breakfast_protein = sum(breakfast_protein_terms)

            day_protein_terms = []
            for m in meals_today:
                for i in range(num_food):
                    if i in food_steps[m]:
                        day_protein_terms.append(
                            protein_mg[i] * food_steps[m][i]
                        )

            day_protein = sum(day_protein_terms)

            model.Add(day_protein >= 1).WithName("protein_day_nonzero")

            model.Add(100 * breakfast_protein >= 20 * day_protein)\
                .WithName("protein_breakfast_ratio_lb")

            model.Add(100 * breakfast_protein <= 30 * day_protein)\
                .WithName("protein_breakfast_ratio_ub")

            cons_count += 3
            logger.info("【求解器】添加硬约束：早餐蛋白质占比 20%-30%（整数版）")






    min_p_r, max_p_r = macro_ratio_ranges["protein"]
    min_f_r, max_f_r = macro_ratio_ranges["fat"]
    min_c_r, max_c_r = macro_ratio_ranges["carb"]

    R_SCALE = 100
    MACRO_RATIO_TOL = 0.005
    tol_int = int(round(MACRO_RATIO_TOL * R_SCALE))

    def to_int_ratio_pair(rng):
        return int(round(rng[0] * R_SCALE)), int(round(rng[1] * R_SCALE))

    min_p_int, max_p_int = to_int_ratio_pair((min_p_r, max_p_r))
    min_f_int, max_f_int = to_int_ratio_pair((min_f_r, max_f_r))
    min_c_int, max_c_int = to_int_ratio_pair((min_c_r, max_c_r))

    excess_protein_lb = model.NewIntVar(0, 1_000_000, "excess_protein_lb")
    excess_protein_ub = model.NewIntVar(0, 1_000_000, "excess_protein_ub")
    excess_fat_lb = model.NewIntVar(0, 1_000_000, "excess_fat_lb")
    excess_fat_ub = model.NewIntVar(0, 1_000_000, "excess_fat_ub")
    excess_carb_lb = model.NewIntVar(0, 1_000_000, "excess_carb_lb")
    excess_carb_ub = model.NewIntVar(0, 1_000_000, "excess_carb_ub")

    
    model.Add(
        R_SCALE * PROTEIN_CAL_FACTOR * daily_total_scaled_protein_expr
        + excess_protein_lb
        >= (min_p_int - tol_int) * daily_total_scaled_calories_expr 
           + (min_p_int - tol_int) * scaled_oil_cal
           - 0 
    )
    model.Add(
        R_SCALE * PROTEIN_CAL_FACTOR * daily_total_scaled_protein_expr
        - excess_protein_ub
        <= (max_p_int + tol_int) * daily_total_scaled_calories_expr
           + (max_p_int + tol_int) * scaled_oil_cal
           - 0
    )

    model.Add(
        R_SCALE * FAT_CAL_FACTOR * daily_total_scaled_fat_expr
        + excess_fat_lb
        >= (min_f_int - tol_int) * daily_total_scaled_calories_expr
           + (min_f_int - tol_int) * scaled_oil_cal 
           - R_SCALE * scaled_oil_fat_cal             
    )
    model.Add(
        R_SCALE * FAT_CAL_FACTOR * daily_total_scaled_fat_expr
        - excess_fat_ub
        <= (max_f_int + tol_int) * daily_total_scaled_calories_expr
           + (max_f_int + tol_int) * scaled_oil_cal
           - R_SCALE * scaled_oil_fat_cal
    )

    model.Add(
        R_SCALE * CARB_CAL_FACTOR * daily_total_scaled_carb_expr
        + excess_carb_lb
        >= (min_c_int - tol_int) * daily_total_scaled_calories_expr
           + (min_c_int - tol_int) * scaled_oil_cal
           - 0
    )
    model.Add(
        R_SCALE * CARB_CAL_FACTOR * daily_total_scaled_carb_expr
        - excess_carb_ub
        <= (max_c_int + tol_int) * daily_total_scaled_calories_expr
           + (max_c_int + tol_int) * scaled_oil_cal
           - 0
    )

    cons_count += 6

    macro_penalty = (
            excess_protein_lb + excess_protein_ub +
            excess_fat_lb + excess_fat_ub +
            excess_carb_lb + excess_carb_ub
    )


    for m in day_plan:
        for category in meal_allowed_category[m]:
            model.AddAtMostOne(
                food_choose[m][i] for i in range(num_food)
                if i in food_choose[m] and category_list[i][-1] == category)

    for m in day_plan:
        for category in meal_allowed_category[m]:
            min_weight, max_weight = type_serving_weight_range[category]
            model.AddLinearConstraint(
                sum(food_steps[m][i] * serving_weight_per_increment_list[i]
                    for i in food_steps[m]
                    if category_list[i][-1] == category), min_weight,
                max_weight)


 
    
    meal_weight_limits_config = MealWeightLimitsConfig.get_meal_weight_limits(solver_params_dict)

    for m in day_plan:
        if m in meal_weight_limits_config:
            min_total_w, max_total_w = meal_weight_limits_config[m]
        else:
            min_total_w, max_total_w = [0, 1200]

        meal_total_weight_expr = sum(
            food_steps[m][i] * serving_weight_per_increment_list[i]
            for i in range(num_food) 
            if i in food_steps[m]
        )

        model.AddLinearConstraint(
            meal_total_weight_expr,
            int(min_total_w),
            int(max_total_w)
        ).WithName(f"{m}_total_meal_weight_limit")
        
        cons_count += 1

    meal_carb_limits_config = MealCarbRatioLimitsConfig.get_meal_carb_ratio_limits(solver_params_dict)

    daily_total_carb_expr = sum(
        int(scaled_c_per_increment[i]) * food_steps[m][i] 
        for m in day_plan
        for i in range(num_food) if i in food_steps[m]
    )

    RATIO_SCALER = 100 

    for m in day_plan:
        if m in meal_carb_limits_config:
            min_c_r, max_c_r = meal_carb_limits_config[m]
        else:
            min_c_r, max_c_r = [0.0, 1.0]

        meal_carb_expr = sum(
            int(scaled_c_per_increment[i]) * food_steps[m][i]
            for i in range(num_food) if i in food_steps[m]
        )

        min_c_r_int = int(round(min_c_r * RATIO_SCALER))
        max_c_r_int = int(round(max_c_r * RATIO_SCALER))

        if min_c_r > epsilon:
            model.Add(RATIO_SCALER * meal_carb_expr >= min_c_r_int * daily_total_carb_expr)\
                .WithName(f"{m}_carb_ratio_lb")

        if max_c_r < (1.0 - epsilon):
            model.Add(RATIO_SCALER * meal_carb_expr <= max_c_r_int * daily_total_carb_expr)\
                .WithName(f"{m}_carb_ratio_ub")
        
        cons_count += 2


    logger.info("【求解器】---二阶段求解——添加每餐内部宏量营养素供能比约束...")

    meal_macro_ratio_config = user_nutrition_info.get("meal_macro_ratio_limits", {})

    DEFAULT_MEAL_MACRO_RATIOS = {
        "breakfast": {
            "protein": [0.15, 0.35], 
            "fat":     [0.05, 0.35], 
            "carb":    [0.05, 0.40]
        },
        "lunch": {
            "protein": [0.05, 0.45], 
            "fat":     [0.05, 0.45], 
            "carb":    [0.05, 0.45] 
        },
        "dinner": {
            "protein": [0.05, 0.45], 
            "fat":     [0.05, 0.40], 
            "carb":    [0.05, 0.45]
        },
        "snack": {
            "protein": [0.0, 1.0], 
            "fat":     [0.0, 1.0], 
            "carb":    [0.0, 1.0]
        }
    }

    RATIO_CALC_SCALE = 100

    MACRO_CAL_FACTORS = {
        "protein": 4,
        "fat":     9,
        "carb":    4
    }
    
    macro_data_map = {
        "protein": scaled_p_per_increment,
        "fat":     scaled_f_per_increment,
        "carb":    scaled_c_per_increment
    }

    from collections import defaultdict

    name_to_indices = defaultdict(list)
    for i in range(num_food):
        name = food_name_map.get(i)
        if not name:
            continue
        norm_name = str(name).strip().lower()
        name_to_indices[norm_name].append(i)

    no_repeat_name_count = 0
    for norm_name, idx_list in name_to_indices.items():

        day_limit = 1

        choose_vars = []
        for m in day_plan:
            for i in idx_list:
                if i in food_choose.get(m, {}):
                    choose_vars.append(food_choose[m][i])

        if choose_vars:
            model.Add(sum(choose_vars) <= day_limit)
            cons_count += 1
            no_repeat_name_count += 1

    
    pref_expr = sum(
        int(scaled_u_per_increment[i]) * food_choose[m][i] for m in day_plan
        for i in range(num_food) if i in food_choose[m])

    N_pref = 1 / scaled_u_per_increment_max
    context_expr = sum(
        int(context_data[i][m]) * food_choose[m][i] for m in day_plan
        for i in range(num_food) if i in food_choose[m])
    N_context = 1 / context_data_max

    MACRO_WEIGHT = 1000
    objective_expr = (
            pref_expr * N_pref +
            context_expr * N_context -
            MACRO_WEIGHT * macro_penalty
    )
    model.Maximize(objective_expr)

    time_limit = Constants.SOLVER_SECOND_STEP_OF_TIME_LIMIT
    gap_limit = Constants.SOLVER_SECOND_STEP_OF_GAP_LIMIT
    num_solver_workers = Constants.SOLVER_NUM_SOLVER_WORKERS


    solve_start_time = time.time()
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.relative_gap_limit = gap_limit
    if num_solver_workers > 0:
        solver.parameters.num_search_workers = num_solver_workers
    solver.parameters.log_search_progress = False
    status = solver.Solve(model)
    solve_time = time.time() - solve_start_time

    if status == cp_model.FEASIBLE or status == cp_model.OPTIMAL:
        num_steps = {}
        for m in day_plan:
            num_steps[m] = {}
            for i in range(num_food):
                if i in food_steps[m]:
                    num_steps[m][i] = solver.Value(food_steps[m][i])

        day_total_cal_val = 0
        day_total_p_val = 0
        day_total_f_val = 0
        day_total_c_val = 0
        meal_energy_perc = {}
        macros_perc_formatted = {}
        day_meal_cal_vals = {}
        for m in day_plan:
            day_food_plan_details[m] = []
            meal_cal_total = 0
            for i in range(num_food):
                if i in num_steps[m]:
                    num = num_steps[m][i]
                    if num >= min_steps_per_selection:
                        serving_val = num * serving_increment
                        food_cal = food_cal_per_increment_unscaled[i] * num
                        food_p = food_p_per_increment_unscaled[i] * num
                        food_f = food_f_per_increment_unscaled[i] * num
                        food_c = food_c_per_increment_unscaled[i] * num
                        day_total_cal_val += food_cal
                        day_total_p_val += food_p
                        day_total_f_val += food_f
                        day_total_c_val += food_c
                        meal_cal_total += food_cal
                        amount = str(round(serving_val, 2)) + "份"
                        unit = "每份" + str(nutrition_unit_list[i]) + "g"
                        transformed_food_item = {
                            "name": food_name_map[i],
                            "food_entity_id": food_index_id_map[i],
                            "amount": amount,
                            "unit": unit,
                            "category": food_index_category_map[i],
                            "nutrition": {
                                "calories": round(food_cal, 4),
                                "protein": round(food_p, 4),
                                "fat": round(food_f, 4),
                                "carb": round(food_c, 4)
                            }
                        }
                        day_food_plan_details[m].append(transformed_food_item)
            if meal_cal_total > epsilon: day_meal_cal_vals[m] = meal_cal_total

        day_total_cal_val_for_macros = day_total_p_val * PROTEIN_CAL_FACTOR + day_total_f_val * FAT_CAL_FACTOR + day_total_c_val * CARB_CAL_FACTOR
        
        
        day_total_cal_val_with_oil = day_total_cal_val + OIL_CALORIES_VAL
        
        total_p_cal = day_total_p_val * PROTEIN_CAL_FACTOR
        total_f_cal = day_total_f_val * FAT_CAL_FACTOR + OIL_CALORIES_VAL
        total_c_cal = day_total_c_val * CARB_CAL_FACTOR
        
        calc_total_energy = total_p_cal + total_f_cal + total_c_cal

        if day_total_cal_val > epsilon:
            for m_key, m_cal in day_meal_cal_vals.items():
                meal_energy_perc[m_key] = f"{round((m_cal / calc_total_energy) * 100, 1)}%"
            
            macros_perc_formatted["protein"] = f"{round((total_p_cal / calc_total_energy) * 100, 1)}%"
            macros_perc_formatted["fat"] = f"{round((total_f_cal / calc_total_energy) * 100, 1)}%"
            macros_perc_formatted["carb"] = f"{round((total_c_cal / calc_total_energy) * 100, 1)}%"
        else:
            meal_energy_perc = {m: "0.0%" for m in day_meal_cal_vals.keys()}
            macros_perc_formatted = {
                "protein": "0.0%",
                "fat": "0.0%",
                "carb": "0.0%"
            }
        transformed_day_food_plan: dict[str, any] = {
            "day": current_day,
            "food_plan": day_food_plan_details,
            "nutrition": {
                "meal_energy": meal_energy_perc,
                "macros_energy": macros_perc_formatted
            }
        }

        return {
            "solve_time": solve_time,
            "status": status,
            "num_steps": num_steps,
            "transformed_day_food_plan": transformed_day_food_plan
        }
    else:
        return {
            "solve_time": solve_time,
            "status": status,
            "transformed_day_food_plan": None
        }
