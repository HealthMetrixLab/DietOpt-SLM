import math
import sys
from pathlib import Path
project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from config.constants import Constants

from clazz.utils.logger_util import logger

FOOD_TYPE_MIN_FOOD_COUNT = Constants.FOOD_TYPE_MIN_FOOD_COUNT

def alternative_type_process(SCALE_FACTOR, alternative_food, alternative_type,
                             food_type_matching, serving_increment):
    epsilon = 1e-6
    PROTEIN_CAL_FACTOR = Constants.PROTEIN_CAL_FACTOR
    FAT_CAL_FACTOR = Constants.FAT_CAL_FACTOR
    CARB_CAL_FACTOR = Constants.CARB_CAL_FACTOR
    type_processed_count = 0
    type_skipped_count = 0
    type_scaled_cal_per_increment = []
    type_scaled_p_per_increment = []
    type_scaled_f_per_increment = []
    type_scaled_c_per_increment = []
    type_scaled_u_per_increment = []
    type_category_list = []
    last_level_categories = []
    type_data_flat = []
    cal_per_increment_unscaled, p_per_increment_unscaled, f_per_increment_unscaled, c_per_increment_unscaled, u_per_increment_unscaled = [], [], [], [], []
    type_context_data = []
    food_id_map, type_name_map, internal_idx_map = {}, {}, {}
    current_internal_idx = 0

    alternative_food_by_type = {}
    check_food_type_dict = {}
    for food_id, food_item in alternative_food.items():
        category_name = food_item["category_name"]
        if category_name[-1] not in alternative_food_by_type:
            alternative_food_by_type[category_name[-1]] = []
        alternative_food_by_type[category_name[-1]].append(food_item)
        check_food_type_dict[category_name[-1]] = '_'.join(category_name)

    logger.info(f"【alternative_type_process】---步骤 5.1：遍历类别数据，进行转换和缩放")
    logger.info(f"【alternative_type_process】---总共有 {len(alternative_food_by_type)} 个类别需要处理")
    temp_dict = {}
    for last_category_name in alternative_food_by_type.keys():
        temp_dict[check_food_type_dict[last_category_name]] = len(alternative_food_by_type[last_category_name])
        
    for temp_key in sorted(temp_dict.keys()):
        logger.info(f"【alternative_type_process】---类别 '{temp_key}' 包含 {temp_dict[temp_key]} 种食物")

    type_little_food = 0
    for food_type in alternative_type:
        type_processed_count += 1
        
        if not isinstance(food_type, dict):
            logger.warning(f"      注意: 子类信息 '{food_type}'  的 获取失败（非字典类型），跳过")
            type_skipped_count += 1
            continue
        
        type_name = food_type.get("name")
        food_in_category_total = 0
        if type_name in alternative_food_by_type and alternative_food_by_type[type_name]:
            food_in_category_total = len(alternative_food_by_type[type_name])
        if food_in_category_total < FOOD_TYPE_MIN_FOOD_COUNT:
            type_little_food += 1
            logger.warning(f"      注意: 类别 '{type_name}' 包含少于 {FOOD_TYPE_MIN_FOOD_COUNT} 种食物，跳过")
            continue
        try:
            category_str = food_type.get("food_category")
            category = category_str.split("_", 2)
            type_nutrition = food_type.get("nutrition")

            type_personal_preference_weight_var = round(float(food_type.get("personal_preference_weight")), 2)
            type_regional_preference_weight_var = round(float(food_type.get("regional_preference_weight")), 2)
            type_context = {
                "breakfast":
                int(10 * float(food_type.get("breakfast_suit_weight", 0))),
                "lunch":
                int(10 * float(food_type.get("lunch_suit_weight", 0))),
                "dinner":
                int(10 * float(food_type.get("dinner_suit_weight", 0))),
                "snack":
                int(10 * float(food_type.get("extra_suit_weight", 0)))
            }
            type_context_data.append(type_context)
            if type_personal_preference_weight_var is not None:
                try:
                    type_personal_preference_weight: float = max(
                        0.0,
                        min(1.0, float(type_personal_preference_weight_var)))
                except (ValueError, TypeError):
                    logger.warning(f"【alternative_type_process】---类别数据处理注意: 类别 '{type_name}' 的 type_personal_preference_weight_var 无法转为浮点数，使用默认值 0.0。")
                    type_personal_preference_weight = 0.0
                    type_skipped_count += 1
                    continue
            if type_regional_preference_weight_var is not None:
                try:
                    type_regional_preference_weight: float = max(
                        0.0,
                        min(1.0, float(type_regional_preference_weight_var)))
                except (ValueError, TypeError):
                    logger.warning(f"【alternative_type_process】---类别数据处理注意: 类别 '{type_name}' 的 type_regional_preference_weight_var 无法转为浮点数，使用默认值 0.0。")
                    type_regional_preference_weight = 0.0
                    type_skipped_count += 1
                    continue
            if type_personal_preference_weight < 0:
                logger.warning(f"【alternative_type_process】---类别数据处理注意: 类别 '{type_name}' 因 type_personal_preference_weight 小于 0，已从优化模型中排除。")
                type_skipped_count += 1
                continue
            if type_regional_preference_weight_var < 0:
                logger.warning(f"【alternative_type_process】---类别数据处理注意: 类别 '{type_name}' 因 type_regional_preference_weight 小于 0，已从优化模型中排除。")
                type_skipped_count += 1
                continue
            if not isinstance(category, list):
                logger.warning(f"【alternative_type_process】---类别数据处理注意: 类别 '{type_name}' 无法获取category_name，已从优化模型中排除。")
                type_skipped_count += 1
                continue
            utility_value = math.sqrt(
                (type_personal_preference_weight * Constants.PROPORTION_OF_PERSONAL_PREFERENCE_SCORES + \
                  type_regional_preference_weight * Constants.PROPORTION_OF_AREA_PREFERENCE_SCORES) / 2
            ) if type_regional_preference_weight > epsilon and type_personal_preference_weight > epsilon else 0.0

            utility_value = round(utility_value, 2)


            base_unit_calories = max(
                0.0, float(type_nutrition.get("calories", 0) or 0))
            base_unit_protein_g = max(
                0.0, float(type_nutrition.get("protein", 0) or 0))
            base_unit_fat_g = max(0.0,
                                  float(type_nutrition.get("fat", 0) or 0))
            base_unit_carb_g = max(0.0,
                                   float(type_nutrition.get("carbo", 0) or 0))
            if base_unit_calories <= epsilon:
                calculated_calories = base_unit_protein_g * PROTEIN_CAL_FACTOR + base_unit_fat_g * FAT_CAL_FACTOR + base_unit_carb_g * CARB_CAL_FACTOR

                if calculated_calories > epsilon:
                    base_unit_calories = calculated_calories
                else:
                    logger.warning(f"【alternative_type_process】---类别数据处理注意: 食物 '{type_name}' 卡路里为 0 或无法估算，已跳过。")
                    type_skipped_count += 1
                    continue

            cal_incr = base_unit_calories * serving_increment
            p_incr = base_unit_protein_g * serving_increment
            f_incr = base_unit_fat_g * serving_increment
            c_incr = base_unit_carb_g * serving_increment
            u_incr = utility_value * serving_increment
            cal_per_increment_unscaled.append(cal_incr)
            p_per_increment_unscaled.append(p_incr)
            f_per_increment_unscaled.append(f_incr)
            c_per_increment_unscaled.append(c_incr)
            u_per_increment_unscaled.append(u_incr)
            type_scaled_cal_per_increment.append(int(cal_incr * SCALE_FACTOR))
            type_scaled_p_per_increment.append(int(p_incr * SCALE_FACTOR))
            type_scaled_f_per_increment.append(int(f_incr * SCALE_FACTOR))
            type_scaled_c_per_increment.append(int(c_incr * SCALE_FACTOR))
            type_scaled_u_per_increment.append(int(u_incr * SCALE_FACTOR))
            type_category_list.append(category)
            last_level_categories.append(category[-1])
            type_name_map[current_internal_idx] = type_name
            internal_idx_map[type_name] = current_internal_idx
            type_data_flat.append({
                'internal_idx': current_internal_idx,
                'name': type_name,
                'category': category,
                'calories': base_unit_calories,
                'protein': base_unit_protein_g,
                'fat': base_unit_fat_g,
                'carb': base_unit_carb_g,
                'utility': utility_value
            })
            current_internal_idx += 1
        except (KeyError, ValueError, TypeError) as e:
            type_display_name = food_type.get('name', "?")
            logger.warning(f"【alternative_type_process】---类别数据处理注意: 处理类别 '{type_display_name}' 时发生错误: {e}，已跳过。")
            type_skipped_count += 1
            continue
    num_type = len(type_data_flat)
    if num_type < 15:
        logger.error(f"数据错误: 预处理后有效类别数量 ({num_type}) 过少，无法进行优化。")
        logger.error(f"数据错误: 预处理后有效类别:{type_data_flat}")
        raise ValueError(f"数据错误: 预处理后有效类别数量 ({num_type}) 过少，无法进行优化。")

    print_str= f"  类别数据预处理完成: 共处理 {type_processed_count} 种食物类别, 因信息错误跳过 {type_skipped_count} 种，因所含食物数量少于{FOOD_TYPE_MIN_FOOD_COUNT}跳过{type_little_food}种。有效食物总数: {num_type}"
    logger.info(f"【alternative_type_process】---{print_str}")

    type_pairing_data: dict = {}
    for type_pair in food_type_matching:
        if not type_pair["source_food_type"] in type_pairing_data:
            type_pairing_data.update({type_pair["source_food_type"]: {}})
        if not type_pair["target_food_type"] in type_pairing_data[
                type_pair["source_food_type"]]:
            type_pairing_data[type_pair["source_food_type"]].update(
                {type_pair["target_food_type"]: 10 * type_pair["suit_weight"]})
    type_scaled_u_per_increment_max = 1
    type_context_data_max = 100
    type_pairing_data_max = 100
    return {
        "type_scaled_cal_per_increment": type_scaled_cal_per_increment,
        "type_scaled_p_per_increment": type_scaled_p_per_increment,
        "type_scaled_f_per_increment": type_scaled_f_per_increment,
        "type_scaled_c_per_increment": type_scaled_c_per_increment,
        "type_scaled_u_per_increment": type_scaled_u_per_increment,
        "type_scaled_u_per_increment_max": type_scaled_u_per_increment_max,
        "cal_per_increment_unscaled": cal_per_increment_unscaled,
        "p_per_increment_unscaled": p_per_increment_unscaled,
        "f_per_increment_unscaled": f_per_increment_unscaled,
        "c_per_increment_unscaled": c_per_increment_unscaled,
        "u_per_increment_unscaled": u_per_increment_unscaled,
        "context_data": type_context_data,
        "context_data_max": type_context_data_max,
        "type_name_map": type_name_map,
        "type_data_flat": type_data_flat,
        "type_category_list": type_category_list,
        "last_level_categories": last_level_categories,
        "type_pairing_data": type_pairing_data,
        "type_pairing_data_max": type_pairing_data_max,
        "internal_idx_map": internal_idx_map,
    }
