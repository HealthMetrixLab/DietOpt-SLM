import math
import sys
from pathlib import Path
project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from config.constants import Constants
from config.solver_constraint_config.food_frequency_config import FoodFrequencyConfig

from clazz.utils.logger_util import logger


def alternative_food_process(alternative_food,
                             allowed_category,
                             serving_increment,
                             SCALE_FACTOR,
                             other_params_dict,
                             used_foods=None,
                             decay_factor=0.5):
    logger.info(f"【求解器】---当前日期允许的食物类别为{allowed_category}")
    epsilon = 1e-6
    PROTEIN_CAL_FACTOR = Constants.PROTEIN_CAL_FACTOR
    FAT_CAL_FACTOR = Constants.FAT_CAL_FACTOR
    CARB_CAL_FACTOR = Constants.CARB_CAL_FACTOR
    food_data_flat = []
    food_id_map, food_name_map, internal_idx_map = {}, {}, {}
    scaled_cal_per_increment, scaled_p_per_increment, scaled_f_per_increment, scaled_c_per_increment, scaled_u_per_increment = [], [], [], [], []
    cal_per_increment_unscaled, p_per_increment_unscaled, f_per_increment_unscaled, c_per_increment_unscaled, u_per_increment_unscaled = [], [], [], [], []
    category_list, food_id_list, nutrition_unit_list = [], [], []
    context_data = []
    processed_count, skipped_count, current_internal_idx = 0, 0, 0
    used_foods = used_foods or {}

    for food_id, food_item in alternative_food.items():
        processed_count += 1
        if not isinstance(food_item, dict):
            logger.warning(f"【求解器】---食物数据处理注意: 食物信息 '{food_item}'  的 获取失败（非字典类型），跳过")
            skipped_count += 1
            continue
        try:
            food_id = food_item.get("id")
            food_name = food_item.get('name', f'未知_{food_id}')
            category_name = food_item.get("category_name")
            food_nutrition = food_item.get("nutrition")
            personal_preference_weight_var = float(food_item.get("personal_preference_weight"))
            regional_preference_weight_var = float(food_item.get("regional_preference_weight"))

            food_nutrition_unit = int(food_item.get("nutrition_unit"))
            food_context_data = {
                "breakfast": food_item.get("breakfast_suit_weight"),
                "lunch": food_item.get("lunch_suit_weight"),
                "dinner": food_item.get("dinner_suit_weight"),
                "snack": food_item.get("extra_suit_weight")
            }
            context_data.append(food_context_data)
            score_val = 0.0

            if not isinstance(category_name, list):
                skipped_count += 1
                continue
            if not category_name[-1] in allowed_category:
                continue
            if personal_preference_weight_var is not None:
                try:
                    personal_preference_weight: float = max(
                        0.0, min(1.0, float(personal_preference_weight_var)))
                except (ValueError, TypeError):
                    #logger.warning(f"【求解器】---食物数据处理注意: 食物 '{food_name}' (ID: {food_id}) 的 personal_preference_weight_var 无法转为浮点数，使用默认值 0.0。")
                    personal_preference_weight = 0.0
            if personal_preference_weight_var < 0:
                #logger.warning(f"【求解器】---食物数据处理信息 (过滤): 食物 '{food_name}' (ID: {food_id}) 因 personal_preference_weight_var 小于 0，已从优化模型中排除。")
                skipped_count += 1
                continue
            if regional_preference_weight_var is not None:
                try:
                    regional_preference_weight: float = max(
                        0.0, min(1.0, float(regional_preference_weight_var)))
                except (ValueError, TypeError):
                    logger.warning(f"【求解器】---食物数据处理注意: 食物 '{food_name}' (ID: {food_id}) 的 regional_preference_weight 无法转为浮点数，使用默认值 0.0。")
                    regional_preference_weight = 0.0
            if regional_preference_weight_var < 0:
                logger.warning(f"【求解器】---食物数据处理信息 (过滤): 食物 '{food_name}' (ID: {food_id}) 因 regional_preference_weight 小于 0，已从优化模型中排除。")
                skipped_count += 1
                continue
            utility_value = math.sqrt(
                (personal_preference_weight * Constants.PROPORTION_OF_PERSONAL_PREFERENCE_SCORES +\
                  regional_preference_weight * Constants.PROPORTION_OF_AREA_PREFERENCE_SCORES) / 2
            ) if regional_preference_weight > epsilon and personal_preference_weight > epsilon else 0.0

            first_category = category_name[0]
            last_category = category_name[-1]
            max_times_per_week = FoodFrequencyConfig.get_food_frequency_by_food_category(first_category, last_category)

            if food_name in used_foods:
                occupy_times = used_foods.get(food_name, 1)
                utility_value = utility_value * (decay_factor**occupy_times)
                if occupy_times >= max_times_per_week:
                    #logger.warning(f"【求解器】---食物数据处理信息: 食物 '{food_name}' (ID: {food_id}) 已使用过 {occupy_times} 次，进行剔除。")
                    logger.info(f"【求解器】---first_category:{first_category} last_category:{last_category} ,最大允许次数为 {max_times_per_week}。")
                    continue
            
            if food_id in other_params_dict.get('not_recommended_food_list', []):
                 #logger.warning(f"【求解器】---食物数据处理注意: 食物 '{food_name}' (ID: {food_id}) 已被标记为不推荐，已从优化模型中排除。")
                 continue

            utility_value = round(utility_value, 2)

            base_unit_calories = max(
                0.0, float(food_nutrition.get("calories", 0) or 0))
            base_unit_protein_g = max(
                0.0, float(food_nutrition.get("protein", 0) or 0))
            base_unit_fat_g = max(0.0,
                                  float(food_nutrition.get("fat", 0) or 0))
            base_unit_carb_g = max(0.0,
                                   float(food_nutrition.get("carbo", 0) or 0))
            if base_unit_calories <= epsilon:
                calculated_calories = base_unit_protein_g * PROTEIN_CAL_FACTOR + base_unit_fat_g * FAT_CAL_FACTOR + base_unit_carb_g * CARB_CAL_FACTOR
                if calculated_calories > epsilon:
                    base_unit_calories = calculated_calories
                else:
                    logger.warning(f"警告: 食物 '{food_name}' (ID: {food_id}) 卡路里为 0 或无法估算，已跳过。")
                    skipped_count += 1
                    continue
            cal_incr = base_unit_calories * serving_increment
            p_incr = base_unit_protein_g * serving_increment
            f_incr = base_unit_fat_g * serving_increment
            c_incr = base_unit_carb_g * serving_increment
            u_incr = utility_value * serving_increment
            cal_per_increment_unscaled.append(cal_incr)
            p_per_increment_unscaled.append(p_incr)
            f_per_increment_unscaled.append(f_incr)
            c_per_increment_unscaled.append(c_incr)
            u_per_increment_unscaled.append(u_incr)
            scaled_cal_per_increment.append(int(cal_incr * SCALE_FACTOR))
            scaled_p_per_increment.append(int(p_incr * SCALE_FACTOR))
            scaled_f_per_increment.append(int(f_incr * SCALE_FACTOR))
            scaled_c_per_increment.append(int(c_incr * SCALE_FACTOR))
            scaled_u_per_increment.append(int(u_incr * SCALE_FACTOR))
            nutrition_unit_list.append(food_nutrition_unit)
            food_id_list.append(food_id)
            category_list.append(category_name)
            food_id_map[current_internal_idx] = food_id
            food_name_map[current_internal_idx] = food_name
            internal_idx_map[food_id] = current_internal_idx
            food_data_flat.append({
                'internal_idx': current_internal_idx,
                'id': food_id,
                'name': food_name,
                'category': category_name,
                'calories': base_unit_calories,
                'protein': base_unit_protein_g,
                'fat': base_unit_fat_g,
                'carb': base_unit_carb_g,
                'utility': utility_value,
                'preference_weight': score_val
            })
            current_internal_idx += 1
        except (KeyError, ValueError, TypeError) as e:
            food_display_name = food_item.get('name', food_item.get('id', '?'))
            skipped_count += 1
            continue
    num_foods = len(food_id_list)

    logger.info(f"【求解器】---类别数据预处理完成: 共处理 {processed_count} 种有效食物, 因食物信息不全跳过 {skipped_count} 种。当前日期食物总数: {num_foods}")
    if num_foods < 1:
        return None
    return {
        "scaled_cal_per_increment": scaled_cal_per_increment,
        "scaled_p_per_increment": scaled_p_per_increment,
        "scaled_f_per_increment": scaled_f_per_increment,
        "scaled_c_per_increment": scaled_c_per_increment,
        "scaled_u_per_increment": scaled_u_per_increment,
        "scaled_u_per_increment_max": 1,
        "cal_per_increment_unscaled": cal_per_increment_unscaled,
        "p_per_increment_unscaled": p_per_increment_unscaled,
        "f_per_increment_unscaled": f_per_increment_unscaled,
        "c_per_increment_unscaled": c_per_increment_unscaled,
        "nutrition_unit_list": nutrition_unit_list,
        "context_data": context_data,
        "context_data_max": 10,
        "category_list": category_list,
        "food_data_flat": food_data_flat,
        "food_name_map": food_name_map,
        "num_foods": num_foods
    }
