import sys
from pathlib import Path
import random

project_root = str(Path(__file__).parent.parent.parent.parent)
sys.path.append(project_root)

from clazz.utils.logger_util import logger
from config.constants import Constants
from src.util.database_util import (
    load_food_healthy_recipe_info,
    t_food_healthy_recipe_and_food_relation,
    load_all_ingredient_info_list,
    load_food_ingredient_list_by_food_id,
    load_food_entity_by_food_id,
)
from src.solver.recipe_solver.solve_ingredient_optimization import main_solve_function
from src.util.analyse_result_util import analyse_meal_info
from src.util.main_execute_llm_fun import (
    execute_llm_analyse_meal_rationality_by_cons,
)
from src.util.common_func import load_ingredient_cooked_data_by_name

MAX_CHOOSE_TIMES_LIMIT = 5

MODULE_DESCRIPTION = "【solver】"



def recipe_solver_function(params_dict:dict):
    day = params_dict.get("day", "未指定")
    check_meal_rationality_params = params_dict.get("check_meal_rationality_params", {})
    choose_recipe_id_arr = params_dict.get("choose_recipe_id_arr", [])

    logger.info(f"")
    logger.info(f"{MODULE_DESCRIPTION} --- 开始求解 {day} 的食谱")
    logger.info(f"参数：\n{params_dict}")

    
    healthy_recipe_info_list = load_food_healthy_recipe_info()
    logger.info(f"{MODULE_DESCRIPTION} --- 加载健康食谱信息，共 {len(healthy_recipe_info_list)} 条")
    
   
    choose_healthy_recipe_id_list = []
    
    for i in range(MAX_CHOOSE_TIMES_LIMIT):
        choose_healthy_recipe_num = random.randint(1, len(healthy_recipe_info_list))

        recipe_id = healthy_recipe_info_list[choose_healthy_recipe_num - 1]["id"]

        if recipe_id not in choose_healthy_recipe_id_list and recipe_id not in choose_recipe_id_arr:
            choose_healthy_recipe_id_list.append(recipe_id)

        if len(choose_healthy_recipe_id_list) >= len(healthy_recipe_info_list):
            break

    logger.info(f"{MODULE_DESCRIPTION} --- 随机选择 {len(choose_healthy_recipe_id_list)} 条健康食谱")
    if choose_healthy_recipe_id_list is None or len(choose_healthy_recipe_id_list) == 0:
        logger.error(f"{MODULE_DESCRIPTION} --- 随机选择的健康食谱数量为 0")
        return None

    ingredient_info_list = load_all_ingredient_info_list()
    logger.info(f"{MODULE_DESCRIPTION} --- 加载所有食材信息，共 {len(ingredient_info_list)} 条")

    ingredient_info_dict = {}
    for ingredient_info in ingredient_info_list:
        ingredient_info_dict[ingredient_info['id']] = ingredient_info

    
    return_result = None

    for recipe_id in choose_healthy_recipe_id_list:
        final_solver_result = {}
        nutrition_dict = {}

        food_healthy_recipe_relation_list = t_food_healthy_recipe_and_food_relation(recipe_id)
        logger.info(f"{MODULE_DESCRIPTION} --- 加载食物与健康食谱的关联信息，共 {len(food_healthy_recipe_relation_list)} 条")

        meal_food_dict = {}
        food_id_meal_check_dict = {}

        food_id_arr = []
        food_check_dict = {}
        for item in food_healthy_recipe_relation_list:
            food_id_arr.append(item['food_id'])
            food_check_dict[item['food_id']] = item
            food_id_meal_check_dict[item['food_id']] = item['meal']
        
        original_food_info_list = []

        need_ingredient_list = []
        need_ingredient_id_list = []

        for food_id in food_id_arr:
            food_ingredient_list = load_food_ingredient_list_by_food_id(food_id)
            food_data = load_food_entity_by_food_id(food_id)

            ingredient_arr = []
            for ingredient_info in food_ingredient_list:
                need_ingredient_id_list.append(ingredient_info[Constants.TARGET_ENTITY_ID_FIELD_NAME])

                ingredient_arr.append({
                    "ingredient_id": ingredient_info[Constants.TARGET_ENTITY_ID_FIELD_NAME].replace(" ", ""),
                    "ingredient_name": ingredient_info[Constants.TARGET_ENTITY_NAME_FIELD_NAME].replace(" ", ""),
                    "weight": ingredient_info['value'] + ingredient_info['unit'],
                })

            original_food_info_list.append({
                "food_id": food_id,
                "food_name": food_data['entity_name'].replace(" ", ""),
                "food_category": food_data['food_category'].replace(" ", ""),
                "ingredient_arr": ingredient_arr,
            })

        for ingredient_id in need_ingredient_id_list:
            if ingredient_id not in ingredient_info_dict:
                logger.error(f"{MODULE_DESCRIPTION} --- 食材 {ingredient_id} 不存在ingredient_info_dict中")
                continue
            ingredient_info = ingredient_info_dict[ingredient_id]
            need_ingredient_list.append({
                "ingredient_name": ingredient_info[Constants.ENTITY_FIELD_NAME].replace(" ", ""),
                "food_unit": ingredient_info['food_unit'],
                "calories": ingredient_info['calories'],
                "protein": ingredient_info['protein'],
                "fat": ingredient_info['fat'],
                "carbo": ingredient_info['carbo'],
            })

        for food_info in original_food_info_list:
            food_id = food_info['food_id']
            meal = food_id_meal_check_dict[food_id]
            if meal not in meal_food_dict:
                meal_food_dict[meal] = []
            meal_food_dict[meal].append(food_info)

        params_dict['meal_food_dict'] = meal_food_dict
        params_dict['need_ingredient_list'] = need_ingredient_list

        recipe_solver_params = {
            "meal_food_dict": meal_food_dict,
            "need_ingredient_list": need_ingredient_list,
        }
        params_dict.update(recipe_solver_params)

        print(params_dict)

        solve_result = None
        try:
            solve_result, nutrition_dict = main_solve_function(params_dict)
        except Exception as e:
            logger.error(f"{MODULE_DESCRIPTION} --- 求解失败，错误信息：{e}")

        if solve_result is None:
            logger.error(f"{MODULE_DESCRIPTION} --- 求解结果为None，选择下一个食谱进行求解")
            continue

        check_flag = True

        meal_arr = []
        for key in Constants.MEAL_NAME_MAP:
            meal_arr.append(key)

        for meal in solve_result.keys():
            meal_food_arr = solve_result[meal]
            new_food_info_arr = []
            final_solver_result[meal] = []
            for food_info in meal_food_arr:
                food_raw_unit_float = 0.0
                food_cal = 0.0
                food_p = 0.0
                food_f = 0.0
                food_c = 0.0

                ingredient_arr = food_info['ingredient_arr']
                for ingredient_info in ingredient_arr:
                    ingredient_id = ingredient_info['ingredient_id']
                    ingredient_name = ingredient_info['ingredient_name']
                    weight_str = ingredient_info['weight']
                    weight_str = weight_str.replace(" ", "").replace("g", "").replace("克", "")
                    weight_float = float(weight_str)


                    food_raw_unit_float += weight_float

                    if ingredient_id not in ingredient_info_dict:
                        check_flag = False
                        logger.error(f"{MODULE_DESCRIPTION} --- 食材 {ingredient_id} 不存在ingredient_info_dict中")
                        continue
                    ingredient_info = ingredient_info_dict[ingredient_id]
                   
                    food_cal += (weight_float / 100) * float(ingredient_info.get('calories', 0.0))
                    food_p += (weight_float / 100) * float(ingredient_info.get('protein', 0.0))
                    food_f += (weight_float / 100) * float(ingredient_info.get('fat', 0.0))
                    food_c += (weight_float / 100) * float(ingredient_info.get('carbo', 0.0))
                    
                new_food_info = {
                    "name": food_info['food_name'],
                    "food_category": food_info['food_category'],
                    "food_entity_id": food_info['food_id'],
                    "amount": "1份",
                    "unit": "每份" + str(int(food_raw_unit_float)) + "g",
                    "nutrition": {
                        "calories": round(food_cal, 4),
                        "protein": round(food_p, 4),
                        "fat": round(food_f, 4),
                        "carb": round(food_c, 4)
                    }
                }
                final_solver_result[meal].append(new_food_info)
        if not check_flag:
            logger.error(f"{MODULE_DESCRIPTION} --- 求解失败，换下一套食谱进行求解")
            continue
        
        deal_snack_arr = ['snack1', 'snack2', 'snack3']
        final_snack_name = 'snack'
        final_solver_result[final_snack_name] = []
        for meal_str in final_solver_result:
            if meal_str not in deal_snack_arr:
                continue
            final_solver_result[final_snack_name].extend(final_solver_result[meal_str])

        for temp_str in deal_snack_arr:
            if temp_str in final_solver_result:
                del final_solver_result[temp_str]


        logger.info(f"{MODULE_DESCRIPTION} --- 求解成功，模型分析通用模型是否合适。")
        transformed_day_food_plan = {
            "day": day,
            "food_plan":final_solver_result,
            "nutrition": nutrition_dict
        }
        analyse_meal_info_result = analyse_meal_info(transformed_day_food_plan)
        print(transformed_day_food_plan)

        meal_info_list = analyse_meal_info_result['meal_info_list']

        meal_info_list_str = '\n'.join(meal_info_list)
        check_meal_rationality_params['meal_info_str'] = meal_info_list_str
        analyse_meal_rationality_result = execute_llm_analyse_meal_rationality_by_cons(check_meal_rationality_params)
        logger.warning(f"{MODULE_DESCRIPTION} --- \n日期：{day}，饮食合理性分析结果: {analyse_meal_rationality_result}")
        meal_rationality_score = analyse_meal_rationality_result.get('score', None)

        if meal_rationality_score == None:
            logger.error(f"{MODULE_DESCRIPTION} --- 日期：{day}，饮食合理性分析结果，未包含评分信息。")
            continue
        if meal_rationality_score < Constants.MODEL_LOWEST_SCORE_FOR_DAILY_RECIPES:
            logger.error(f"{MODULE_DESCRIPTION} --- {day}，饮食合理性分析结果，评分过低{meal_rationality_score}，重新求解。")
            continue
        return_result = transformed_day_food_plan
        return_result['choose_recipe_id'] = recipe_id


        logger.info(f"{MODULE_DESCRIPTION} --- 求解成功，食谱ID为：{recipe_id}，正准备返回数据结果........")
        break
    return return_result






if __name__ == "__main__":
    print('---start---')