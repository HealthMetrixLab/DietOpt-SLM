import json
import math
from ortools.sat.python import cp_model

def main_solve_function(input_data):
    model = cp_model.CpModel()
    
    nutrition_dict = {
        "meal_energy": {"breakfast": "0", "lunch": "0", "dinner": "0", "snack": "0"},
        "macros_energy": {"protein": "0", "fat": "0", "carb": "0"}
    }

   
    SCALE_RATIO = 1 

    
    GEN_MIN_PCT = 70
    GEN_MAX_PCT = 130
    
    STAPLE_MIN_PCT = 70
    STAPLE_MAX_PCT = 110
    STAPLE_KEYWORDS = ["主食", "米饭", "面点", "粥", "馒头", "饼", "面条"]

    SCALE_NUTRIENT = 100
    CONSTRAINT_SCALE = 100 

    PENALTY_CALORIE_MISS = 50000 
    PENALTY_RATIO_MISS = 1       
    PENALTY_CHANGE = 10          

    calories_config = input_data['calories']
    meal_ratio_ranges = input_data['meal_ratio_ranges']
    macro_ratio_ranges = input_data['macro_ratio_ranges']
    meal_food_dict = input_data['meal_food_dict']
    need_ingredient_list = input_data['need_ingredient_list']

    db = {}
    for item in need_ingredient_list:
        name = item['ingredient_name'].strip()
        db[name] = {
            'cal': float(item['calories']),
            'p': float(item['protein']),
            'f': float(item['fat']),
            'c': float(item['carbo'])
        }

    food_base_data = {}
    
    print(f"--- 1. 预计算食物基准营养 ---")
    for meal_key, food_list in meal_food_dict.items():
        food_base_data[meal_key] = {}
        for food_idx, food in enumerate(food_list):
            # 统计这道菜所有食材的总营养 (100% 分量时)
            total_cal = 0
            total_p = 0
            total_f = 0
            total_c = 0
            
            ingredient_arr = food.get('ingredient_arr', [])
            for ing in ingredient_arr:
                ing_name = ing['ingredient_name'].strip()
                try:
                    w_str = ing['weight'].lower().replace('g', '')
                    w_val = float(w_str) # 克重
                except:
                    continue
                
                nuts = db.get(ing_name, {'cal':0, 'p':0, 'f':0, 'c':0})
                
                ratio = w_val / 100.0
                total_cal += ratio * nuts['cal']
                total_p   += ratio * nuts['p']
                total_f   += ratio * nuts['f']
                total_c   += ratio * nuts['c']
            
            food_base_data[meal_key][food_idx] = {
                'cal': int(total_cal * SCALE_NUTRIENT),
                'p':   int(total_p * SCALE_NUTRIENT),
                'f':   int(total_f * SCALE_NUTRIENT),
                'c':   int(total_c * SCALE_NUTRIENT),
                'orig_obj': food
            }

    food_vars = {}
    objective_terms = []
    all_vars_list = [] 


    for meal_key, food_list in meal_food_dict.items():
        food_vars[meal_key] = {}
        for food_idx, food in enumerate(food_list):
            
            f_category = food.get('food_category', '').strip()
            is_staple = any(keyword in f_category for keyword in STAPLE_KEYWORDS)
            
            if is_staple:
                min_ratio = STAPLE_MIN_PCT
                max_ratio = STAPLE_MAX_PCT
            else:
                min_ratio = GEN_MIN_PCT
                max_ratio = GEN_MAX_PCT
            
            var_name = f"ratio_{meal_key}_{food_idx}"
            ratio_var = model.NewIntVar(min_ratio, max_ratio, var_name)
            
            food_vars[meal_key][food_idx] = ratio_var
            
            base_nuts = food_base_data[meal_key][food_idx]
            all_vars_list.append({
                'var': ratio_var,
                'meal': meal_key,
                'base_nuts': base_nuts
            })
            
            diff = model.NewIntVar(0, 100, f"diff_{var_name}")
            model.Add(diff >= ratio_var - 100)
            model.Add(diff >= 100 - ratio_var)
            objective_terms.append(diff * PENALTY_CHANGE)

    if not all_vars_list:
        print("错误：未识别到任何有效食物。")
        return None

    
    LARGE_BOUND = int(1e10) 

    total_cal_expr = sum(v['var'] * v['base_nuts']['cal'] for v in all_vars_list)
    
    target_min_val = int(calories_config['daily_total_calories_target_min'] * SCALE_NUTRIENT * 100)
    target_max_val = int(calories_config['daily_total_calories_target_max'] * SCALE_NUTRIENT * 100)
    
    cal_shortage = model.NewIntVar(0, LARGE_BOUND, "cal_shortage")
    model.Add(total_cal_expr >= target_min_val - cal_shortage)
    objective_terms.append(cal_shortage * PENALTY_CALORIE_MISS)
    
    cal_excess = model.NewIntVar(0, LARGE_BOUND, "cal_excess")
    model.Add(total_cal_expr <= target_max_val + cal_excess)
    objective_terms.append(cal_excess * PENALTY_CALORIE_MISS)

    meal_cal_exprs = {}
    for m in ['breakfast', 'lunch', 'dinner', 'snack']:
        meal_cal_exprs[m] = 0
        
    for v in all_vars_list:
        m_key = v['meal']
        if 'snack' in m_key: group = 'snack'
        else: group = m_key
        
        if group in meal_cal_exprs:
            if isinstance(meal_cal_exprs[group], int):
                meal_cal_exprs[group] = v['var'] * v['base_nuts']['cal']
            else:
                meal_cal_exprs[group] += v['var'] * v['base_nuts']['cal']

    RATIO_SCALE = 100 
    
    for m_key, r_range in meal_ratio_ranges.items():
        expr = meal_cal_exprs.get(m_key, 0)
        if isinstance(expr, int) and expr == 0: continue

        r_min = int(r_range[0] * RATIO_SCALE)
        r_max = int(r_range[1] * RATIO_SCALE)
        
        r_short = model.NewIntVar(0, LARGE_BOUND, f"{m_key}_short")
        model.Add(expr * RATIO_SCALE + r_short >= r_min * total_cal_expr)
        objective_terms.append(r_short * PENALTY_RATIO_MISS)

        r_excess = model.NewIntVar(0, LARGE_BOUND, f"{m_key}_excess")
        model.Add(expr * RATIO_SCALE - r_excess <= r_max * total_cal_expr)
        objective_terms.append(r_excess * PENALTY_RATIO_MISS)

    macro_factors = {'protein': 4, 'fat': 9, 'carb': 4}
    
    total_macros = {
        'protein': sum(v['var'] * v['base_nuts']['p'] for v in all_vars_list),
        'fat':     sum(v['var'] * v['base_nuts']['f'] for v in all_vars_list),
        'carb':    sum(v['var'] * v['base_nuts']['c'] for v in all_vars_list)
    }
    
    for m_key, r_range in macro_ratio_ranges.items():
        macro_energy_expr = total_macros[m_key] * macro_factors[m_key]
        
        r_min = int(r_range[0] * RATIO_SCALE)
        r_max = int(r_range[1] * RATIO_SCALE)
        
        m_short = model.NewIntVar(0, LARGE_BOUND, f"{m_key}_macro_short")
        model.Add(macro_energy_expr * RATIO_SCALE + m_short >= r_min * total_cal_expr)
        objective_terms.append(m_short * PENALTY_RATIO_MISS)
        
        m_excess = model.NewIntVar(0, LARGE_BOUND, f"{m_key}_macro_excess")
        model.Add(macro_energy_expr * RATIO_SCALE - m_excess <= r_max * total_cal_expr)
        objective_terms.append(m_excess * PENALTY_RATIO_MISS)

    model.Minimize(sum(objective_terms))
    solver = cp_model.CpSolver()
    
    status = solver.Solve(model)
    
    if status == cp_model.OPTIMAL or status == cp_model.FEASIBLE:
        
        final_total_cal = solver.Value(total_cal_expr) / (SCALE_NUTRIENT * 100)
        
        new_meal_food_dict = json.loads(json.dumps(meal_food_dict))
        
        daily_stats = {'cal': 0, 'p': 0, 'f': 0, 'c': 0}
        
        print(f"\n{'='*20} 优化结果 (Food-Level) {'='*20}")
        print(f"{'食物名称':<15} | {'缩放比例':<8} | {'热量(kcal)':<10}")
        print("-" * 50)
        
        for meal_key in new_meal_food_dict.keys():
            food_list = new_meal_food_dict[meal_key]
            meal_cal = 0
            
            for food_idx, food in enumerate(food_list):
                if food_idx in food_vars.get(meal_key, {}):
                    ratio_val = solver.Value(food_vars[meal_key][food_idx])
                    ratio_float = ratio_val / 100.0
                    
                    base_cal = food_base_data[meal_key][food_idx]['cal'] / SCALE_NUTRIENT
                    final_cal = base_cal * ratio_float
                    meal_cal += final_cal
                    
                    print(f"{food['food_name']:<15} | {ratio_val}%      | {final_cal:.1f}")
                    
                    ingredient_arr = food.get('ingredient_arr', [])
                    for ing in ingredient_arr:
                        try:
                            orig_w = float(ing['weight'].lower().replace('g', ''))
                            new_w = orig_w * ratio_float
                            ing['weight'] = f"{new_w:.1f}g"
                            
                            ing_name = ing['ingredient_name'].strip()
                            nuts = db.get(ing_name, {'cal':0, 'p':0, 'f':0, 'c':0})
                            daily_stats['cal'] += (new_w / 100.0) * nuts['cal']
                            daily_stats['p']   += (new_w / 100.0) * nuts['p']
                            daily_stats['f']   += (new_w / 100.0) * nuts['f']
                            daily_stats['c']   += (new_w / 100.0) * nuts['c']
                            
                        except:
                            pass
            
            if final_total_cal > 0:
                nutrition_dict["meal_energy"][meal_key] = f"{(meal_cal / final_total_cal * 100):.1f}%"
                if meal_key.startswith('snack'):
                    pass 

        total_macro_energy = (daily_stats['p'] * 4) + (daily_stats['f'] * 9) + (daily_stats['c'] * 4)
        
        if total_macro_energy > 0:
            nutrition_dict["macros_energy"]["protein"] = f"{(daily_stats['p'] * 4 / total_macro_energy * 100):.1f}%"
            nutrition_dict["macros_energy"]["fat"]     = f"{(daily_stats['f'] * 9 / total_macro_energy * 100):.1f}%"
            nutrition_dict["macros_energy"]["carb"]    = f"{(daily_stats['c'] * 4 / total_macro_energy * 100):.1f}%"

        print("-" * 50)
        print(f"优化后总热量: {daily_stats['cal']:.1f} kcal")
        print(f"目标区间: [{calories_config['daily_total_calories_target_min']}, {calories_config['daily_total_calories_target_max']}]")

        return new_meal_food_dict, nutrition_dict
        
    else:
        print(f"求解失败。状态码: {status}")
        return None, None