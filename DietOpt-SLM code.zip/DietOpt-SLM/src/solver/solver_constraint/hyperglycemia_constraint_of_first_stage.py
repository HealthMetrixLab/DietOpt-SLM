import sys
from pathlib import Path
import random

project_root = str(Path(__file__).parent.parent.parent.parent)
sys.path.append(project_root)
from ortools.sat.python import cp_model

from clazz.utils.logger_util import logger
from clazz.common.common_utils import CommonUtils
from config.constants import Constants
from config.solver_constraint_config.food_category_frequency_config_by_solver_space import FrequencyFoodCategoryConfigBySolverSpace


def add_constraint_of_the_first_stage_hyperglycemia(model, cons_dict:dict):
    
    can_choose_food_size = cons_dict["can_choose_food_size"]

    health_risk_arr = cons_dict["health_risk_arr"]
    type_info = cons_dict["type_info"]
    day_name = cons_dict["day_name"]
    include_snack = cons_dict["include_snack"]
    meal_keys = cons_dict["meal_keys"]

    y: dict[int, dict[str, dict[int, cp_model.IntVar]]] = {}
    var_count = 0
    var_dict = {}  

    parent_type_list = [
        "主食", "蔬菜", "肉蛋鱼与海产", "豆类与豆制品", "水果", "饮品", "零食与甜点"
    ]

    meal_allowed_type = {
        "breakfast": {
            "粥/糊/羹", "杂粮饭", "其他杂粮主食", "包子", "米饭", "馒头/花卷/窝头", "面条/米粉/粉丝/皮"
            "凉拌蔬菜", "炒/烧/焖/烩蔬菜", "蒸/煮蔬菜", "芽苗类", "菌类菜肴", 
            "豆浆/豆奶",
            "奶类饮品",
            "水煮蛋", "蒸蛋"
        },
        "lunch": {
            "米饭", "炒饭", "盖饭/焖饭/抓饭", "饼", "馒头/花卷/窝头", "杂粮饭", "其他杂粮主食", 
            "炒/烧/焖/烩蔬菜", "凉拌蔬菜", "蒸/煮蔬菜", "芽苗类", "菌类菜肴", 
            "蔬菜汤羹",
            "畜肉类菜肴", "禽肉类菜肴", "畜肉汤羹", "禽肉汤羹",
            "蛋类菜肴", "鱼类菜肴", "虾蟹贝类菜肴", "鱼类汤羹", "虾蟹贝类汤羹", 
            "豆腐/豆干/豆花菜肴", "腐竹/豆皮/面筋菜肴", "豆类菜肴", "豆制品汤羹"
        },
        "dinner": {
            "米饭", "炒饭", "盖饭/焖饭/抓饭", "饼", "馒头/花卷/窝头", "杂粮饭", "其他杂粮主食", 
            "炒/烧/焖/烩蔬菜", "凉拌蔬菜", "蒸/煮蔬菜", 
            "蔬菜汤羹", 
            "畜肉类菜肴", "禽肉类菜肴", "畜肉汤羹", "禽肉汤羹",
            "蛋类菜肴", "鱼类菜肴", "虾蟹贝类菜肴", "鱼类汤羹", "虾蟹贝类汤羹", 
            "豆腐/豆干/豆花菜肴", "腐竹/豆皮/面筋菜肴", "豆类菜肴", "豆制品汤羹"
        }
    }
    snack_allowed_type = {
        "奶类饮品", 
        "坚果/籽类零食",
        "新鲜水果",
    }
    if include_snack:
        meal_allowed_type["snack"] = snack_allowed_type
    mutual_exclusions = {
        "breakfast": ["粥/糊/羹", "面条/米粉/粉丝/皮", "饺子/馄饨/烧卖", "蛋类汤羹", "豆浆/豆奶"],
        "lunch": [
            "蔬菜汤羹", "畜肉汤羹", "禽肉汤羹", "蛋类汤羹", "鱼类汤羹", "虾蟹贝类汤羹",
            "其他水产汤羹", "豆制品汤羹"
        ],
        "dinner": [
            "蔬菜汤羹", "畜肉汤羹", "禽肉汤羹", "蛋类汤羹", "鱼类汤羹", "虾蟹贝类汤羹",
            "其他水产汤羹", "豆制品汤羹"
        ],
        "snack": []
    }
    meal_category_serving_limits = {
        'breakfast': [
            ['主食', '蔬菜', "|豆类与豆制品"],
            ['主食', '蔬菜', "|饮品"],
            ['主食', '蔬菜', "|肉蛋鱼与海产"],
        ],
        'lunch': [
            ['主食', '蔬菜', '肉蛋鱼与海产']
        ],
        'dinner': [
            ['主食', '蔬菜', '肉蛋鱼与海产']
        ]
    }

    if health_risk_arr and len(health_risk_arr) > 0:
        if "高血糖" in health_risk_arr or "糖尿病" in health_risk_arr:
            not_allowed_type = {"粥/糊/羹", "水果饮品/汁/酱", "果汁饮品"}
            for meal_type in meal_allowed_type:
                meal_allowed_type[meal_type] = [
                    t for t in meal_allowed_type[meal_type] if t not in not_allowed_type
                ]
            snack_allowed_type = [
                t for t in snack_allowed_type if t not in not_allowed_type
            ]
    logger.info(f"【求解器】---求解阶段一: 创建 OR-Tools CP-SAT 模型...")
    logger.info(f"【求解器】---步骤 4.1：获取模型参数")
    num_day = len(day_name)
    num_type = len(type_info["type_data_flat"])
    type_category_list = type_info["type_category_list"]
    type_scaled_u_per_increment = type_info["type_scaled_u_per_increment"]
    category_list = type_info["type_category_list"]
    context_data = type_info["context_data"]
    type_pairing_data = type_info["type_pairing_data"]
    logger.info(f"【求解器】---可选的食物种类细类数量（最后一级类别）：{num_type}")

    logger.info(f"【求解器】---步骤 4.2: 创建 CP-SAT 决策变量 (y, steps)...")

    for d in range(num_day):
        y[d] = {}
        for m in meal_keys:
            y[d][m] = {}
            allowed_subcodes_for_meal = meal_allowed_type.get(m, set())
            for i in range(num_type):
                if type_category_list[i][-1] in allowed_subcodes_for_meal:
                    y_var = model.NewBoolVar(name=f"y_{d}_{m}_{i}")
                    y[d][m][i] = y_var
                    var_dict[y_var.Index()] = f"y_{d}_{m}_{i}"
                    var_count += 1
    cons_count = 0
    for d in range(num_day):
        for m in mutual_exclusions:
            if mutual_exclusions[m]:
                model.AddAtMostOne(
                    y[d][m][i] for i in range(num_type)
                    if i in y[d].get(m, {})
                    and category_list[i][-1] in mutual_exclusions[m])
                cons_count += 1
    for d in range(num_day):
        for m in meal_keys:
            for parent_type in parent_type_list:
                model.AddAtMostOne(y[d][m][i] for i in range(num_type)
                                    if i in y[d].get(m, {})
                                    and category_list[i][0] == parent_type)
                cons_count += 1
    presence_cons_count = 0
    

    check_meal_obj = {}

    for d in range(num_day):
        for m in meal_category_serving_limits:
            if m not in meal_keys: continue
            all_limit_arr = meal_category_serving_limits[m]

            seven_day_meal_index_arr = []
            if m not in check_meal_obj:
                seven_day_meal_index_arr = CommonUtils.balanced_random_meal(range(len(all_limit_arr)))
                check_meal_obj[m] = seven_day_meal_index_arr
            else:
                seven_day_meal_index_arr = check_meal_obj[m]

            random_num = seven_day_meal_index_arr[d]
            
            using_limit_arr = all_limit_arr[random_num]

            allowed_categories = [s.lstrip("|") for s in using_limit_arr] 

            for parent_type_raw in using_limit_arr:
                is_optional = parent_type_raw.startswith("|")
                parent_type = parent_type_raw.lstrip("|")

                relevant_y_vars = [
                    y[d][m][i] for i in range(num_type)
                    if i in y[d].get(m, {})
                    and category_list[i][0] == parent_type
                ]
                if not relevant_y_vars:
                    logger.warning(f"【求解器】---警告: Day {d}, Meal {m}, 类别 '{parent_type}' 没有找到候选变量。")
                    logger.warning(
                        f"【求解器】---严重警告: Day {d}, Meal {m}, 必需类别 '{parent_type}' 没有找到任何可选食物变量！这很可能导致模型不可行。"
                    )
                    continue

                if not is_optional:
                    model.Add(sum(relevant_y_vars) >= 1)
                    presence_cons_count += 1
                else:
                    logger.warning(f"【求解器】---可选类别 '{parent_type}' 已跳过强制约束。")

                other_y_vars = [
                    y[d][m][i] for i in range(num_type)
                    if i in y[d].get(m, {}) and category_list[i][0] not in allowed_categories
                ]
                if other_y_vars:
                    for var in other_y_vars:
                        model.Add(var == 0)
    cons_count += presence_cons_count
    frequency_food_category_config = \
        FrequencyFoodCategoryConfigBySolverSpace.get_frequency_food_category_config(can_choose_food_size)
    for i in range(num_type):
        category_path = category_list[i]

        food_first_category = category_path[0]
        limits = []
        if food_first_category in frequency_food_category_config:
            limits = frequency_food_category_config[food_first_category]
        else:
            limits = frequency_food_category_config.get("其他", [2, 10])
        if not limits or len(limits) != 2:
            continue
        day_limit = limits[0]
        week_limit = limits[1]

        model.Add(
            sum(y[d][m][i] for d in range(num_day)
                for m in y[d] if i in y[d][m]) <= week_limit
        )
        cons_count += 1

        for d in range(num_day):
            model.Add(
                sum(y[d][m][i] for m in y[d] if i in y[d][m]) <= day_limit
            )
            cons_count += 1

    special_limits = {
        "馒头/花卷/窝头": {"day": 1, "week": 4},
        "米饭": {"day": 2, "week": 10},
        "畜肉类菜肴": {"day": 1, "week": 7},
        "禽肉类菜肴": {"day": 1, "week": 7},
        "虾蟹贝类菜肴": {"day": 1, "week": 6},
        "蒸/煮蔬菜": {"day": 2, "week": 12},
        "炒/烧/焖/烩蔬菜": {"day": 2, "week": 12},
        "凉拌蔬菜": {"day": 1, "week": 7},
        "芽苗类": {"day": 1, "week": 7},
        "菌类菜肴": {"day": 1, "week": 6},
        "新鲜水果": {"day": 2, "week": 12},
        "坚果/籽类零食": {"day": 2, "week": 14},
        "默认": {"day": 3, "week": 14}
    }
    
    for i in range(num_type):
        category_path = category_list[i] 

        special = None
        for key in special_limits:
            if key in category_path:
                special = special_limits[key]
                break
        
        if not special:
            special = special_limits["默认"]

        week_limit = special["week"]
        model.Add(
            sum(y[d][m][i] for d in range(num_day)
                for m in y[d] if i in y[d][m]) <= week_limit
        )
        cons_count += 1

        day_limit = special["day"]
        for d in range(num_day):
            model.Add(sum(y[d][m][i] for m in y[d] if i in y[d][m]) <= day_limit)
            cons_count += 1
    

    mutual_exclusive_groups = [
        {
            "members": ["蔬菜汤羹", "畜肉汤羹", "禽肉汤羹", "虾蟹贝类汤羹", "鱼类汤羹","蛋类汤羹", "豆制品汤羹"],
            "day": 1,
            "week": 3
        },
        {
            "members": ["鱼类汤羹", "鱼类菜肴", "虾蟹贝类菜肴", "虾蟹贝类汤羹"],
            "day": 1,
            "week": 2
        },
    ]
    objective_terms = []
    for g_idx, group in enumerate(mutual_exclusive_groups):
        members = group["members"]
        day_limit = group["day"]
        week_limit = group["week"]

        group_indices = [
            i for i in range(num_type)
            if any(m in category_list[i] for m in members)
        ]
        if not group_indices:
            continue

        week_expr = sum(
            y[d][m][i]
            for d in range(num_day)
            for m in y[d]
            for i in group_indices if i in y[d][m]
        )
        model.Add(week_expr <= week_limit)
        cons_count += 1

        for d in range(num_day):
            day_expr = sum(
                y[d][m][i]
                for m in y[d]
                for i in group_indices if i in y[d][m]
            )
            model.Add(day_expr <= day_limit)
            cons_count += 1

        norm_var = model.NewIntVar(0, 100, f"group_norm_{g_idx}")
        model.Add(norm_var * week_limit == week_expr * 100)

        penalty = model.NewIntVar(0, 10000, f"group_penalty_{g_idx}")
        model.AddMultiplicationEquality(penalty, [norm_var, norm_var])

        objective_terms.append(penalty)

    return model,y,cons_count


if __name__ == '__main__':
    print('---start---')