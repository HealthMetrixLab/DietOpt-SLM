import asyncio
import math
import time
import json
from typing import Dict, Any, List, Set, DefaultDict
import math
import traceback
from ortools.sat.python import cp_model
import os, sys, contextlib



import sys
from pathlib import Path

project_root = str(Path(__file__).parent.parent.parent)
sys.path.append(project_root)

from src.solver.alternative_type_process import alternative_type_process
from src.solver.food_solver import food_solver
from src.solver.solver_constraint_of_the_first_stage import add_constraint_of_the_first_stage
from src.solver.recipe_solver.main_recipe_solver import recipe_solver_function

from config.solver_constraint_config.solver_diet_mode_dict_config import SolverDietModeDict
from config.constants import Constants
from config.reasoning_constraint_config.disease_selection_priority_config \
    import DiseaseSelectionPriorityConfig
from config.solver_constraint_config.food_component_constraints_for_chronic_diseases_config \
    import FoodComponentConstraintsForChronicDiseasesConfig
from clazz.utils.logger_util import logger

from src.util.analyse_result_util import analyse_meal_info
from src.util.main_execute_llm_fun import (
    execute_llm_analyse_meal_rationality_by_cons,
)



def optimize_plan_node(params_dict: dict) -> dict[str, Any]:
    

    node_start_time = time.time()
    current_date_str = time.strftime("%Y%m%d", time.localtime())

    epsilon = 1e-6 

    first_output = {
        "overall_status": "init",
        "solving_time": 0.0, 
        "total_objective": 0.0, 
        "weekly_plan": [] 
    }

    data = params_dict["data"]

    save_local_flag = False
    is_save_main_process_result = data.get("is_save_main_process_result", "0")
    logger.info(f'----------------is_save_main_process_result:{is_save_main_process_result}----------------------')
    if is_save_main_process_result == 1 or is_save_main_process_result == '1':
        save_local_flag = True

    food_type_matching = data.get('food_type_matching', [])
    user_info = data.get('user_info', {})
    alternative_food = data.get('alternative_foods', {})
    alternative_type = data.get('food_category_preferences_and_suitability', {})

    can_choose_food_size = len(alternative_food)
    logger.info(f'【求解器】---可选择的食物数量：{can_choose_food_size}')

    nutrition_solver_params = {}

    try: 
        user_id = user_info.get("id", "unknown_user")
        user_height = float(user_info.get("height"))
        user_weight = float(user_info.get("weight"))
        user_age = float(user_info.get("age"))
        user_gender = 1 if user_info.get("sex") == "女" or user_info.get("gender") == "女" else 0
        user_pa = float(user_info.get("pa"))
        user_diet_mode = user_info.get("dietary_pattern")
        user_diet_mode_name = user_info.get("dietary_pattern_name")
        user_snack = int(user_info.get("snack"))
        nutrition_target = user_info.get("nutrition_target", "")
        user_self_report = user_info["user_self_report"]
        health_risk_arr = user_info.get("health_risk_arr", [])
        disease_priority, disease_priority_name = \
            DiseaseSelectionPriorityConfig.get_disease_selection_priority_by_disease_name(health_risk_arr)
        
        status_map = {
            cp_model.OPTIMAL: "optimal",
            cp_model.FEASIBLE: "feasible",
            cp_model.INFEASIBLE: "infeasible",
            cp_model.MODEL_INVALID: "error_model_invalid",
            cp_model.UNKNOWN: "unknown"
        }


        other_requirements = {}
        daily_total_calories_target: float = 1
        REE = (
            user_gender * (655.096 + 9.563 * user_weight + 1.850 * user_height - 4.676 * user_age) +
            (1 - user_gender) * ( 66.473 + 13.752 * user_weight + 5.003 * user_height - 6.755 * user_age)
        )
        if user_gender == 1:
            logger.info(f"【求解器】--------计算得出的REE = 655.096 + {9.563 * user_weight:.2f} + {1.850 * user_height:.2f} -{4.676 * user_age:.2f}")
        else:
            logger.info(f"【求解器】--------计算得出的REE = 66.473 + {13.752 * user_weight:.2f} + {5.003 * user_height:.2f} -{6.755 * user_age:.2f}")
        

        for code, diet_mode in SolverDietModeDict.diet_mode_dict.items():
            if user_diet_mode == code:
                daily_total_calories_target: float = REE * user_pa * diet_mode["Parameters"]["cal_factor"]
                meal_ratio_ranges = diet_mode["Parameters"]["three_meal_ratios"]  # e.g. {"breakfast": [0.3, 0.4], ...}
                macro_ratio_ranges = diet_mode["Parameters"]["nutrient_ratios"]  # e.g. {"protein": [0.15, 0.20], ...}
            if user_diet_mode == "MODLE_05":
                daily_total_calories_target: float = 1000
            if user_diet_mode == "MODLE_06":
                daily_total_calories_target: float = 800
            if user_diet_mode == "MODLE_07":
                other_requirements["含盐量"] = "每日盐摄入量为1~4克"
            if user_diet_mode == "MODEL_16":
                other_requirements[
                    "用餐时间"] = "请选择一种安排定时用餐：7——11——15点 或 8-12-16点 或 9-13-17点"
            if user_diet_mode == "MODEL_17":
                other_requirements[
                    "饮食要求"] = "动物内脏、蛋黄每周≤2次，每日胆固醇<200mg，降低低密度脂蛋白的饮食选择，每天2克植物甾醇或甾醇，每天10-25克可溶性纤维"
            if user_diet_mode == "MODEL_12":
                other_requirements["食物选择"] = "请选择低GI的碳水来源"

        if not daily_total_calories_target:
            raise ValueError("优化节点错误: 缺少总热量摄入数据 (nutrition_targets)")
        if not meal_ratio_ranges:
            raise ValueError("优化节点错误: 缺少三餐比例范围数据 (three_meals_ratios)")
        if not macro_ratio_ranges:
            raise ValueError("优化节点错误: 缺少宏量营养素比例范围数据 (nutrient_ratios)")
        if not all(k in macro_ratio_ranges
                   for k in ["protein", "fat", "carb"]):
            raise ValueError("优化节点错误: 宏量营养素比例数据缺少键 (需要 protein, fat, carb)")
        meal_range_low_bound, meal_range_up_bound = 0, 0
        for meal, ratio_range in meal_ratio_ranges.items():
            meal_range_low_bound += ratio_range[0]
            meal_range_up_bound += ratio_range[1]

        macro_range_low_bound, macro_range_up_bound = 0, 0
        for macro, ratio_range in macro_ratio_ranges.items():
            macro_range_low_bound += ratio_range[0]
            macro_range_up_bound += ratio_range[1]
        if not meal_range_low_bound < 1:
            raise ValueError(f"优化节点错误：三餐供能比下限{meal_range_low_bound}大于100%")
        if not meal_range_up_bound > 1:
            raise ValueError("优化节点错误：三餐供能比上限小于100%")
        if not macro_range_low_bound < 1:
            raise ValueError("优化节点错误：营养素供能比下限大于100%")
        if not macro_range_up_bound > 1:
            raise ValueError("优化节点错误：营养素供能比上限小于100%")

        logger.info(f"【求解器】---步骤 1.1: 动态判断是否包含加餐")
        base_meal_keys = ["breakfast", "lunch", "dinner"]
        snack_ratio_range = meal_ratio_ranges.get("snack", [0.0, 0.0])
        include_snack = isinstance(snack_ratio_range, list) and len(
            snack_ratio_range
        ) == 2 and snack_ratio_range[1] > epsilon and user_snack
        meal_keys = base_meal_keys + ["snack"] if include_snack else base_meal_keys
        logger.info(f"【求解器】---是否包含加餐 (include_snack): {include_snack} (比例范围: {snack_ratio_range})")
        logger.info(f"【求解器】---本次优化包含的餐次: {meal_keys}")
        if not all(k in meal_ratio_ranges for k in meal_keys):
            missing_keys = [k for k in meal_keys if k not in meal_ratio_ranges]
            raise ValueError(f"优化节点错误: 餐次比例数据缺少键: {missing_keys}")

        logger.info(f"【求解器】---步骤 2.1: 配置优化器参数")
        serving_increment = 0.5 
        min_serving_units = 0.5
        if serving_increment <= epsilon:
            raise ValueError("serving_increment 必须为正数")
        min_steps_per_selection = math.ceil(
            min_serving_units /
            serving_increment) 
        if min_steps_per_selection <= 0:
            print(
                f"      警告: 计算得到的最小步数 ({min_steps_per_selection}) 非正数。将强制设为 1。"
            )
            min_steps_per_selection = 1

        SCALE_FACTOR = Constants.SCALE_FACTOR
        logger.info(f"【求解器】---CP-SAT 缩放因子 (SCALE_FACTOR): {SCALE_FACTOR}")
        logger.info(f"【求解器】---步骤 3: 定义食物类别、规则和常量")
        day_name = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]

        logger.info(f"【求解器】---步骤 4: 预处理食物数据，提取优化所需信息，并进行缩放")
        logger.info(f"【求解器】---步骤 4.1: 解析营养目标并计算范围")
        if daily_total_calories_target <= epsilon:
            raise ValueError("目标总热量必须为正数")

        logger.warning(f"【求解器】----------------------【目标能量、允许范围及缩放到整数范围】（开始）----------------------")
        logger.info(f"【求解器】---目标能量: {daily_total_calories_target} kcal")
        daily_total_calories_target = round(daily_total_calories_target, 1)
        logger.info(f"【求解器】---目标能量（保留一位小数）: {daily_total_calories_target} kcal")
        
        total_cal_tolerance = Constants.TOTAL_CAL_TOLERANCE
        min_total_cal = daily_total_calories_target * (1 - total_cal_tolerance)
        max_total_cal = daily_total_calories_target * (1 + total_cal_tolerance)
        logger.info(f"【求解器】---目标能量允许的缩放范围：{total_cal_tolerance}。")
        logger.info(f"【求解器】---目标能量允许的范围: [{min_total_cal} ~ {max_total_cal}] kcal。")
        min_total_cal = round_with_mode(min_total_cal, 1, 'ceil')
        max_total_cal = round_with_mode(max_total_cal, 1, 'floor')
        logger.info( f"【求解器】---目标能量允许的范围（保留一位小数）: [{min_total_cal} ~ {max_total_cal}] kcal")

        scaled_min_total_cal = int(min_total_cal * SCALE_FACTOR)
        scaled_max_total_cal = int(max_total_cal * SCALE_FACTOR)
        logger.info(f"【求解器】---缩放到整数范围区间: [{scaled_min_total_cal}, {scaled_max_total_cal}]")
        scaled_min_total_cal = round(scaled_min_total_cal)
        scaled_max_total_cal = round(scaled_max_total_cal)
        logger.info(f"【求解器】---缩放到整数范围区间(取整数): [{scaled_min_total_cal}, {scaled_max_total_cal}]")

        actual_min_total_cal = daily_total_calories_target * (
                1 - total_cal_tolerance * Constants.ACTUAL_SCALING_COEFFICIENT
        )
        actual_max_total_cal = daily_total_calories_target * (
                1 + total_cal_tolerance * Constants.ACTUAL_SCALING_COEFFICIENT
        )
        logger.info(f"【求解器】---目标能量允许的缩放范围：{total_cal_tolerance}。")
        logger.info(f"【求解器】---目标能量允许的范围（实际）: [{actual_min_total_cal} ~ {actual_max_total_cal}] kcal。")
        actual_min_total_cal = round_with_mode(actual_min_total_cal, 1, 'ceil')
        actual_max_total_cal = round_with_mode(actual_max_total_cal, 1, 'floor')
        logger.info( f"【求解器】---目标能量允许的范围（实际）（保留一位小数）: [{actual_min_total_cal} ~ {actual_max_total_cal}] kcal")

        actual_scaled_min_total_cal = int(actual_min_total_cal * SCALE_FACTOR)
        actual_scaled_max_total_cal = int(actual_max_total_cal * SCALE_FACTOR)
        logger.info(f"【求解器】---缩放到整数范围区间（实际）: [{actual_scaled_min_total_cal}, {actual_scaled_max_total_cal}]")
        actual_scaled_min_total_cal = round(actual_scaled_min_total_cal)
        actual_scaled_max_total_cal = round(actual_scaled_max_total_cal)
        logger.info(f"【求解器】---缩放到整数范围区间（实际）: [{actual_scaled_min_total_cal}, {actual_scaled_max_total_cal}]")
        logger.warning(f"【求解器】----------------------【目标能量、允许范围及缩放到整数范围】（结束）----------------------")


        logger.warning(f"【求解器】----------------------【宏量营养素供能比范围-能量】（开始）----------------------")
        logger.info(f"【求解器】---目标总热量: {daily_total_calories_target:.1f} kcal (允许范围: [{min_total_cal:.1f}, {max_total_cal:.1f}])")
        logger.info(f"【求解器】---实际允许热量范围: [{actual_min_total_cal:.1f}, {actual_max_total_cal:.1f}]")
        logger.info(f"【求解器】---缩放后热量范围 (整数): [{scaled_min_total_cal}, {scaled_max_total_cal}]")
        logger.info(f"【求解器】---缩放后热量范围 (实际): [{actual_scaled_min_total_cal}, {actual_scaled_max_total_cal}]")
        logger.info(f"【求解器】---餐次热量比例范围: {meal_ratio_ranges}")
        logger.info(f"【求解器】---宏量营养素供能比范围: {macro_ratio_ranges}")
        logger.warning(f"【求解器】----------------------【宏量营养素供能比范围-能量】（结束）----------------------")

        PROTEIN_CAL_FACTOR = Constants.PROTEIN_CAL_FACTOR
        FAT_CAL_FACTOR = Constants.FAT_CAL_FACTOR
        CARB_CAL_FACTOR = Constants.CARB_CAL_FACTOR
        daily_target_grams_macros = {}
        for macro_key, cal_per_g in [("protein", PROTEIN_CAL_FACTOR),
                                     ("fat", FAT_CAL_FACTOR),
                                     ("carb", CARB_CAL_FACTOR)]:
            min_ratio, max_ratio = macro_ratio_ranges[macro_key]
            target_ratio = (min_ratio + max_ratio) / 2  
            target_calories_from_macro = daily_total_calories_target * target_ratio
            target_gram = target_calories_from_macro / cal_per_g
            daily_target_grams_macros[macro_key] = round(target_gram, 1)
        logger.warning(f"【求解器】----------------------【宏量营养素供能比范围-其他】（开始）----------------------")
        logger.info(f"【求解器】---每日目标宏量营养素摄入量 (克): {json.dumps({k: round(v,1) for k,v in daily_target_grams_macros.items()})}")
        logger.warning(f"【求解器】----------------------【宏量营养素供能比范围-其他】（结束）----------------------")

        logger.warning(f"【求解器】----------------------【宏量营养素供能比范围-营养占比】（开始）----------------------")
        user_nutrition_info = {
            "scaled_calories_range":[scaled_min_total_cal, scaled_max_total_cal],
            "meal_ratio_ranges": meal_ratio_ranges,
            "macro_ratio_ranges": macro_ratio_ranges,
        }
        logger.info(f"【求解器】----用户营养占比信息：{user_nutrition_info}")
        user_nutrition_info = {
            "scaled_calories_range": [actual_scaled_min_total_cal, actual_scaled_max_total_cal],
            "meal_ratio_ranges": meal_ratio_ranges,
            "macro_ratio_ranges": macro_ratio_ranges,
        }
        logger.info(f"【求解器】----用户营养占比信息（实际）：{user_nutrition_info}")
        logger.warning(f"【求解器】----------------------【宏量营养素供能比范围-营养占比】（结束）----------------------")

        nutrition_solver_params['calories'] = {
            "daily_total_calories_target": daily_total_calories_target,
            "daily_total_calories_target_min": min_total_cal,
            "daily_total_calories_target_max": max_total_cal,
            "actual_min_total_cal": actual_min_total_cal,
            "actual_max_total_cal": actual_max_total_cal,
            "total_cal_tolerance": total_cal_tolerance,
            "scaled_min_total_cal": scaled_min_total_cal,
            "scaled_max_total_cal": scaled_max_total_cal
        }
        nutrition_solver_params['meal_ratio_ranges'] = meal_ratio_ranges
        nutrition_solver_params['macro_ratio_ranges'] = macro_ratio_ranges
        nutrition_solver_params['daily_target_grams_macros'] = daily_target_grams_macros


        solver_params_dict = {
            "disease_name": disease_priority_name,
            "nutrition_target": nutrition_target,
            "mode": user_diet_mode,
            "activity_level": user_pa,
            "total_energy": daily_total_calories_target,
            "not_recommended_food_list": [],
        }

        logger.info(f"【求解器】---步骤 4.2: 转换食物数据格式，计算缩放后的营养值和效用")
        type_info = alternative_type_process(SCALE_FACTOR, alternative_food,
                                             alternative_type,
                                             food_type_matching,
                                             serving_increment)
        last_level_categories = type_info["last_level_categories"]
        num_day = len(day_name)
        num_type = len(type_info["type_data_flat"])
        type_category_list = type_info["type_category_list"]

        constraint_of_the_first_stage_dict = {
            "health_risk_arr": health_risk_arr,
            "type_info": type_info,
            "day_name": day_name,
            "include_snack": include_snack,
            "meal_keys": meal_keys,
            "serving_increment": serving_increment,
            "can_choose_food_size": can_choose_food_size,
        }

        y: dict[int, dict[str, dict[int, cp_model.IntVar]]] = {}

        model = cp_model.CpModel()
        model,y,cons_count = add_constraint_of_the_first_stage(model, constraint_of_the_first_stage_dict)

        num_solver_workers = Constants.SOLVER_NUM_SOLVER_WORKERS

        time_limit = Constants.SOLVER_SECOND_STEP_OF_TIME_LIMIT

        gap_limit = Constants.SOLVER_SECOND_STEP_OF_GAP_LIMIT

        first_output = {}
        logger.info(f"【求解器】---一阶段求解——开始求解 CP-SAT 模型 核心线程数: {num_solver_workers}")
        logger.info(f"【求解器】---一阶段求解——开始求解 CP-SAT 模型 (时间限制: {time_limit}s, Relative Gap: {gap_limit * 100:.1f}%)...")
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = time_limit
        solver.parameters.relative_gap_limit = gap_limit
        if num_solver_workers > 0:
            solver.parameters.num_search_workers = num_solver_workers
        solver.parameters.log_search_progress = False
        solve_start_time = time.time()
        status = solver.Solve(model)


        solve_time = time.time() - solve_start_time
        first_output["solving_time"] = round(solve_time, 2)
        first_stage_dialog = {
            "status": solver.StatusName(status),
            "solve_time": solve_time
        }
        logger.info(f"【求解器】---一阶段求解——CP-SAT 求解完成，耗时: {solve_time:.2f} 秒")
        logger.info(
            f"【求解器】---一阶段求解——求解状态码: {status} ({solver.StatusName(status)})")

        logger.info(f"【求解器】---步骤 7: 一阶段求解——处理和解析一阶段 CP-SAT 优化结果...")
        final_status = status_map.get(status,
                                      f"unknown_{solver.StatusName(status)}")
        solution_found = (status == cp_model.OPTIMAL
                          or status == cp_model.FEASIBLE)
        logger.info(f"【求解器】---一阶段求解——求解状态码: {status} ({solver.StatusName(status)})")
        if status == cp_model.MODEL_INVALID:
            raise ValueError("    模型错误：求解器设置错误，无法求解，请检查。")
        if status == cp_model.INFEASIBLE:
            raise ValueError("    求解失败：问题没有任何可行解，请检查参数设置或更换输入数据尝试。")
        if status == cp_model.UNKNOWN:
            raise ValueError(
                f"    求解失败：没有在规定时间({time_limit})内找到符合gap要求({gap_limit})的解，请延长求解时间或更换输入数据尝试。"
            )
        if status == cp_model.FEASIBLE:
            time_limit_reached = solve_time >= time_limit * 0.98
            gap_limit_met = False
            obj_val = solver.ObjectiveValue()
            bound = solver.BestObjectiveBound()
            current_gap = 0.0
            if abs(obj_val) > epsilon:
                current_gap = abs(obj_val - bound) / (abs(obj_val) + epsilon)
            elif abs(obj_val - bound) > epsilon:
                current_gap = float('inf')
            if gap_limit > 0 and current_gap > gap_limit: gap_limit_met = True
            if time_limit_reached:
                final_status = "feasible_timelimit"
                print("    状态修正: 可行解，但可能因达到时间限制而停止。")
                logger.info(f"【求解器】---一阶段求解——状态修正: 可行解，但可能因达到时间限制而停止。")
            elif gap_limit_met:
                final_status = "feasible_gaplimit"
                print(
                    f"    状态修正: 可行解，但目标间隙 ({current_gap:.2%}) 未达到预设值 ({gap_limit:.2%})。"
                )
                logger.info(
                    f"【求解器】---一阶段求解——状态修正: 可行解，但目标间隙 ({current_gap:.2%}) 未达到预设值 ({gap_limit:.2%})。"
                )
        first_output["overall_status"] = final_status

        if solution_found:
            print(
                f"  CP-SAT 找到解。最终状态: {solver.StatusName(status)} (映射为: {final_status})"
            )
            scaled_obj_val = solver.ObjectiveValue()
            final_obj_val = scaled_obj_val / SCALE_FACTOR if SCALE_FACTOR > 0 else 0
            first_output["total_objective"] = round(final_obj_val, 4)
            print(f"    目标函数值 (Scaled): {scaled_obj_val}")
            print(f"    目标函数值 (Unscaled, 总效用): {final_obj_val:.4f}")
            print(
                f"    求解器界限 (Scaled Best Bound): {solver.BestObjectiveBound()}"
            )
            print("    提取优化后的饮食计划...")
            weekly_plan = {}
            print("      第一遍: 构建基础计划结构")
            for d in range(num_day):
                day_plan = {}
                for m in meal_keys:
                    if m not in y[d]: continue
                    day_plan[m] = []
                    for i in range(num_type):
                        if i in y[d].get(m, {}):
                            num_y = solver.Value(y[d][m][i])
                            if num_y > 0:
                                transformed_type_item = {
                                    "category_name": type_category_list[i],
                                }
                                day_plan[m].append(transformed_type_item)
                weekly_plan.update({day_name[d]: day_plan})

            first_output["weekly_plan"] = weekly_plan
            if save_local_flag and weekly_plan:
                try:
                    output_dir = os.path.join("user_analysis_results",
                                              str(current_date_str))
                    os.makedirs(output_dir, exist_ok=True)
                    filename = f"{user_id}_meal_plan_final_CP-SAT_{time.strftime('%Y%m%d_%H%M%S')}.json"
                    filepath = os.path.join(output_dir, filename)
                    logger.info(f"【求解器】---一阶段求解——准备将最终格式的优化结果写入文件: {filepath}")
                    with open(filepath, 'w', encoding='utf-8') as f:
                        json.dump(first_output,
                                  f,
                                  indent=2,
                                  ensure_ascii=False)
                    logger.info(f"【求解器】---一阶段求解——最终格式优化结果已成功保存到: {filepath}")
                except Exception as save_err:
                    logger.error(f"【求解器】---一阶段求解——警告: 保存最终格式 JSON 文件时发生错误: {save_err}")
                    traceback.print_exc()
        else:
            first_output["total_objective"] = 0.0
            first_output["weekly_plan"] = {}
            error_message = f"CP-SAT 未找到可行解 (状态: {solver.StatusName(status)} - {final_status})"
            logger.error(f"【求解器】---一阶段求解——优化失败: {error_message}")
            if status == cp_model.INFEASIBLE:
                logger.error(f"【求解器】---模型被判定为不可行。请检查约束条件是否过于严格或相互冲突，特别是：")
                logger.error(f"【求解器】---营养目标范围 (总热量、宏量、餐次比例)")
                logger.error(f"【求解器】---食物选择规则 (互斥、种类上限、日内重复、周频率)")
                logger.error(f"【求解器】---单个食物的最小份量约束 (min_serving_units / min_steps_per_selection)")
                logger.error(f"【求解器】---可选食物库是否充足且数据合理")
            if status == cp_model.MODEL_INVALID:
                error_message = model.Validate()
                print(error_message)

        logger.info("【求解器】---步骤 8: 二阶段求解——获取食物食谱...")
        logger.info(f"【求解器】---二阶段求解——求解开始，求解目标: 二阶段求解")
        second_stage_start_time = time.time()
        second_stage_dialog = {}
        transformed_weekly_food_plan = {}
        type_serving_weight_range = {}

        default_category_range = None
        food_category_quality_range_config_dict = \
            FoodComponentConstraintsForChronicDiseasesConfig.get_constraints_by_disease_name(disease_priority_name)
        food_category_quality_range_config = food_category_quality_range_config_dict['constraints']
        food_category_quality_range_type = food_category_quality_range_config_dict['type']
        food_category_quality_range_dict = {}
        for category_config in food_category_quality_range_config:
            if category_config['category_main'] == 'default':
                default_category_range = category_config['range']
            else:
                for category_name in category_config['name']:
                    food_category_quality_range_dict.update({category_name: category_config['range']})

        if not default_category_range:
            default_category_range = [100, 450]

        for category in last_level_categories:
            if category in food_category_quality_range_dict and food_category_quality_range_dict[category]:
                type_serving_weight_range.update({category: food_category_quality_range_dict[category]})
            else:
                type_serving_weight_range.update({category: default_category_range}) 
        used_foods = {}
        decay_factor = Constants.DECAY_FACTOR

        successfull_solve_days = []
        check_successfull_solve_day_index = 0
        SOLVER_MAX_TIMES_LIMIT = 2
        
        all_not_recommended_food_list = []

        choose_recipe_id_arr = []

        for day, day_plan in weekly_plan.items():
            current_day = day
            second_stage_dialog.update({day: {}})
            logger.info(f"【求解器】---二阶段求解——-----------------求解开始，求解目标: {day} 饮食计划-------------------------")
            transformed_day_food_plan = None

            check_successfull_solve_day_index = 0
            
            solver_times_index = 1
            successfull_solve_day_max_index = len(successfull_solve_days) - 1
            meal_arr = ['breakfast', 'lunch', 'dinner', 'snack']

            check_model_lowest_score_for_retry_times_limit = 0
            model_approved_flag = False
            every_solver_result = {}
            check_meal_rationality_params = {
                "dietary_pattern": user_diet_mode_name,
                "user_self_report": user_self_report,
            }

            while True:
                second_stage_result = food_solver(
                    alternative_food, 
                    serving_increment, 
                    current_day,
                    user_nutrition_info, 
                    SCALE_FACTOR, 
                    min_steps_per_selection,
                    type_serving_weight_range, 
                    first_output, 
                    solver_params_dict,
                    used_foods,
                    decay_factor
                )

                if not isinstance(second_stage_result, dict):
                    solver_times_index += 1
                    continue

                transformed_day_food_plan = second_stage_result["transformed_day_food_plan"]
                if transformed_day_food_plan != None:
                    logger.info(f"【求解器】---二阶段求解——求解成功，日期：{day}，求解结果结果: {transformed_day_food_plan}")

                    analyse_meal_info_result = analyse_meal_info(transformed_day_food_plan)

                    meal_info_list = analyse_meal_info_result['meal_info_list']
                    food_name_id_check_dict = analyse_meal_info_result.get('food_name_id_check_dict', {})
                    meal_info_list_str = '\n'.join(meal_info_list)
                    check_meal_rationality_params['meal_info_str'] = meal_info_list_str
                    analyse_meal_rationality_result = execute_llm_analyse_meal_rationality_by_cons(check_meal_rationality_params)
                    logger.warning(f"【求解器，二阶段求解结果】---\n日期：{day}，饮食合理性分析结果: {analyse_meal_rationality_result}")
                    meal_rationality_score = analyse_meal_rationality_result.get('score', None)

                    if meal_rationality_score == None:
                        logger.error(f"【求解器，二阶段求解结果】---日期：{day}，饮食合理性分析结果，未包含评分信息。")
                        continue
                    
                    not_recommended_food_list = analyse_meal_rationality_result.get('not_recommended_food_list', [])
                    if not_recommended_food_list and len(not_recommended_food_list) > 0:
                        if solver_params_dict['not_recommended_food_list']:
                            solver_params_dict['not_recommended_food_list'] = []
                        
                        temp_not_recommended_food_list = []
                        for food_name in not_recommended_food_list:
                            if food_name in food_name_id_check_dict.keys():
                                all_not_recommended_food_list.append(food_name_id_check_dict[food_name])
                        solver_params_dict['not_recommended_food_list'].extend(all_not_recommended_food_list)

                        logger.info(f"【求解器，二阶段求解结果】---日期：{day}，不建议的食物清单(继承前日食物，共{len(all_not_recommended_food_list)}个)")

                    if meal_rationality_score < Constants.MODEL_LOWEST_SCORE_FOR_DAILY_RECIPES:
                        check_model_lowest_score_for_retry_times_limit += 1
                        every_solver_result[meal_rationality_score] = transformed_day_food_plan

                        logger.error(f"【求解器，二阶段求解结果】---日期：{day}，饮食合理性分析结果，第{check_model_lowest_score_for_retry_times_limit}次评分过低({meal_rationality_score} < {Constants.MODEL_LOWEST_SCORE_FOR_DAILY_RECIPES})，视为求解失败。")
                        if check_model_lowest_score_for_retry_times_limit >= Constants.MODEL_LOWEST_SCORE_FOR_RETRY_TIMES_LIMIT:
                            logger.error(f"【求解器，二阶段求解结果】---日期：{day}，饮食合理性分析结果，评分过低({meal_rationality_score} < {Constants.MODEL_LOWEST_SCORE_FOR_DAILY_RECIPES})，已达到最大重试次数限制({Constants.MODEL_LOWEST_SCORE_FOR_RETRY_TIMES_LIMIT})，停止重试。")
                            check_model_lowest_score_for_retry_times_limit = 0
                            if Constants.IS_USE_MAX_SCORE_FLAG:
                                model_approved_flag = True
                                max_score = max(every_solver_result.keys())
                                logger.warning(f"【求解器，二阶段求解结果】---日期：{day}，饮食合理性分析结果，使用最高评分 【{max_score}】 的食谱结果，继续后续处理。")
                                transformed_day_food_plan = every_solver_result[max_score]
                            else:
                                model_approved_flag = False
                            break
                        continue
                    model_approved_flag = True
                    break
                else:
                    logger.error(f"【求解器】---二阶段求解---{day}---——第{solver_times_index}次求解失败，状态名({second_stage_result['status']})。")
                    day_plan = first_output["weekly_plan"][current_day]
                    logger.error(f"【求解器】---二阶段求解---{day}---每餐计划：")
                    log_str = ""
                    for meal_str, allowed_category_list in day_plan.items():
                        category_last_name_arr = []
                        for category_dict in allowed_category_list:
                            category_last_name_arr.append(category_dict['category_name'][-1])
                        log_str += f"{meal_str:<10}：{', '.join(category_last_name_arr)}\n"
                    logger.error(f"\n{log_str}")
                    
                    solver_times_index += 1
                    if solver_times_index > SOLVER_MAX_TIMES_LIMIT:
                        logger.error(f"【求解器】---二阶段求解---{day}---——第{solver_times_index}次求解失败，状态名({second_stage_result['status']})。")
                        if successfull_solve_day_max_index > -1 and Constants.USING_FORMER_SOLVER_CONSTRAINT:
                            current_day = successfull_solve_days[successfull_solve_day_max_index]
                            logger.error(f"【求解器】---二阶段求解---{day}-{successfull_solve_day_max_index}--- 使用上一次成功求解日期({current_day})的结果。")
                            successfull_solve_day_max_index -= 1
                        else:
                            break

            if model_approved_flag == False:
                logger.warning(f"【求解器】---二阶段求解---{day}---求解失败，尝试使用通用食谱进行求解。")
                recipe_solver_result = recipe_solver_function({
                    "day": day,
                    "choose_recipe_id_arr": choose_recipe_id_arr,
                    "check_meal_rationality_params": check_meal_rationality_params,
                    "meal_ratio_ranges": meal_ratio_ranges,
                    "calories": nutrition_solver_params['calories'],
                    "macro_ratio_ranges": macro_ratio_ranges,
                })
                logger.info(f"【求解器，二阶段求解结果】---日期：{day}，通用食谱求解结果：{recipe_solver_result}")
                if recipe_solver_result is not None:
                    transformed_day_food_plan = recipe_solver_result
                    choose_recipe_id_arr.append(recipe_solver_result['choose_recipe_id'])
                    model_approved_flag = True


            if model_approved_flag == False:
                temp_str = f"【求解器】---二阶段求解——求解失败, 无可行解或未通过模型评分阈值({Constants.MODEL_LOWEST_SCORE_FOR_DAILY_RECIPES})。"
                logger.error(temp_str)
                raise ValueError(temp_str)
            second_stage_result["transformed_day_food_plan"] = transformed_day_food_plan
            
            second_stage_dialog[day].update({
                "status": solver.StatusName(second_stage_result["status"]),
                "solve_time": second_stage_result["solve_time"]
            })

            transformed_weekly_food_plan.update({day: transformed_day_food_plan})
            successfull_solve_days.append(day)
            check_successfull_solve_day_index = 0
            
            
            meal_using_food_name_set = set()

            food_plan_obj = transformed_day_food_plan['food_plan']
            for meal_str in meal_arr:
                meal_food_arr = []
                if meal_str in food_plan_obj:
                    meal_food_arr = food_plan_obj[meal_str]
                if not meal_food_arr:
                    continue
                this_meal_food_name_set = set()
                for one_food_data in meal_food_arr:
                    food_entity_name = one_food_data['name']
                    this_meal_food_name_set.add(food_entity_name)
                    if food_entity_name in used_foods:
                        used_foods[food_entity_name] += 1
                    else:
                        used_foods[food_entity_name] = 1
                logger.info(f"【求解器，二阶段求解结果】---日期：{day}，餐次：{meal_str}，使用食物: {this_meal_food_name_set}")
            if second_stage_result["transformed_day_food_plan"] == None:
                logger.error(
                    f"【求解器】---二阶段求解——求解失败，状态名({second_stage_result['status']})。"
                )
                raise ValueError(f"    二阶段求解失败，状态名({second_stage_result['status']})。")

        solve_dialog = {
            "first_stage": first_stage_dialog,
            "second_stage": second_stage_dialog
        }
        final_output = {
            "solve_dialog": solve_dialog,
            "weekly_plan": transformed_weekly_food_plan,
            "nutrition_solver_params": nutrition_solver_params
        }
        total_second_stage_time = time.time() - second_stage_start_time

        if save_local_flag and transformed_weekly_food_plan:
            try:
                output_dir = os.path.join("user_analysis_results", str(current_date_str))
                os.makedirs(output_dir, exist_ok=True)
                filename = f"{user_id}_food_plan_final_CP-SAT_{time.strftime('%Y%m%d_%H%M%S')}.json"
                filepath = os.path.join(output_dir, filename)
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(final_output, f, indent=2, ensure_ascii=False)
            except Exception as save_err:
                traceback.print_exc()

    except ValueError as ve:
        error_msg = f"优化节点输入/配置错误 (CP-SAT): {str(ve)}"
        logger.error(f"【求解器】---CP-SAT 优化节点输入/配置错误: {error_msg}")
        traceback.print_exc()
        first_output["overall_status"] = "error_validation"
        return {
            "error": error_msg,
            "optimal_meal_plan": first_output
        }
    except Exception as proto_err:
        error_msg = f"CP-SAT 模型构建或约束错误: {str(proto_err)}"
        logger.error(f"【求解器】---CP-SAT 模型构建或约束错误: {error_msg}")
        traceback.print_exc()
        first_output["overall_status"] = "error_model_invalid"
        return {
            "error": error_msg,
            "optimal_meal_plan": first_output
        }
    except RuntimeError as rte:
        error_msg = f"优化节点运行时错误 (CP-SAT): {str(rte)}"
        logger.error(f"【求解器】---CP-SAT 优化节点运行时错误: {error_msg}")
        traceback.print_exc()
        first_output["overall_status"] = "error_runtime"
        return {
            "error": error_msg,
            "optimal_meal_plan": first_output
        }
    except Exception as e:
        error_msg = f"优化节点发生意外错误 (CP-SAT): {str(e)}"
        logger.error(f"【求解器】---CP-SAT 优化节点发生意外错误: {error_msg}")
        traceback.print_exc()
        first_output["overall_status"] = "error_unexpected"
        return {
            "error": error_msg,
            "optimal_meal_plan": first_output
        }

    finally:
        total_node_time = time.time() - node_start_time
        logger.info(f"--- CP-SAT 优化节点执行完成 ---")
        logger.info(f"  节点总耗时: {total_node_time:.2f} 秒")
        logger.info(
            f"  求解器耗时: 第一阶段{first_output['solving_time']:.2f} 秒， 第二阶段{total_second_stage_time}"
        )
        logger.info(f"  最终状态: {solve_dialog}")

    return {"optimal_meal_plan": final_output}


async def execute_solver_async(params: dict) -> dict:
    return await optimize_plan_node(params)


def execute_solver(params: dict) -> dict:
    return optimize_plan_node(params)

def round_with_mode(x, n=1, mode='floor'):
    factor = 10 ** n
    if mode == 'ceil':
        return math.ceil(x * factor) / factor
    else:
        return math.floor(x * factor) / factor


if __name__ == "__main__":
    import asyncio
    start_time = time.time()
    with open('lichangyu_main_result.json', 'r', encoding='utf-8') as file:
        intake = json.load(file)
    result = optimize_plan_node({"data": intake})