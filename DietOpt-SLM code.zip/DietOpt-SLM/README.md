## 1. Solver

### 1.1 Basic Information

**Version:** 1.0

**File structure and description:**

```
DietOpt-SLM/             # Project root directory
├── .gitignore
├── README.md
├── requirements.txt
└── src/                               # Core source code directory
    ├── clazz/                         # Low-level shared classes and managers
    ├── config/                        # Business rules and static parameters
    ├── model/                         # Model-related files (weights/configurations)
    ├── schedule/                      # Scheduled task module
    ├── graph_reasoner/                # [Reasoning engine] Responsible for preference analysis,
    │                                  # suitability assessment, and other qualitative reasoning
    ├── solver/                        # Optimization solver module
    ├── util/                          # Utility functions and helpers
    ├── main.py                        # Main program entry point
    ├── sync_work_process.py           # Synchronous workflow script
    └── work_process.py                # General workflow script
```

------

### 1.2 Installation Guide

**Operating system:** Windows / Linux

**Programming language:** Python

**Non-standard hardware or special resource requirements:** None

**Environment dependencies:**

```
# Installation time may vary depending on network conditions,
# but all dependencies are standard and install quickly.
pip install -r requirements.txt
```

------

### 1.3 Project Startup

```
conda activate <environment_name>
cd src/
nohup uvicorn main:app --host 0.0.0.0 --port 9000 > ./app_solver.log 2>&1 &

# Terminate the process if needed
# pkill -9 -f "uvicorn main:app --host 0.0.0.0 --port 9000"
```

------

### 1.4 API Request Example

```sh
{
	"diet_history": "早餐***午餐***晚餐***...",
	"user_info_json": {
		"family_med_history": "",
		"nutrition_water_history": "",
		"gender": "男",
		"anamnesis": "高血脂",
		"is_save_main_process_result": "0",
		"city": "**省**市",
		"snack": 1,
		"special_physiological_period": [],
		"weight": 65.4,
		"allergy": "无",
		"personal_lifestyle": "运动习惯近几年没有，睡眠较好，精神压力之前大；不吸烟饮酒...",
		"activity_level": "轻度活动",
		"dietary_preference": {
			"preference": "肉多以猪肉为主..."
		},
		"medication_status": "阿司匹林...",
		"health_risk": [
			"支架术后2个月，高血脂"
		],
		"id": "e1cf100dadc144ce9b9....",
		"age": 34,
		"nutrition_target": "控制血脂",
		"height": 176.0
	},
	"nutritional_prescription": {
		"dietary_advice": "营养处方建议",
		"nutritional_prescription_dietary_pattern_code": "膳食模式编码，代码中有"
	},
	"is_save_main_process_result": "0",
	"user_self_report": "",
	"query_type": "user_info_json"
}

```
